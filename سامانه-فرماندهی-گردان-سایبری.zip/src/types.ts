export type UserRole = 'admin' | 'manager' | 'user';
export type BattalionType = 'shamsa' | 'matna' | 'nasra' | 'resane_mahale';
export type UnitLevel = 'nahiye' | 'howze' | 'paygah' | 'gordan';

export interface OrganizationalUnit {
  id: string | number;
  name: string;
  level: UnitLevel;
  parentId?: string;
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  phone: string;
  name: string;
  rank: string;
  password?: string;
  role: UserRole;
  departments?: BattalionType[];
  unitLevel?: UnitLevel;
  unitId?: string | number; // Structured link to OrganizationUnit
  unitName?: string;
  points: number;
  level: number;
  completedMissions: number;
  isWhitelisted?: boolean;
  isTrusted?: boolean;
  createdAt: string;
  unit?: string;
  bio?: string;
  avatar?: string;
  email?: string;
  baleId?: string;
  notificationsEnabled?: boolean;
  baleNotificationsEnabled?: boolean;
  walletBalance?: number;
  referralCode?: string;
  referralCount?: number;
}

export interface Task {
  id: string;
  missionId: string;
  title: string;
  description: string;
  points: number;
  platform: 'twitter' | 'instagram' | 'bale' | 'telegram' | 'skyroom' | 'rubika' | 'other';
  department?: BattalionType;
  status: 'pending' | 'in_progress' | 'submitted' | 'completed' | 'rejected';
  deadline: string;
  assignedTo?: string; // User UID
  contentId?: string;
  targetLink?: string; // Link to the post/tweet to interact with
  contentCaption?: string;
  contentBody?: string;
  contentImage?: string;
  documentationLink?: string;
  documentationScreenshot?: string;
  adminFeedback?: string;
  completedBy?: string; // User UID
  completedAt?: string;
  createdAt: string;
  steps?: string[];
  currentStep?: number;
  educationId?: string;
  // Nasra Fields
  isNasra?: boolean;
  nasraType?: 'webinar' | 'live' | 'video' | 'article' | 'tutorial';
  nasraUrl?: string;
  evidenceUrl?: string;
}

export interface TrackedAccount {
  id: string;
  platform: 'instagram' | 'bale' | 'twitter';
  handle: string;
  name: string;
  category: 'enemy' | 'friendly' | 'neutral';
  lastActivity: string;
  status: 'active' | 'inactive';
  notes?: string;
}

export interface EducationSession {
  id: string;
  title: string;
  type: 'audio' | 'video' | 'text' | 'html';
  content: string; // URL or raw content
}

export interface EducationItem {
  id: string;
  title: string;
  description: string;
  coverImage: string;
  sessions: EducationSession[];
  createdAt: string;
}

export interface GordanContent {
  id: string;
  title: string;
  content: string;
  type: 'video' | 'poster' | 'tweet' | 'post';
  targetAudience: 'all' | 'leaders' | 'subordinates';
  publishedBy: string; // Admin UID
  createdAt: string;
  attachments?: string[];
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  type: 'daily' | 'special' | 'urgent';
  priority?: 'low' | 'medium' | 'high' | 'critical';
  difficulty: 'easy' | 'medium' | 'hard' | 'expert';
  category: 'social' | 'intelligence' | 'content' | 'technical';
  reward: string;
  isCompleted: boolean;
  isArchived: boolean;
  createdAt: string;
  educationId?: string;
  sendBaleAlert?: boolean;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'info' | 'warning' | 'critical';
  sender: string;
  timestamp: string;
  isPublic: boolean;
}

export type ChatType = 'direct' | 'group' | 'channel' | 'bot';

export interface Chat {
  id: string;
  name: string;
  lastMsg: string;
  time: string;
  unread: number;
  avatar: string;
  color: string;
  type: ChatType;
  messages: Message[];
  description?: string;
  subscribers?: number;
}

export interface Message {
  id: string;
  text: string;
  sender: string;
  time: string;
  media?: string;
  isMarked?: boolean;
}

export interface SaleRecord {
  id: string;
  title: string;
  amount: number;
  date: string;
  recordedBy: string;
  status: 'pending' | 'verified' | 'rejected';
}

export interface Report {
  id: string;
  title: string;
  content?: string;
  description?: string;
  url?: string;
  category: string;
  date?: string;
  timestamp?: string;
  author?: string;
  status: 'pending' | 'reviewed' | 'rejected';
}

export interface Observation {
  id: string;
  instagramPage: string;
  fakeContentTitle: string;
  screenshots: string[];
  reportedBy: string; // User UID
  createdAt: string;
  status: 'pending' | 'reviewed' | 'rejected';
}

export interface AIContent {
  content: string;
  hashtags: string[];
  suggestedTime: string;
}

export interface ContentItem {
  id: string;
  type: 'tweet' | 'post' | 'story' | 'poster' | 'video';
  title: string;
  content: string;
  imageUrl?: string;
  hashtags: string[];
  isPublished: boolean;
  downloadCount: number;
  isMarked?: boolean;
}

export interface AnalyticsData {
  totalReports: number;
  totalPublished: number;
  impactScore: number;
  activeMembers: number;
  trendingTopics: string[];
}

export interface BotConfig {
  token: string;
  welcomeMessage: string;
  notificationsEnabled: boolean;
  autoReplyEnabled: boolean;
  adminChatId?: string;
  channelId?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  description: string;
  date?: string; // ISO format
  time?: string; // Friendly time
  type: 'operation' | 'briefing' | 'drill' | 'maintenance' | 'deadline' | 'training' | 'mission' | 'other';
  priority?: 'low' | 'medium' | 'high' | 'critical';
  assignedUnit?: string;
  location?: string;
}
