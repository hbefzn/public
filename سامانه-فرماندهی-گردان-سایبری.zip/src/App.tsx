import React, { useState, useEffect, useRef } from 'react';
import jalaali from 'jalaali-js';
import { motion, AnimatePresence } from 'motion/react';

declare global {
  interface Window {
    ethereum?: any;
  }
}

import { 
  Menu, 
  Search, 
  Plus, 
  Check, 
  Copy, 
  Upload, 
  Shield,
  Clock,
  Moon,
  Sun,
  Zap,
  Twitter,
  AlertCircle,
  AlertTriangle,
  ChevronRight,
  Calendar,
  Share2,
  MessageSquare,
  Send,
  MoreVertical,
  ArrowRight,
  ArrowLeft,
  Paperclip,
  Mic,
  Bookmark,
  Hash,
  Layout,
  Settings,
  Info,
  LogOut,
  Download,
  Eye,
  BarChart3,
  Image as ImageIcon,
  Video,
  FileText,
  CheckCircle2,
  CheckCircle,
  Activity,
  Wallet,
  Landmark,
  Gift,
  ArrowUpRight,
  Headset,
  Users,
  Target,
  Trophy,
  Bell,
  Volume2,
  VolumeX,
  Filter,
  Star,
  Lock,
  Phone,
  UserPlus,
  Trash2,
  Edit3,
  TrendingUp,
  GraduationCap,
  Compass,
  LayoutGrid,
  ChevronLeft,
  ExternalLink,
  Instagram,
  Camera,
  XCircle,
  Terminal,
  Maximize2,
  AtSign,
  CheckCheck,
  Smile,
  DollarSign,
  List,
  BookOpen,
  Play,
  ShieldCheck,
  Archive,
  Link as LinkIcon,
  X,
  MapPin,
  LayoutDashboard,
  CalendarDays,
  ClipboardList,
  ShieldAlert,
  Megaphone,
  Signal,
  ScanEye,
  MonitorDot,
  FileSpreadsheet,
  History,
  Bot,
  RefreshCw,
  CreditCard
} from 'lucide-react';
import { generateCyberContent, getDailyBrief, monitorTrendingNews, generateTweets, generateStrategicAnalysis } from './lib/gemini';
import { Task, Report, AIContent, ContentItem, AnalyticsData, Mission, Chat, Message, UserProfile, UserRole, TrackedAccount, GordanContent, SaleRecord, EducationItem, EducationSession, Observation, BotConfig, CalendarEvent, BattalionType, UnitLevel, OrganizationalUnit } from './types';

import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart,
  Area,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie
} from 'recharts';

const Toast = ({ message, type, onClose }: { message: string, type: 'success' | 'error', onClose: () => void }) => (
  <motion.div 
    initial={{ opacity: 0, y: 50, scale: 0.9 }}
    animate={{ opacity: 1, y: 0, scale: 1 }}
    exit={{ opacity: 0, y: 20, scale: 0.9 }}
    className={`fixed bottom-24 left-6 right-6 z-[100] p-4 rounded-2xl shadow-2xl border flex items-center gap-3 ${
      type === 'success' ? 'bg-emerald-500 border-emerald-400 text-white' : 'bg-red-500 border-red-400 text-white'
    }`}
  >
    {type === 'success' ? <CheckCircle2 size={20} /> : <AlertCircle size={20} />}
    <p className="text-xs font-black flex-1">{message}</p>
    <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-lg transition-colors">
      <XCircle size={18} />
    </button>
  </motion.div>
);

const StatCard = ({ icon: Icon, label, value, color, trend }: { icon: any, label: string, value: string, color: string, trend?: string }) => (
  <div className="bg-tg-surface p-4 rounded-2xl border border-tg-border shadow-sm space-y-2 relative group transition-colors">
    <div className={"w-10 h-10 rounded-2xl bg-black/5 dark:bg-white/5 flex items-center justify-center " + color + " relative z-10 transition-colors"}>
      <Icon size={20} />
    </div>
    <div className="relative z-10">
      <p className="text-[9px] font-black text-tg-text-muted uppercase tracking-widest">{label}</p>
      <div className="flex items-end gap-2">
        <p className="text-xl font-black font-mono text-tg-text">{value}</p>
        {trend && <span className="text-[8px] font-black text-emerald-500 mb-1">{trend}</span>}
      </div>
    </div>
  </div>
);

// --- Components ---

const CommandCenter = ({ users, tasks, content, user, logs, setLogs }: { users: UserProfile[], tasks: Task[], content: ContentItem[], user: UserProfile | null, logs: any[], setLogs: (l: any[]) => void }) => {
  const [analysis, setAnalysis] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const fetchAnalysis = async () => {
    setLoading(true);
    try {
      const data = await generateStrategicAnalysis({ 
        userCount: users.length, 
        taskCount: tasks.length, 
        platforms: tasks.map(t => t.platform),
        recentActivity: tasks.slice(-10)
      });
      setAnalysis(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const res = await fetch('/api/system/logs');
        const data = await res.json();
        setLogs(data);
      } catch (err) {}
    };
    if (user?.role === 'admin') {
      fetchLogs();
      const interval = setInterval(fetchLogs, 10000);
      return () => clearInterval(interval);
    }
  }, [user, setLogs]);

  useEffect(() => {
    fetchAnalysis();
  }, [users, tasks]);

  const chartData = [
    { name: 'شنبه', activity: 400, impact: 240 },
    { name: 'یکشنبه', activity: 300, impact: 139 },
    { name: 'دوشنبه', activity: 200, impact: 980 },
    { name: 'سه‌شنبه', activity: 278, impact: 390 },
    { name: 'چهارشنبه', activity: 189, impact: 480 },
    { name: 'پنج‌شنبه', activity: 239, impact: 380 },
    { name: 'جمعه', activity: 349, impact: 430 },
  ];

  const platformData = [
    { name: 'توییتر', value: tasks.filter(t => t.platform === 'twitter').length },
    { name: 'اینستاگرام', value: tasks.filter(t => t.platform === 'instagram').length },
    { name: 'بله', value: tasks.filter(t => t.platform === 'bale').length },
  ];

  const COLORS = ['#2481cc', '#e1306c', '#0088cc'];

  return (
    <>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard icon={Activity} label="عملکرد شبکه" value={`${tasks.length * 124}`} color="text-blue-500" trend="+۱۲٪" />
          <StatCard icon={Target} label="ضریب نفوذ" value="۸.۴" color="text-emerald-500" trend="+۵٪" />
          <StatCard icon={Users} label="افسران فعال" value={`${users.length}`} color="text-purple-500" />
          <StatCard icon={Share2} label="محتوای وایرال" value={`${content.filter(c => c.downloadCount > 100).length}`} color="text-orange-500" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-4 shadow-xl transition-colors">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-black uppercase tracking-widest text-tg-text-muted/60">نخبگان عملیاتی (Top 5)</h3>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                <span className="text-[8px] font-black text-amber-500 uppercase tracking-widest">براساس امتیاز کل</span>
              </div>
            </div>
            <div className="space-y-3">
              {users.sort((a, b) => b.points - a.points).slice(0, 5).map((topUser, i) => (
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  key={i} 
                  className={`flex items-center justify-between p-3 rounded-2xl border transition-all relative overflow-hidden group shadow-lg ${
                    i === 0 ? 'bg-gradient-to-r from-amber-500/20 to-transparent border-amber-500/30' : 
                    'bg-black/5 dark:bg-black/40 border-tg-border'
                  }`}
                >
                  {i === 0 && (
                    <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/10 rounded-full blur-2xl -mr-8 -mt-8" />
                  )}
                  <div className="flex items-center gap-4 relative z-10 font-sans">
                    <div className={"w-10 h-10 rounded-2xl flex items-center justify-center font-black text-sm transition-transform group-hover:scale-110 " + (
                      i === 0 ? 'bg-amber-500 text-white shadow-xl shadow-amber-500/40 ring-4 ring-amber-500/20' : 
                      i === 1 ? 'bg-black/20 dark:bg-white/20 text-tg-text shadow-lg' :
                      i === 2 ? 'bg-[#cd7f32] text-white shadow-lg' :
                      'bg-black/10 dark:bg-white/5 text-tg-text-muted border border-tg-border'
                    )}>
                      {i + 1}
                    </div>
                    <div>
                      <p className="text-[12px] font-black text-tg-text group-hover:text-amber-400 transition-colors">{topUser.name}</p>
                      <div className="flex items-center gap-2">
                        <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter ${
                          i === 0 ? 'bg-amber-500/20 text-amber-500' : 'bg-black/10 dark:bg-white/5 text-tg-text-muted border border-tg-border'
                        }`}>
                          {topUser.rank}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right relative z-10">
                    <p className={`text-sm font-black ${i === 0 ? 'text-amber-500 scale-110' : 'text-tg-text'}`}>
                      {topUser.points.toLocaleString('fa-IR')}
                    </p>
                    <p className="text-[7px] font-bold text-tg-text-muted uppercase tracking-widest">امتیاز کل</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-red-500/20 space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Clock size={14} className="text-red-500" />
                <h3 className="text-xs font-black uppercase tracking-widest text-red-500">اهداف حساس به زمان</h3>
              </div>
              <span className="text-[8px] font-black text-red-500 animate-pulse uppercase tracking-widest">ضرب‌الاجل‌ها</span>
            </div>
            <div className="space-y-3">
              {tasks
                .filter(t => t.status === 'pending' && t.deadline && t.deadline.includes('T'))
                .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
                .slice(0, 4)
                .map((t, i) => {
                  const timeLeft = new Date(t.deadline).getTime() - new Date().getTime();
                  const hoursLeft = Math.max(0, Math.floor(timeLeft / (60 * 60 * 1000)));
                  return (
                    <div key={i} className={"flex items-center justify-between p-3 rounded-2xl border transition-all " + (
                      timeLeft < 3 * 60 * 60 * 1000 ? 'bg-red-500/10 border-red-500/30 group hover:bg-red-500/20' : 'bg-black/5 dark:bg-white/5 border-tg-border hover:border-red-500/30'
                    )}>
                      <div className="flex items-center gap-3">
                        <div className={"w-8 h-8 rounded-xl flex items-center justify-center " + (timeLeft < 3 * 60 * 60 * 1000 ? 'bg-red-500 text-white' : 'bg-red-500/10 text-red-500')}>
                          <AlertCircle size={16} />
                        </div>
                        <div>
                          <p className="text-[10px] font-black truncate max-w-[120px] text-tg-text">{t.title}</p>
                          <p className="text-[8px] font-bold text-tg-text-muted ltr text-right">{new Date(t.deadline).toLocaleString('fa-IR', { hour: '2-digit', minute: '2-digit' })}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={"text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-tighter " + (
                          timeLeft < 3 * 60 * 60 * 1000 ? 'bg-red-500 text-white shadow-lg shadow-red-500/20' : 'bg-black/10 dark:bg-white/5 text-tg-text-muted border border-tg-border'
                        )}>
                          {hoursLeft.toLocaleString('fa-IR')} ساعت مانده
                        </span>
                      </div>
                    </div>
                  );
                })}
              {tasks.filter(t => t.status === 'pending' && t.deadline && t.deadline.includes('T')).length === 0 && (
                <div className="text-center py-12 opacity-40">
                  <p className="text-[10px] font-bold text-slate-500">موردی یافت نشد.</p>
                </div>
              )}
            </div>
          </div>

          <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-4 shadow-xl transition-colors">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-black uppercase tracking-widest text-tg-text-muted/60">آخرین فعالیت‌های عملیاتی</h3>
              <span className="text-[8px] font-black text-blue-500 animate-pulse">پخش زنده</span>
            </div>
            <div className="space-y-3 max-h-[256px] overflow-y-auto no-scrollbar">
              {tasks.slice(-5).reverse().map((task, i) => {
                const taskUser = users.find(u => u.uid === task.completedBy);
                return (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-2xl bg-black/5 dark:bg-white/5 border border-tg-border group hover:border-blue-500/30 transition-all">
                    <div className={"w-8 h-8 rounded-xl flex items-center justify-center text-white " + (
                      task.status === 'completed' ? 'bg-emerald-500/20 text-emerald-500' : 
                      task.status === 'submitted' ? 'bg-amber-500/20 text-amber-500' : 'bg-blue-500/20 text-blue-500'
                    )}>
                      {task.status === 'completed' ? <CheckCircle2 size={16} /> : 
                       task.status === 'submitted' ? <Clock size={16} /> : <Activity size={16} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] font-black truncate text-tg-text">{task.title}</p>
                      <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">
                        {taskUser?.name || 'کاربر ناشناس'} • {task.status === 'completed' ? 'تکمیل شده' : task.status === 'submitted' ? 'در انتظار تایید' : 'در حال انجام'}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[8px] font-black text-tg-text-muted">{new Date(task.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="space-y-6 pt-6 border-t border-white/5 opacity-80">
          <div className="flex items-center gap-2 px-2">
            <Activity size={18} className="text-blue-500" />
            <h3 className="text-sm font-black uppercase tracking-widest">تحلیل پیشرفت عملیاتی</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">تحلیل توزیع پلتفرمی</h3>
              </div>
              <div className="flex items-center justify-around h-48">
                <div className="w-1/2 h-full ltr">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={platformData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={8}
                        dataKey="value"
                      >
                        {platformData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{backgroundColor: '#1c242f', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', fontSize: '10px'}}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-3">
                  {platformData.map((p, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-md" style={{ backgroundColor: COLORS[i] }} />
                      <div>
                        <p className="text-[10px] font-black">{p.name}</p>
                        <p className="text-[8px] font-bold text-slate-500">{Math.round((p.value / tasks.length || 1) * 100) || 0}٪ تمرکز عملیاتی</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border flex flex-col justify-between">
              <div className="space-y-1">
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">بهره‌وری گردان</h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">Efficiency Index</p>
              </div>
              <div className="py-8 flex flex-col items-center">
                <div className="relative w-32 h-32 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90">
                    <circle cx="64" cy="64" r="58" fill="none" stroke="currentColor" strokeWidth="12" className="text-black/5 dark:text-white/5" />
                    <circle cx="64" cy="64" r="58" fill="none" stroke="currentColor" strokeWidth="12" strokeDasharray="364" strokeDashoffset={364 - (364 * 0.78)} className="text-blue-500 rounded-full" />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-3xl font-black text-tg-text">۷۸٪</span>
                    <span className="text-[8px] font-black text-tg-text-muted uppercase">عالی</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-4 shadow-xl transition-colors min-h-[300px]">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-black uppercase tracking-widest text-tg-text-muted/60">روند عملیاتی (۷ روز اخیر)</h3>
            </div>
            <div className="h-64 w-full ltr">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorActivity" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-tg-border" vertical={false} />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: 'currentColor', fontSize: 10, fontWeight: 700}} 
                    className="text-tg-text-muted"
                  />
                  <YAxis hide />
                  <Tooltip 
                    contentStyle={{backgroundColor: 'var(--tg-surface)', border: '1px solid var(--tg-border)', borderRadius: '12px', fontSize: '10px', color: 'var(--tg-text)'}}
                  />
                  <Area type="monotone" dataKey="activity" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorActivity)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="bg-tg-surface rounded-[2.5rem] border border-tg-border space-y-4 shadow-xl transition-colors">
            {analysis ? (
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className={"w-2 h-2 rounded-full glow-point " + (
                      analysis.threatLevel === 'critical' ? 'bg-red-500' : 
                      analysis.threatLevel === 'high' ? 'bg-orange-500' : 'bg-emerald-500'
                    )} />
                    <span className="text-[10px] font-black uppercase tracking-widest text-blue-500">سطح تهدید: {analysis.threatLevel}</span>
                  </div>
                  <p className="text-xs leading-relaxed text-slate-300 font-medium">
                    {analysis.summary}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500">تحلیل‌های کلیدی</h4>
                    <div className="space-y-2">
                      {analysis.keyInsights?.map((insight: string, i: number) => (
                        <div key={i} className="flex items-start gap-2 text-[10px] font-bold text-slate-400">
                          <div className="w-1 h-1 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                          <span>{insight}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500">دستورالعمل‌های عملیاتی</h4>
                    <div className="space-y-2">
                      {analysis.operationalDirectives?.map((directive: string, i: number) => (
                        <div key={i} className="flex items-start gap-2 text-[10px] font-bold text-slate-400">
                          <Check size={12} className="text-emerald-500 mt-0.5 shrink-0" />
                          <span>{directive}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 space-y-4">
                <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center mx-auto">
                  <Shield size={24} className="text-slate-700" />
                </div>
                <p className="text-[10px] font-bold text-slate-500">در حال آماده‌سازی تحلیل استراتژیک...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

const LoginScreen = ({ onLoginSuccess, onWalletConnect }: { onLoginSuccess: (user: UserProfile) => void, onWalletConnect?: () => void }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [loginMode, setLoginMode] = useState<'password' | 'bale'>('password');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1); // 1: Input phone/pass, 2: OTP (if bale)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (loginMode === 'bale' && step === 1) {
      // Simulate sending OTP
      setTimeout(() => {
        setStep(2);
        setLoading(false);
      }, 1000);
      return;
    }

    try {
      const endpoint = isLogin ? '/api/login' : '/api/signup';
      const body = isLogin 
        ? { phone, password, mode: loginMode, otp: loginMode === 'bale' ? otp : undefined } 
        : { phone, password, name };
      
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const data = await res.json();

      if (data.success) {
        localStorage.setItem('cyber_user', JSON.stringify(data.user));
        onLoginSuccess(data.user);
      } else {
        setError(data.message || 'خطایی رخ داد');
      }
    } catch (err: any) {
      setError('ارتباط با سرور برقرار نشد');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-app-bg min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden transition-colors">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-8 relative z-10"
      >
        <div className="text-center space-y-4">
          <div className="relative inline-block">
            <div className="w-28 h-28 bg-tg-accent rounded-[3rem] flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(59,130,246,0.3)] relative z-10 border-4 border-white/10 dark:border-white/5 transition-transform hover:scale-105 duration-500">
              <Shield size={56} className="text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]" />
            </div>
            <div className="absolute inset-0 bg-tg-accent/30 blur-[60px] rounded-full scale-150 z-0 animate-pulse" />
          </div>
          <div className="space-y-1">
            <h1 className="text-4xl font-black tracking-tighter uppercase text-tg-text drop-shadow-sm">Cyber Battalion</h1>
            <h2 className="text-xl font-bold text-tg-accent tracking-tighter opacity-90">استقرار مرکزی قرارگاه عملیاتی</h2>
            <div className="h-0.5 w-12 bg-tg-accent mx-auto my-3 rounded-full shadow-[0_0_10px_rgba(59,130,246,1)]" />
            <p className="text-[10px] text-tg-text-muted font-black uppercase tracking-[0.4em]">Strategic Defense & Global Operations</p>
          </div>
        </div>

        <div className="bg-tg-surface p-10 rounded-[3.5rem] border border-tg-border shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3)] relative group transition-all hover:shadow-tg-accent/5">
          <div className="absolute top-0 right-0 w-32 h-32 bg-tg-accent/5 rounded-full -mr-16 -mt-16 blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-500/5 rounded-full -ml-16 -mb-16 blur-3xl pointer-events-none" />
          
          <div className="flex bg-black/5 dark:bg-white/5 p-1.5 rounded-2xl border border-tg-border mb-8 relative z-10">
            <button 
              type="button"
              onClick={() => { setLoginMode('password'); setStep(1); }}
              className={`flex-1 py-3 rounded-xl text-[10px] font-black transition-all ${loginMode === 'password' ? 'bg-blue-500 text-white shadow-lg' : 'text-tg-text-muted'}`}
            >
              ورود با رمز عبور
            </button>
            <button 
              type="button"
              onClick={() => { setLoginMode('bale'); setStep(1); }}
              className={`flex-1 py-3 rounded-xl text-[10px] font-black transition-all ${loginMode === 'bale' ? 'bg-emerald-500 text-white shadow-lg' : 'text-tg-text-muted'}`}
            >
              ورود با پیام‌رسان بله
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {step === 1 ? (
              <>
                {!isLogin && (
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-tg-text-muted uppercase px-1 tracking-widest">نام و نام خانوادگی اصلی</label>
                    <div className="relative">
                      <input 
                        required
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="tg-input pr-12"
                        placeholder="نام عملیاتی خود را وارد کنید"
                      />
                      <Users size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-tg-text-muted" />
                    </div>
                  </div>
                )}
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-tg-text-muted uppercase px-1 tracking-widest">شماره همراه عملیاتی</label>
                  <div className="relative">
                    <input 
                      required
                      type="tel"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      className="tg-input pr-12 text-left font-mono"
                      placeholder="0912 000 0000"
                      dir="ltr"
                    />
                    <Phone size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-tg-text-muted" />
                  </div>
                </div>
                {loginMode === 'password' && (
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-tg-text-muted uppercase px-1 tracking-widest">رمز عبور (کلید دسترسی)</label>
                    <div className="relative">
                      <input 
                        required
                        type="password"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        className="tg-input pr-12 text-left font-mono"
                        placeholder="••••••••"
                        dir="ltr"
                      />
                      <Lock size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-tg-text-muted" />
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="space-y-4 text-center">
                <div className="w-16 h-16 bg-emerald-500/10 rounded-2xl flex items-center justify-center mx-auto text-emerald-500 mb-2 border border-emerald-500/20">
                  <MessageSquare size={32} />
                </div>
                <p className="text-xs font-bold text-tg-text-muted">کد تایید عملیاتی به پیام‌رسان بله ارسال شد.</p>
                <div className="space-y-2 text-right">
                  <label className="text-[10px] font-black text-tg-text-muted uppercase px-1 tracking-widest">کد تایید ۶ رقمی</label>
                  <input 
                    required
                    type="text"
                    value={otp}
                    onChange={e => setOtp(e.target.value)}
                    className="tg-input text-center font-mono text-xl tracking-[0.5em]"
                    placeholder="000000"
                    maxLength={6}
                  />
                </div>
                <button 
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-[9px] font-black text-blue-500 uppercase hover:underline"
                >
                  تغییر شماره یا روش ورود
                </button>
              </div>
            )}

            {error && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="p-4 bg-red-500/10 rounded-2xl border border-red-500/20 flex items-center gap-3 text-red-500 text-[11px] font-black"
              >
                <AlertCircle size={16} />
                <span>{error}</span>
              </motion.div>
            )}

            <button 
              disabled={loading}
              className="tg-btn-primary w-full flex items-center justify-center gap-3"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>{isLogin ? 'ورود به شبکه عملیاتی' : 'ثبت‌نام در قرارگاه'}</span>
                  <ArrowRight size={20} />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-tg-border space-y-4">
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="w-full text-[10px] font-black text-tg-text-muted hover:text-blue-500 transition-all uppercase tracking-widest pt-2"
              >
                {isLogin ? 'درخواست دسترسی جدید / عضویت' : 'قبلاً ثبت‌نام کرده‌اید؟ ورود به سامانه'}
              </button>
          </div>
        </div>

        <div className="flex flex-col items-center gap-4">
          <div className="flex items-center gap-2 px-4 py-2 bg-black/5 dark:bg-white/5 rounded-full border border-tg-border">
            <div className="w-2 h-2 rounded-full bg-emerald-500 glow-point" />
            <span className="text-[9px] font-black text-tg-text-muted uppercase tracking-widest">اتصال امن و پایدار برقرار است</span>
          </div>
          <p className="text-[9px] text-center text-tg-text-muted font-bold max-w-[280px] leading-relaxed">
            تمامی فعالیت‌ها در این سامانه تحت نظارت واحد امنیت سایبری قرار دارد. هرگونه سوء استفاده پیگرد قانونی خواهد داشت.
          </p>
        </div>
      </motion.div>
    </div>
  );
};

const ImageViewer = ({ src, isOpen, onClose }: { src: string, isOpen: boolean, onClose: () => void }) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-[200] flex items-end justify-center p-0 md:p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/95"
        />
        <motion.div 
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="relative w-full max-w-full md:max-w-4xl z-10 bg-tg-surface rounded-t-[3rem] p-4 flex flex-col items-center"
        >
          <div className="w-12 h-1.5 bg-slate-800 rounded-full mb-6" />
          <img src={src} className="max-w-full max-h-[70vh] object-contain rounded-2xl shadow-2xl mb-4" referrerPolicy="no-referrer" />
          <button 
            onClick={onClose}
            className="w-full py-4 bg-white/5 text-white font-black rounded-2xl mb-4"
          >
            بستن تصویر
          </button>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

const BottomSheet = ({ isOpen, onClose, title, children, className = "" }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode, className?: string }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[150] flex items-end justify-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className={`relative w-full max-w-2xl bg-tg-surface rounded-t-[2.5rem] border-t border-tg-border shadow-2xl p-6 overflow-y-auto max-h-[90vh] no-scrollbar transition-colors ${className}`}
          >
            <div className="w-12 h-1 bg-tg-border rounded-full mx-auto mb-6" />
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-black text-tg-text">{title}</h3>
              <button 
                onClick={onClose}
                className="p-2 hover:bg-black/5 dark:hover:bg-white/5 rounded-xl transition-colors text-tg-text-muted"
              >
                <X size={20} />
              </button>
            </div>
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const AdminDashboard = ({ 
  missions, 
  tasks, 
  users, 
  content, 
  trackedAccounts, 
  educationItems, 
  observations,
  reports,
  user,
  setToast,
  setViewingImage,
  integrations,
  setIntegrations,
  botConfig,
  setBotConfig,
  setTasks,
  setUsers,
  setMissions,
  setObservations,
  setReports,
  setTrackedAccounts,
  setEducationItems,
  onShare,
  dailyPlans,
  setDailyPlans,
  onTabChange,
  onAddUser,
  onAddEvent,
  onAddMission,
  onAddTask,
  updateDb,
  newEvent,
  setNewEvent,
  showCalendarAddEvent,
  setShowCalendarAddEvent,
  handleAddEvent,
  showCalendarTutorial,
  setShowCalendarTutorial,
  activeSubTab,
  setActiveSubTab,
  logs,
  setLogs,
  organizationalUnits,
  setOrganizationalUnits,
  newUnit,
  setNewUnit,
  newTask,
  setNewTask,
  showAddTask,
  setShowAddTask,
  newUser,
  setNewUser,
  showAddUser,
  setShowAddUser,
  taskCompletions,
  setTaskCompletions,
  notifyBale,
  announcements,
  setAnnouncements,
  newAnnouncement,
  setNewAnnouncement,
  showAddAnnouncement,
  setShowAddAnnouncement,
  handleAddMission,
  handleDeleteMission,
  handleAddTask,
  handleSendAnnouncement,
  newMission,
  setNewMission,
  showAddMission,
  setShowAddMission
}: { 
  missions: Mission[], 
  tasks: Task[], 
  users: UserProfile[], 
  content: ContentItem[],
  trackedAccounts: TrackedAccount[],
  educationItems: EducationItem[],
  observations: Observation[],
  reports: Report[],
  user: UserProfile,
  setToast: (t: {message: string, type: 'success' | 'error'} | null) => void,
  setViewingImage: (url: string | null) => void,
  integrations: any,
  setIntegrations: (i: any) => void,
  botConfig: BotConfig,
  setBotConfig: (b: BotConfig) => void,
  setTasks: (t: Task[]) => void,
  setUsers: (u: UserProfile[]) => void,
  setMissions: (m: Mission[]) => void,
  taskCompletions: any[],
  setTaskCompletions: (c: any[]) => void,
  setObservations: (o: Observation[]) => void,
  setReports: (r: Report[]) => void,
  setTrackedAccounts: (a: TrackedAccount[]) => void,
  setEducationItems: (e: EducationItem[]) => void,
  onShare: (i: ContentItem) => void,
  dailyPlans: CalendarEvent[],
  setDailyPlans: (p: CalendarEvent[]) => void,
  onTabChange: (t: any) => void,
  onAddUser: () => void,
  onAddEvent: (date?: string) => void,
  onAddMission: () => void,
  onAddTask: () => void,
  updateDb: (path: string, value: any) => Promise<void>,
  newEvent: any,
  setNewEvent: (e: any) => void,
  showCalendarAddEvent: {date: string} | null,
  setShowCalendarAddEvent: (e: {date: string} | null) => void,
  handleAddEvent: () => Promise<void>,
  showCalendarTutorial: boolean,
  setShowCalendarTutorial: (s: boolean) => void,
  activeSubTab: string,
  setActiveSubTab: (s: string) => void,
  logs: any[],
  setLogs: (l: any[]) => void,
  organizationalUnits: OrganizationalUnit[],
  setOrganizationalUnits: (u: OrganizationalUnit[]) => void,
  newUnit: any,
  setNewUnit: (u: any) => void,
  newTask: any,
  setNewTask: (t: any) => void,
  showAddTask: any,
  setShowAddTask: (s: any) => void,
  newUser: any,
  setNewUser: (u: any) => void,
  showAddUser: boolean,
  setShowAddUser: (s: boolean) => void,
  notifyBale: (text: string, chatId?: string) => Promise<void>,
  announcements: Announcement[],
  setAnnouncements: (a: Announcement[]) => void,
  newAnnouncement: any,
  setNewAnnouncement: (a: any) => void,
  showAddAnnouncement: boolean,
  setShowAddAnnouncement: (s: boolean) => void,
  handleAddMission: () => Promise<void>,
  handleDeleteMission: (id: string) => Promise<void>,
  handleAddTask: () => Promise<void>,
  handleSendAnnouncement: () => Promise<void>,
  newMission: any,
  setNewMission: (m: any) => void,
  showAddMission: boolean,
  setShowAddMission: (s: boolean) => void
}) => {
  const [loading, setLoading] = useState(false);
  
  const [activityLogs, setActivityLogs] = useState([
    { id: 1, action: 'تایید وظیفه', user: 'مدیر کل', time: '۱۰ دقیقه پیش', target: 'وظیفه #۱۲۳' },
    { id: 2, action: 'افزودن ماموریت', user: 'مدیر واحد', time: '۱ ساعت پیش', target: 'ماموریت روزانه' },
    { id: 3, action: 'تغییر نقش کاربر', user: 'مدیر کل', time: '۳ ساعت پیش', target: 'علی محمدی' },
  ]);
  
  const [showAddAccount, setShowAddAccount] = useState(false);
  const [newAccount, setNewAccount] = useState({ handle: '', name: '', platform: 'twitter' as any, category: 'enemy' as any });

  const [showAddSale, setShowAddSale] = useState(false);
  const [newSale, setNewSale] = useState({ title: '', amount: '' });

  const [showAddEducation, setShowAddEducation] = useState(false);
  const [newEducation, setNewEducation] = useState({ title: '', description: '', coverImage: '' });

  const [showAddContent, setShowAddContent] = useState(false);
  const [showRejectTask, setShowRejectTask] = useState<{ missionId: string, taskId: string } | null>(null);
  const [rejectFeedback, setRejectFeedback] = useState('');
  const [editingMission, setEditingMission] = useState<Mission | null>(null);
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [editingContent, setEditingContent] = useState<ContentItem | null>(null);
  const [editingEducation, setEditingEducation] = useState<EducationItem | null>(null);
  const [showAddSession, setShowAddSession] = useState<{ itemId: string } | null>(null);
  const [newSession, setNewSession] = useState<any>({ title: '', type: 'video', content: '' });
  const [editingSession, setEditingSession] = useState<{ itemId: string, session: any } | null>(null);
  const [showAddReport, setShowAddReport] = useState(false);
  const [newReport, setNewReport] = useState<any>({ title: '', content: '', author: '', status: 'draft', category: 'social', tags: [] });
  const [newContent, setNewContent] = useState<any>({ title: '', content: '', platform: 'twitter', category: 'social' });
  const [taskFilterPlatform, setTaskFilterPlatform] = useState<string>('all');
  const [taskFilterStatus, setTaskFilterStatus] = useState<string>('all');
  const [selectedAdminMissionId, setSelectedAdminMissionId] = useState<string | null>(null);
  const strategicScore = Math.round((tasks.filter(t => t.status === 'completed').length / (tasks.length || 1)) * 100);

  const handleApproveTask = async (task: Task) => {
    if (!confirm('آیا از تایید این وظیفه و به‌روزرسانی وضعیت ماموریت اطمینان دارید؟')) return;
    const updatedTasks = tasks.map(t => t.id === task.id ? { ...t, status: 'completed' as any } : t);
    setTasks(updatedTasks);
    await updateDb('operations.tasks', updatedTasks);

    // Update completions explicitly if they exist
    const updatedCompletions = taskCompletions.map(c => c.taskId === task.id ? { ...c, status: 'verified' } : c);
    setTaskCompletions(updatedCompletions);
    try {
      await updateDb('operations.completions', updatedCompletions);
    } catch (e) {
      console.warn('Completions sync failed');
    }

    // Check if the associated mission is now fully completed
    const missionId = task.missionId;
    const missionTasks = updatedTasks.filter(t => t.missionId === missionId);
    const isMissionFullyCompleted = missionTasks.every(t => t.status === 'completed');

    if (isMissionFullyCompleted) {
      const updatedMissions = missions.map(m => m.id === missionId ? { ...m, isCompleted: true, isArchived: true } : m);
      setMissions(updatedMissions);
      await updateDb('operations.missions', updatedMissions);
    }

    // Award points to user
    const targetUser = users.find(u => u.uid === task.completedBy);
    if (targetUser) {
      const updatedUser: UserProfile = {
        ...targetUser,
        points: targetUser.points + task.points,
        completedMissions: targetUser.completedMissions + 1,
        level: Math.floor((targetUser.points + task.points) / 1000) + 1
      };
      const updatedUsers = users.map(u => u.uid === targetUser.uid ? updatedUser : u);
      setUsers(updatedUsers);
      await updateDb('auth.users', updatedUsers);

      // Notify User via Bale
      if (targetUser.baleNotificationsEnabled && targetUser.baleId) {
        notifyBale(`✅ مأموریت تایید شد!\n🎯 مأموریت: ${task.title}\n💎 امتیاز دریافت شد: ${task.points}\n🔥 سطح جدید شما: ${updatedUser.level}`, targetUser.baleId);
      }
    }
  };

  const handleRejectTask = async () => {
    if (!showRejectTask) return;
    const updatedTasks = tasks.map(t => t.id === showRejectTask.taskId ? { ...t, status: 'rejected' as any, adminFeedback: rejectFeedback || '' } : t);
    setTasks(updatedTasks);
    await updateDb('operations.tasks', updatedTasks);

    // Update completions
    const updatedCompletions = taskCompletions.map(c => c.taskId === showRejectTask.taskId ? { ...c, status: 'rejected' } : c);
    setTaskCompletions(updatedCompletions);
    try {
      await updateDb('operations.completions', updatedCompletions);
    } catch (e) {
      console.warn('Completions sync failed');
    }

    // Notify User via Bale
    const task = tasks.find(t => t.id === showRejectTask.taskId);
    if (task) {
      const targetUser = users.find(u => u.uid === task.completedBy);
      if (targetUser?.baleNotificationsEnabled && targetUser?.baleId) {
        notifyBale(`❌ مأموریت رد شد\n🎯 مأموریت: ${task.title}\n💬 بازخورد مدیر: ${rejectFeedback || 'عدم رعایت دستورالعمل'}`, targetUser.baleId);
      }
    }

    setShowRejectTask(null);
    setRejectFeedback('');
  };









  const handleDeleteTask = async (id: string) => {
    await updateDb('operations.tasks', tasks.filter(t => t.id !== id));
  };

  const handleEditMission = async () => {
    if (!editingMission) return;
    const updatedMissions = missions.map(m => m.id === editingMission.id ? editingMission : m);
    await updateDb('operations.missions', updatedMissions);
    setEditingMission(null);
  };

  const handleAddUser = async () => {
    if (!newUser.name || !newUser.phone || !newUser.password) {
      setToast({ message: 'لطفا تمامی فیلدها از جمله رمز عبور را وارد کنید', type: 'error' });
      return;
    }
    const userObj: UserProfile = {
      uid: `u-${Date.now()}`,
      name: newUser.name,
      phone: newUser.phone,
      password: newUser.password,
      role: newUser.role,
      unitId: newUser.unitId || undefined,
      departments: newUser.departments,
      points: 0,
      level: 1,
      completedMissions: 0,
      createdAt: new Date().toISOString(),
      rank: newUser.role === 'admin' ? 'مدیر کل ستادی' : newUser.role === 'manager' ? 'مدیر واحد عملیاتی' : 'افسر همکار'
    };
    
    try {
      const res = await fetch('/api/users/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userObj)
      });
      if (res.ok) {
        setUsers([...users, userObj]);
        setShowAddUser(false);
        setNewUser({ name: '', phone: '', password: '', role: 'user', unitId: '', departments: [] });
        setToast({ message: 'کاربر جدید با موفقیت در سلسله‌مراتب ثبت شد', type: 'success' });
      } else {
        throw new Error();
      }
    } catch (err) {
      setToast({ message: 'خطا در ثبت کاربر. دوباره تلاش کنید', type: 'error' });
    }
  };

  const handleEditUser = async () => {
    if (!editingUser) return;
    const updatedUsers = users.map(u => u.uid === editingUser.uid ? editingUser : u);
    await updateDb('auth.users', updatedUsers);
    setEditingUser(null);
  };

  const handleEditContent = async () => {
    if (!editingContent) return;
    const updatedContent = content.map(c => c.id === editingContent.id ? editingContent : c);
    await updateDb('content.library', updatedContent);
    setEditingContent(null);
  };

  const handleEditEducation = async () => {
    if (!editingEducation) return;
    const updatedEducation = educationItems.map(e => e.id === editingEducation.id ? editingEducation : e);
    await updateDb('education.items', updatedEducation);
    setEditingEducation(null);
  };

  const handleAddEducation = async () => {
    if (!newEducation.title) return;
    const education = {
      ...newEducation,
      id: `edu-${Date.now()}`,
      sessions: [],
      createdAt: new Date().toISOString()
    };
    await updateDb('education.items', [...educationItems, education]);
    setShowAddEducation(false);
    setNewEducation({ title: '', description: '', coverImage: '' });
  };

  const handleAddSession = async () => {
    if (!showAddSession || !newSession.title) return;
    const session = {
      ...newSession,
      id: `sess-${Date.now()}`
    };
    const updatedItems = educationItems.map(item => 
      item.id === showAddSession.itemId 
      ? { ...item, sessions: [...item.sessions, session] } 
      : item
    );
    await updateDb('education.items', updatedItems);
    setShowAddSession(null);
    setNewSession({ title: '', type: 'video', content: '' });
  };

  const handleEditSession = async () => {
    if (!editingSession || !editingSession.session.title) return;
    const updatedItems = educationItems.map(item => 
      item.id === editingSession.itemId 
      ? { 
          ...item, 
          sessions: item.sessions.map(s => s.id === editingSession.session.id ? editingSession.session : s) 
        } 
      : item
    );
    await updateDb('education.items', updatedItems);
    setEditingSession(null);
  };

  return (
    <div className="flex flex-col h-full pb-24">

      <div className="bg-tg-surface border-b border-tg-border p-4 flex justify-between items-center transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Shield size={18} className="text-white" />
          </div>
          <div>
            <h2 className="text-xs font-black uppercase tracking-widest">قرارگاه عملیاتی</h2>
            <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">مرکز فرماندهی عملیاتی نسخه ۳.۰</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex flex-col items-end">
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 glow-point" />
              <span className="text-[9px] font-black text-emerald-500 uppercase tracking-tighter">سیستم آنلاین</span>
            </div>
            <p className="text-[8px] font-bold text-slate-500 ltr">127.0.0.1:3000</p>
          </div>
        </div>
      </div>

      <div className="flex bg-tg-surface border-b border-tg-border sticky top-0 z-10 overflow-x-auto no-scrollbar p-1 gap-1 transition-colors">
        {[
          { id: 'overview', label: 'پیشخوان استراتژیک', icon: <LayoutDashboard size={16} /> },
          { id: 'schedule', label: 'برنامه‌ریزی آتی', icon: <CalendarDays size={16} /> },
          { id: 'missions', label: 'ماموریت‌ها', icon: <Target size={16} /> },
          { id: 'tasks', label: 'مدیریت وظایف', icon: <ClipboardList size={16} /> },
          { id: 'approvals', label: `تاییدات (${tasks.filter(t => t.status === 'submitted').length})`, icon: <ShieldAlert size={16} /> },
          { id: 'users', label: 'کاربران', icon: <Users size={16} /> },
          { id: 'tracking', label: 'رصد هوشمند', icon: <ScanEye size={16} /> },
          { id: 'monitoring', label: 'پایش آنلاین', icon: <MonitorDot size={16} /> },
          { id: 'observations', label: 'مشاهدات', icon: <Eye size={16} /> },
          { id: 'reports', label: 'گزارشات مکتوب', icon: <FileSpreadsheet size={16} /> },
          { id: 'education', label: 'آموزش', icon: <GraduationCap size={16} /> },
          { id: 'logs', label: 'لاگ‌ها', icon: <History size={16} /> },
          { id: 'settings', label: 'تنظیمات کلان', icon: <Settings size={16} /> },
          { id: 'integrations', label: 'اتصالات سرویس/API', icon: <Zap size={16} /> },
          { id: 'bot', label: 'مدیریت ربات', icon: <Bot size={16} /> },
          { id: 'units', label: 'مدیریت ساختار', icon: <LayoutGrid size={16} /> }
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)} 
            className={`flex items-center gap-2 px-4 py-2.5 text-[10px] font-black rounded-xl shrink-0 transition-all border ${
              activeSubTab === tab.id 
              ? 'bg-tg-accent text-white border-blue-400 shadow-lg shadow-blue-500/20' 
              : 'text-tg-text-muted border-transparent hover:bg-black/5'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {activeSubTab === 'overview' && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-500">
            {/* Header Strategic Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-tg-accent p-8 rounded-[3rem] text-white relative shadow-2xl shadow-blue-900/10 transition-all">
                <div className="relative z-10 flex flex-col h-full justify-between gap-8">
                  <div className="space-y-4">
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 rounded-full border border-white/20 backdrop-blur-md">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-[8px] font-black uppercase tracking-widest text-emerald-400">سیستم مدیریت عملیات (نسخه پیشرفته)</span>
                    </div>
                    <h2 className="text-4xl font-black tracking-tighter leading-none">پیشخوان استراتژیک <br/><span className="brightness-125">مرکز عملیات</span></h2>
                    <p className="text-[11px] font-medium opacity-80 leading-relaxed max-w-sm">
                      تحلیل هوشمند داده‌های عملیاتی، مدیریت منابع انسانی و پایش لحظه‌ای فضای مجازی برای تبیین دستاوردهای نظام.
                    </p>
                  </div>

                  <div className="flex gap-4">
                    <button 
                      onClick={() => onAddMission?.()}
                      className="px-6 py-3 bg-white text-black rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-white/5 active:scale-95 transition-all flex items-center gap-2"
                    >
                      <Plus size={14} />
                      تعریف عملیات جدید
                    </button>
                    <button 
                      onClick={() => onTabChange?.('calendar')}
                      className="px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2"
                    >
                      <Calendar size={14} />
                      برنامه زمانی
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-tg-surface p-8 rounded-[3rem] border border-tg-border flex flex-col items-center justify-center text-center space-y-6 relative overflow-hidden group transition-colors shadow-sm">
                <div className="absolute inset-0 bg-grid-white/[0.02] mask-image-b" />
                
                {/* White Line Progress */}
                <div className="w-full space-y-4">
                  <div className="relative h-2 w-full bg-black/5 dark:bg-white/5 rounded-full overflow-hidden border border-tg-border">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(100, (user?.points || 0) / 10000 * 100)}%` }}
                      className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-600 to-emerald-400"
                    />
                  </div>
                  <div className="flex justify-between items-center px-1">
                    <span className="text-[9px] font-black text-tg-text-muted uppercase tracking-widest">وضعیت اشتراک ویژه</span>
                    <span className="text-[9px] font-black text-tg-text">{user?.points || 0} / ۱۰۰۰۰ امتیاز</span>
                  </div>
                  {user && user.points >= 10000 ? (
                    <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-center gap-2">
                      <ShieldCheck size={14} className="text-emerald-500" />
                      <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">اشتراک فعال (اینترنت نامحدود)</span>
                    </div>
                  ) : (
                    <p className="text-[8px] text-tg-text-muted font-bold leading-tight px-2">
                       {10000 - (user?.points || 0)} امتیاز تا فعال‌سازی خودکار دسترسی به اینترنت آزاد و خط سفید.
                    </p>
                  )}
                </div>

                <div className="relative pt-4 border-t border-tg-border w-full">
                  <div className="flex items-center justify-center gap-6">
                    <div className="text-center">
                      <p className="text-xl font-black text-tg-text">{strategicScore}٪</p>
                      <p className="text-[7px] font-black text-tg-text-muted uppercase tracking-widest">آمادگی کل</p>
                    </div>
                    <div className="w-[1px] h-8 bg-tg-border" />
                    <div className="text-center">
                      <p className="text-xl font-black text-blue-500">{users.length}</p>
                      <p className="text-[7px] font-black text-tg-text-muted uppercase tracking-widest">کارشناسان فعال</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Graphical Shortcuts Section */}
            <div className="space-y-4">
              <h3 className="text-[10px] font-black text-tg-text-muted uppercase tracking-[0.2em] px-2">میانبرهای مدیریتی (Quick Access)</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {[
                  { label: 'ثبت کاربر', icon: UserPlus, color: 'emerald', action: () => onAddUser?.() },
                  { label: 'انتشار محتوا', icon: Plus, color: 'blue', action: () => onAddTask?.() },
                  { label: 'اعلان سراسری', icon: Megaphone, color: 'red', action: () => onSendAnnouncement?.() },
                  { label: 'ثبت رویداد', icon: Calendar, color: 'purple', action: () => onAddEvent?.() },
                  { label: 'ربات هوشمند', icon: Send, color: 'indigo', action: () => setActiveSubTab('bot') },
                ].map((item, i) => (
                  <motion.button
                    whileHover={{ y: -4 }}
                    whileTap={{ scale: 0.95 }}
                    key={i}
                    onClick={item.action}
                    className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border flex flex-col items-center text-center space-y-3 hover:border-blue-500/30 transition-all shadow-lg group"
                  >
                    <div className={`w-12 h-12 rounded-2xl bg-${item.color}-500/10 text-${item.color}-500 flex items-center justify-center group-hover:bg-${item.color}-500 group-hover:text-white transition-all`}>
                      <item.icon size={20} />
                    </div>
                    <span className="text-[10px] font-black text-tg-text">{item.label}</span>
                  </motion.button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                   <StatCard icon={Users} label="کاربران" value={users.length.toString()} color="text-blue-500" />
                   <StatCard icon={CheckCircle2} label="وظایف انجام شده" value={tasks.filter(t => t.status === 'completed').length.toString()} color="text-emerald-500" />
                   <StatCard icon={Target} label="ماموریت‌ها" value={missions.length.toString()} color="text-amber-500" />
                   <StatCard icon={Trophy} label="امتیاز کل واحد" value={users.reduce((acc, u) => acc + u.points, 0).toLocaleString('fa-IR')} color="text-purple-500" />
                </div>
              </div>
            </div>

            {showAddAnnouncement && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-tg-surface p-6 rounded-[2.5rem] border border-red-500/30 space-y-4 shadow-2xl shadow-red-500/10"
              >
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-black text-red-500 uppercase tracking-widest border-b border-white/5 pb-2">ایجاد اعلان سراسری (Broadcast)</h4>
                    <input 
                      placeholder="عنوان خبر یا اطلاعیه" 
                      className="tg-input bg-black/20 border-white/5 focus:border-red-500/50" 
                      value={newAnnouncement.title} 
                      onChange={e => setNewAnnouncement({...newAnnouncement, title: e.target.value})} 
                    />
                    <textarea 
                      placeholder="متن کامل پیام جهت ارسال به بله و نمایش در استودیو..." 
                      className="tg-input bg-black/20 border-white/5 focus:border-red-500/50 min-h-[120px]" 
                      value={newAnnouncement.content} 
                      onChange={e => setNewAnnouncement({...newAnnouncement, content: e.target.value})} 
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-slate-500 uppercase px-2">نوع پیام</label>
                      <select 
                        className="tg-input bg-black/20 border-white/5 focus:border-red-500/50" 
                        value={newAnnouncement.type} 
                        onChange={e => setNewAnnouncement({...newAnnouncement, type: e.target.value as any})}
                      >
                        <option value="info">اطلاع‌رسانی (Info)</option>
                        <option value="warning">هشدار (Warning)</option>
                        <option value="critical">فوری/بسیار مهم (Critical)</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-3 pt-5 px-2">
                        <input 
                          type="checkbox" 
                          id="announcement-public"
                          className="w-4 h-4 rounded bg-black/20 border-white/5 text-red-500"
                          checked={newAnnouncement.isPublic}
                          onChange={e => setNewAnnouncement({...newAnnouncement, isPublic: e.target.checked})}
                        />
                        <label htmlFor="announcement-public" className="text-[10px] font-black text-tg-text uppercase">نمایش عمومی در استودیو</label>
                      </div>
                  </div>
                </div>
                <div className="flex gap-3 pt-2">
                  <button 
                    onClick={handleSendAnnouncement} 
                    className="flex-1 py-4 bg-red-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-red-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                  >
                    <Send size={14} />
                    ارسال به تمامی کانال‌ها
                  </button>
                  <button 
                    onClick={() => setShowAddAnnouncement(false)} 
                    className="flex-1 py-4 bg-white/5 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all"
                  >
                    انصراف
                  </button>
                </div>
              </motion.div>
            )}

            {/* Strategic Score Analysis */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6 flex flex-col">
                <div className="bg-tg-surface rounded-[2.5rem] p-8 border border-tg-border relative overflow-hidden flex-1 min-h-[350px] transition-colors">
                  <div className="flex justify-between items-center mb-8">
                    <h3 className="font-black text-sm flex items-center gap-3 text-tg-text">
                      <BarChart3 size={20} className="text-blue-500" />
                      توزیع عملیات در پلتفرم‌ها
                    </h3>
                  </div>
                  <div className="h-[250px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={[
                            { name: 'توییتر', value: tasks.filter(t => t.platform === 'twitter').length },
                            { name: 'اینستاگرام', value: tasks.filter(t => t.platform === 'instagram').length },
                            { name: 'بله', value: tasks.filter(t => t.platform === 'bale').length },
                          ]}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          paddingAngle={8}
                          dataKey="value"
                        >
                          {['#3b82f6', '#ec4899', '#10b981'].map((color, index) => (
                            <Cell key={`cell-${index}`} fill={color} stroke="none" />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ background: 'var(--tg-surface)', border: '1px solid var(--tg-border)', borderRadius: '1rem', fontSize: '10px', color: 'var(--tg-text)' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex justify-center gap-6 mt-4">
                    {['توییتر', 'اینستاگرام', 'بله'].map((name, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${i === 0 ? 'bg-blue-500' : i === 1 ? 'bg-pink-500' : 'bg-emerald-500'}`} />
                        <span className="text-[10px] font-black text-tg-text">{name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-tg-surface rounded-[3rem] p-8 border border-tg-border flex flex-col space-y-6 shadow-xl relative overflow-hidden group transition-colors">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-amber-500/10 transition-all duration-500" />
                  <h4 className="text-xs font-black text-tg-text flex items-center gap-3 relative z-10">
                    <Trophy size={18} className="text-amber-500 animate-bounce" />
                    نخبگان عملیاتی (Top 5)
                  </h4>
                  <div className="space-y-4 relative z-10">
                    {[...users].sort((a, b) => b.points - a.points).slice(0, 5).map((u, i) => (
                      <motion.div 
                        key={u.uid}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className={`flex items-center gap-4 p-3 rounded-2xl border transition-all group/item ${
                          i === 0 ? 'bg-amber-500/10 border-amber-500/30 ring-1 ring-amber-500/20' : 'bg-black/5 dark:bg-white/5 border-tg-border hover:bg-tg-border transition-colors'
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-[10px] font-black transition-transform group-hover/item:scale-110 ${
                          i === 0 ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/40' :
                          i === 1 ? 'bg-black/20 dark:bg-white/20 text-tg-text' :
                          i === 2 ? 'bg-orange-600 text-white' :
                          'bg-black/20 dark:bg-white/5 text-tg-text-muted border border-tg-border'
                        }`}>
                          {i + 1}
                        </div>
                        <div className="flex-1">
                          <p className="text-[10px] font-black text-tg-text group-hover/item:text-blue-500 transition-colors">{u.name}</p>
                          <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">{u.rank}</p>
                        </div>
                        <div className="text-right">
                          <p className={`text-[10px] font-black ${i === 0 ? 'text-amber-500' : 'text-blue-500'}`}>{u.points.toLocaleString('fa-IR')}</p>
                          <p className="text-[7px] font-black text-tg-text-muted uppercase">امتیاز</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  <button 
                    onClick={() => setActiveSubTab('users')}
                    className="w-full py-3 bg-black/5 dark:bg-white/5 hover:bg-tg-border rounded-2xl text-[9px] font-black text-tg-text-muted hover:text-tg-text uppercase tracking-widest transition-all relative z-10"
                  >
                    مشاهده تالار افتخارات
                  </button>
                </div>
              </div>
            </div>

              <div className="bg-tg-surface rounded-[3rem] p-8 border border-tg-border flex flex-col space-y-6 transition-colors">
                <h4 className="text-xs font-black text-tg-text flex items-center gap-3">
                  <History size={18} className="text-amber-500" />
                  آخرین فعالیت‌های ستادی
                </h4>
                <div className="flex-1 space-y-4">
                  {activityLogs.slice(0, 5).map((log, i) => (
                    <div key={i} className="flex gap-4 items-start pb-4 border-b border-tg-border last:border-0">
                      <div className="w-8 h-8 rounded-xl bg-black/5 dark:bg-white/5 flex items-center justify-center text-tg-text-muted mt-1">
                        <Terminal size={14} />
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-tg-text leading-tight">{log.action}</p>
                        <p className="text-[9px] text-tg-text-muted font-bold uppercase">{log.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <button 
                  onClick={() => setActiveSubTab('logs')}
                  className="w-full py-3 bg-black/5 dark:bg-white/5 hover:bg-tg-border rounded-2xl text-[9px] font-black text-tg-text-muted uppercase tracking-widest transition-all"
                >
                  مشاهده تمام لاگ‌ها
                </button>
              </div>
            </div>
        )}

        {activeSubTab === 'logs' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black">پایش برخط عملیات (System Logs)</h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">رصد لحظه‌ای فعالیت‌های کادر فرماندهی و افسران</p>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => setLogs([])}
                  className="bg-red-500/10 text-red-500 px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest border border-red-500/20 active:scale-95 transition-all flex items-center gap-2"
                >
                  <Trash2 size={14} />
                  پاکسازی لاگ‌ها
                </button>
              </div>
            </div>

            <div className="bg-tg-surface rounded-[2.5rem] border border-tg-border overflow-hidden shadow-2xl transition-colors">
              <div className="p-1 border-b border-tg-border bg-black/5 dark:bg-black/20 flex gap-1">
                {['all', 'USER_UPSERT', 'TASK_COMPLETION', 'DATA_UPDATE'].map(type => (
                  <button 
                    key={type}
                    className="px-4 py-2 text-[8px] font-black text-tg-text-muted hover:text-tg-text transition-all uppercase tracking-widest"
                  >
                    {type === 'all' ? 'همه لاگ‌ها' : type}
                  </button>
                ))}
              </div>
              <div className="max-h-[600px] overflow-y-auto p-4 space-y-4">
                {Array.isArray(logs) && logs.length > 0 ? (
                  [...logs].reverse().map((log, i) => (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      key={i} 
                      className="flex gap-4 group"
                    >
                      <div className="flex flex-col items-center">
                        <div className={`w-10 h-10 rounded-2xl flex items-center justify-center border border-tg-border shadow-lg ${
                          log.action === 'USER_UPSERT' ? 'bg-blue-500/20 text-blue-500 border-blue-500/30' :
                          log.action === 'TASK_COMPLETION' ? 'bg-emerald-500/20 text-emerald-500 border-emerald-500/30' :
                          'bg-black/5 dark:bg-slate-800 text-tg-text-muted'
                        }`}>
                          {log.action === 'USER_UPSERT' ? <UserPlus size={18} /> :
                           log.action === 'TASK_COMPLETION' ? <CheckCircle size={18} /> :
                           <Terminal size={18} />}
                        </div>
                        <div className="w-0.5 h-full bg-tg-border mt-2 group-last:hidden" />
                      </div>
                      <div className="flex-1 pb-6">
                        <div className="bg-black/5 dark:bg-black/20 border border-tg-border p-4 rounded-3xl group-hover:border-blue-500/30 transition-all">
                          <div className="flex justify-between items-start mb-2">
                             <h4 className="text-[11px] font-black text-tg-text">{log.action}</h4>
                             <span className="text-[8px] font-black text-tg-text-muted font-mono tracking-tighter" dir="ltr">{new Date(log.timestamp).toLocaleString('fa-IR')}</span>
                          </div>
                          <div className="p-3 bg-white/5 rounded-2xl text-[9px] font-mono text-tg-text-muted overflow-x-auto" dir="ltr">
                            {JSON.stringify(log.data, null, 2)}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="text-center py-20 opacity-30">
                    <History size={48} className="mx-auto mb-4" />
                    <p className="text-xs font-black">هیچ فعالیتی ثبت نشده است</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'schedule' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black">مدیریت رزم‌نامه (برنامه‌ریزی)</h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">برنامه‌ریزی بلندمدت و کوتاه‌مدت عملیاتی</p>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => onAddEvent?.()}
                  className="bg-emerald-500 text-white px-4 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-500/20 active:scale-95 transition-all flex items-center gap-2"
                >
                  <Plus size={14} />
                  ایجاد برنامه جدید
                </button>
                <button 
                  onClick={() => { onTabChange?.('calendar'); }}
                  className="bg-white/5 text-slate-400 px-4 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-white/5 hover:bg-white/10 transition-all flex items-center gap-2"
                >
                  <Calendar size={14} />
                  تقویم شمسی
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1 space-y-6">
                <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border shadow-xl relative overflow-hidden transition-colors">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-purple-500" />
                  <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6 px-1">آمار برنامه‌های جاری</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-3xl border border-white/5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500">
                          <Zap size={16} />
                        </div>
                        <span className="text-[11px] font-black">عملیاتی</span>
                      </div>
                      <span className="text-sm font-black">{dailyPlans.filter(p => p.type === 'operation').length}</span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-3xl border border-white/5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500">
                          <GraduationCap size={16} />
                        </div>
                        <span className="text-[11px] font-black">آموزشی</span>
                      </div>
                      <span className="text-sm font-black">{dailyPlans.filter(p => p.type === 'training').length}</span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-3xl border border-white/5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-500">
                          <Users size={16} />
                        </div>
                        <span className="text-[11px] font-black">جلسات</span>
                      </div>
                      <span className="text-sm font-black">{dailyPlans.filter(p => p.type === 'other').length}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border shadow-xl transition-colors">
                   <h3 className="text-xs font-black mb-4 text-tg-text">میانبرهای سریع تقویم</h3>
                   <div className="grid grid-cols-2 gap-3">
                      <button onClick={() => onAddEvent?.()} className="p-4 bg-black/5 dark:bg-white/5 rounded-3xl border border-tg-border hover:border-blue-500/30 transition-all text-center space-y-2">
                        <div className="w-8 h-8 bg-blue-500/10 text-blue-500 rounded-xl flex items-center justify-center mx-auto"><Plus size={16}/></div>
                        <span className="text-[9px] font-black text-tg-text">افزودن رویداد</span>
                      </button>
                      <button onClick={() => onTabChange?.('calendar')} className="p-4 bg-black/5 dark:bg-white/5 rounded-3xl border border-tg-border hover:border-purple-500/30 transition-all text-center space-y-2">
                        <div className="w-8 h-8 bg-purple-500/10 text-purple-500 rounded-xl flex items-center justify-center mx-auto"><Calendar size={16}/></div>
                        <span className="text-[9px] font-black text-tg-text">پنل تقویم</span>
                      </button>
                   </div>
                </div>
              </div>

              <div className="lg:col-span-2 bg-tg-surface rounded-[2.5rem] border border-tg-border shadow-2xl p-6 relative transition-colors">
                 <div className="absolute inset-0 bg-grid-white/5 mask-image-b" />
                 <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6 relative z-10 px-1">لیست رویدادهای رزم‌نامه</h4>
                 <div className="space-y-3 relative z-10 overflow-y-auto max-h-[600px] no-scrollbar pr-1">
                    {dailyPlans.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map((plan, idx) => (
                      <motion.div 
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        key={plan.id} 
                        className="p-5 bg-tg-surface/50 rounded-[2rem] border border-tg-border flex items-center justify-between group hover:border-blue-500/30 transition-all shadow-lg"
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl shadow-xl ${
                            plan.type === 'training' ? 'bg-amber-500/10 text-amber-500 shadow-amber-500/5' :
                             plan.type === 'mission' ? 'bg-red-500/10 text-red-500 shadow-red-500/5' : 'bg-blue-500/10 text-blue-500 shadow-blue-500/5'
                           }`}>
                             {plan.type === 'training' ? <GraduationCap size={24} /> :
                              plan.type === 'mission' ? <Zap size={24} /> : <Calendar size={24} />}
                           </div>
                           <div>
                             <div className="flex items-center gap-2">
                               <h5 className="font-black text-sm text-tg-text">{plan.title}</h5>
                               <span className={`text-[7px] font-black uppercase px-2 py-0.5 rounded-full ${
                                 plan.type === 'training' ? 'bg-amber-500/10 text-amber-500' :
                                 plan.type === 'mission' ? 'bg-red-500/10 text-red-500' : 'bg-blue-500/10 text-blue-500'
                               }`}>{plan.type}</span>
                             </div>
                             <div className="flex items-center gap-3 mt-1.5">
                               <div className="flex items-center gap-1">
                                 <CalendarDays size={10} className="text-tg-text-muted" />
                                 <span className="text-[10px] font-black text-tg-text-muted ltr">{plan.date}</span>
                               </div>
                               <div className="flex items-center gap-1">
                                 <Clock size={10} className="text-tg-text-muted" />
                                 <span className="text-[10px] font-black text-tg-text-muted ltr">{plan.time}</span>
                               </div>
                             </div>
                           </div>
                         </div>
                         <div className="flex gap-2">
                           <button 
                             onClick={async () => {
                               if (confirm('آیا از حذف این رویداد اطمینان دارید؟')) {
                                 const updated = dailyPlans.filter(p => p.id !== plan.id);
                                 setDailyPlans(updated);
                                 await updateDb('calendar.events', updated);
                               }
                             }}
                             className="w-10 h-10 bg-black/5 dark:bg-white/5 hover:bg-red-500/10 text-tg-text-muted hover:text-red-500 rounded-xl flex items-center justify-center transition-all border border-tg-border opacity-0 group-hover:opacity-100 shadow-sm"
                           >
                             <Trash2 size={16} />
                           </button>
                         </div>
                       </motion.div>
                     ))}
                     {dailyPlans.length === 0 && (
                       <div className="text-center py-20 bg-tg-surface rounded-[2.5rem] border border-dashed border-tg-border space-y-4 shadow-sm">
                         <div className="w-16 h-16 bg-black/5 dark:bg-white/5 rounded-full flex items-center justify-center mx-auto text-tg-text-muted border border-tg-border">
                           <Calendar size={32} />
                         </div>
                         <p className="text-xs font-black text-tg-text-muted">هیچ رویدادی در رزم‌نامه ثبت نشده است.</p>
                       </div>
                     )}
                 </div>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'integrations' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-[#1a237e] to-[#2481cc] p-10 rounded-[3.5rem] text-white space-y-8 relative overflow-hidden shadow-2xl shadow-blue-900/40">
              <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/10 rounded-full blur-[80px] translate-y-1/2 -translate-x-1/2" />
              
              <div className="flex justify-between items-start relative">
                <div className="space-y-3">
                  <div className="flex items-center gap-3 px-4 py-1.5 bg-white/20 rounded-full w-fit backdrop-blur-md border border-white/20">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse glow-point" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">پل ارتباطی فعال (سطح دسترسی الف)</span>
                  </div>
                  <h3 className="text-3xl font-black tracking-tight text-white">مرکز تبادل داده سامانه</h3>
                  <p className="text-[12px] font-medium opacity-80 leading-relaxed max-w-md text-white">
                    مدیریت هوشمند کانال‌های ورودی و خروجی. تمامی سیگنال‌ها با پروتکل‌های پیشرفته رمزنگاری شده و مستقیماً به پیام‌رسان «بله» متصل می‌شوند.
                  </p>
                </div>
                <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-indigo-600 rounded-[2rem] flex items-center justify-center shadow-xl border border-white/20 animate-pulse transition-all">
                  <Zap size={40} className="text-white" />
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 relative">
                {[
                  { label: 'پایداری سیستم', value: '۹۹.۹۸٪', icon: Activity, color: 'text-emerald-400' },
                  { label: 'سرعت پردازش', value: '۱۲ میلی‌ثانیه', icon: Zap, color: 'text-amber-400' },
                  { label: 'کانال‌های فعال', value: '۱۴ واحد', icon: Share2, color: 'text-blue-400' },
                  { label: 'سطح امنیت', value: 'Maximum', icon: Shield, color: 'text-indigo-400' },
                ].map((stat, i) => (
                  <div key={i} className="bg-white/5 p-5 rounded-3xl backdrop-blur-xl border border-white/10 group hover:bg-white/10 transition-all">
                    <stat.icon size={20} className={`mb-3 ${stat.color} opacity-80`} />
                    <p className="text-[9px] font-black opacity-50 uppercase mb-1 tracking-widest">{stat.label}</p>
                    <p className="text-xl font-black font-mono">{stat.value}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-between items-center px-1 pt-2">
              <div className="space-y-1">
                <h3 className="text-sm font-black">مدیریت هاب‌های عملیاتی</h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">اتصالات پلتفرمی و تنظیمات ربات بله</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { id: 'bale', name: 'پیام‌رسان بله', desc: 'رابط عملیات میدانی و ارسال اعلان', icon: Send, color: 'text-emerald-500', bg: 'bg-emerald-500/10', label: 'کلید API ربات بله' },
                { id: 'storage', name: 'هاست دانلود (Storage)', desc: 'آپلود محتوا و منابع عملیاتی', icon: Download, color: 'text-blue-500', bg: 'bg-blue-500/10', label: 'آدرس PHP آپلودر' },
                { id: 'zarinpal', name: 'ZarinPal Gateway', desc: 'مدیریت و پایش پرداخت‌ها', icon: CreditCard, color: 'text-amber-500', bg: 'bg-amber-500/10', label: 'Merchant ID کد مرچنت' },
                { id: 'metamask', name: 'Web3 Gateway', desc: 'احراز هویت غیرمتمرکز', icon: ShieldCheck, color: 'text-orange-500', bg: 'bg-orange-500/10', label: 'Wallet Address / API' },
                { id: 'twitter', name: 'X Intelligence', desc: 'پایش فضای توییتر', icon: Twitter, color: 'text-blue-400', bg: 'bg-blue-400/10', label: 'X Developer Token' },
                { id: 'instagram', name: 'Visual Center', desc: 'رصد محتوای تصویری', icon: Instagram, color: 'text-pink-500', bg: 'bg-pink-500/10', label: 'Access Token' }
              ].map(service => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={service.id} 
                  className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-6 group hover:border-blue-500/30 transition-all shadow-sm transition-colors"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex gap-4">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border border-white/5 ${service.bg} ${service.color} group-hover:scale-110 transition-transform`}>
                        <service.icon size={28} />
                      </div>
                      <div>
                        <h4 className="text-xs font-black">{service.name}</h4>
                        <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest mt-1 opacity-70">{service.desc}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center pt-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${integrations[service.id as keyof typeof integrations]?.enabled ? 'bg-emerald-500 animate-pulse shadow-sm shadow-emerald-500/50' : 'bg-tg-bg border border-tg-border'}`} />
                      <span className="text-[9px] font-black text-tg-text-muted uppercase tracking-widest">
                        {integrations[service.id as keyof typeof integrations]?.enabled ? 'فعال و برخط' : 'غیرفعال'}
                      </span>
                    </div>
                    <button 
                      onClick={() => setIntegrations({...integrations, [service.id]: {...integrations[service.id as keyof typeof integrations], enabled: !integrations[service.id as keyof typeof integrations]?.enabled}})}
                      className={`w-12 h-6 rounded-full relative transition-all shadow-inner ${integrations[service.id as keyof typeof integrations]?.enabled ? 'bg-tg-accent shadow-lg shadow-tg-accent/20' : 'bg-tg-bg border border-tg-border'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${integrations[service.id as keyof typeof integrations]?.enabled ? 'right-1' : 'right-7'}`} />
                    </button>
                  </div>

                  {integrations[service.id as keyof typeof integrations]?.enabled && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-4 bg-black/20 rounded-2xl border border-white/5 space-y-3"
                    >
                      <div className="flex flex-col gap-2">
                        <label className="text-[8px] font-black text-slate-500 uppercase">کلید API پیام‌رسان بله:</label>
                        <input 
                          type="password" 
                          placeholder="Bale Bot API Token..."
                          className="w-full bg-black/40 border border-white/5 rounded-xl px-3 py-2 text-[10px] text-emerald-400 font-mono outline-none focus:border-emerald-500/50"
                          value={integrations[service.id as keyof typeof integrations]?.apiKey || ''}
                          onChange={(e) => setIntegrations({...integrations, [service.id]: {...integrations[service.id as keyof typeof integrations], apiKey: e.target.value}})}
                        />
                      </div>
                      <div className="flex justify-between items-center pt-1">
                        <span className="text-[8px] font-black text-slate-500 uppercase">شناسه اتصال:</span>
                        <span className="text-[9px] font-mono text-blue-400">CX-BALE-{service.id.toUpperCase()}</span>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              ))
              }
            </div>
          </div>
        )}

        {activeSubTab === 'reports' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-tg-surface p-6 rounded-[2rem] border border-tg-border transition-colors">
                <p className="text-[8px] font-black text-tg-text-muted uppercase mb-1">کل تسک‌های انجام شده</p>
                <p className="text-2xl font-black text-tg-text">{tasks.filter(t => t.status === 'completed').length}</p>
              </div>
              <div className="bg-tg-surface p-6 rounded-[2rem] border border-tg-border transition-colors">
                <p className="text-[8px] font-black text-tg-text-muted uppercase mb-1">امتیازات توزیع شده</p>
                <p className="text-2xl font-black text-emerald-500">{users.reduce((sum, u) => sum + u.points, 0)}</p>
              </div>
              <div className="bg-tg-surface p-6 rounded-[2rem] border border-tg-border transition-colors">
                <p className="text-[8px] font-black text-tg-text-muted uppercase mb-1">کاربران فعال (۷ روز)</p>
                <p className="text-2xl font-black text-blue-500">{users.filter(u => u.points > 0).length}</p>
              </div>
              <div className="bg-tg-surface p-6 rounded-[2rem] border border-tg-border transition-colors">
                <p className="text-[8px] font-black text-tg-text-muted uppercase mb-1">نرخ تایید عملیات</p>
                <p className="text-2xl font-black text-amber-500">
                  {tasks.length > 0 ? Math.round((tasks.filter(t => t.status === 'completed').length / tasks.length) * 100) : 0}%
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border transition-colors">
                <h4 className="text-[10px] font-black text-tg-text-muted uppercase mb-6">رتبه‌بندی واحدهای عملیاتی (Units Performance)</h4>
                <div className="space-y-4">
                  {organizationalUnits.map(unit => {
                    const unitUsers = users.filter(u => u.unitId == unit.id);
                    const unitPoints = unitUsers.reduce((sum, u) => sum + u.points, 0);
                    const unitTasks = tasks.filter(t => unitUsers.some(uu => uu.uid === t.completedBy) && t.status === 'completed').length;
                    
                    return (
                      <div key={unit.id} className="flex items-center justify-between p-4 bg-black/5 dark:bg-white/5 rounded-2xl hover:bg-tg-border transition-all group">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500 font-black text-[10px]">
                            {unit.level === 'nahiye' ? 'N' : unit.level === 'howze' ? 'H' : 'P'}
                          </div>
                          <div>
                            <input 
                              type="text" 
                              className="bg-transparent border-none p-0 text-xs font-black text-tg-text focus:ring-0 focus:outline-none w-full"
                              defaultValue={unit.name}
                              onBlur={async (e) => {
                                if (e.target.value === unit.name) return;
                                try {
                                  const res = await fetch('/api/structures/update', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ action: 'update', data: { id: unit.id, name: e.target.value } })
                                  });
                                  const result = await res.json();
                                  if (result.success) {
                                    setOrganizationalUnits(result.structures);
                                    setToast({ message: 'نام واحد با موفقیت تغییر یافت', type: 'success' });
                                  }
                                } catch (err) {
                                  setToast({ message: 'خطا در ویرایش نام', type: 'error' });
                                }
                              }}
                            />
                            <p className="text-[8px] font-bold text-tg-text-muted">{unitUsers.length} نفر فعال</p>
                          </div>
                        </div>
                        <div className="text-left">
                          <p className="text-xs font-black text-emerald-500">+{unitPoints} امتیاز</p>
                          <p className="text-[8px] font-bold text-tg-text-muted uppercase">{unitTasks} تسک تکمیل شده</p>
                        </div>
                        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity mr-2">
                          <button 
                            onClick={async (e) => {
                              e.stopPropagation();
                              if (!confirm('آیا از حذف این واحد اطمینان دارید؟')) return;
                              try {
                                const res = await fetch('/api/structures/update', {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ action: 'delete', data: { id: unit.id } })
                                });
                                const result = await res.json();
                                if (result.success) {
                                  setOrganizationalUnits(result.structures);
                                  setToast({ message: 'واحد با موفقیت حذف شد', type: 'success' });
                                }
                              } catch (err) {
                                setToast({ message: 'خطا در حذف واحد', type: 'error' });
                              }
                            }}
                            className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                  {organizationalUnits.length === 0 && (
                     <div className="text-center py-10 opacity-40 italic text-xs text-tg-text-muted">واحدی یافت نشد</div>
                  )}
                </div>
              </div>

              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border transition-colors">
                <h4 className="text-[10px] font-black text-tg-text-muted uppercase mb-6">آخرین تسک‌های تکمیل شده</h4>
                <div className="space-y-4">
                  {tasks.filter(t => t.status === 'completed').slice(-5).reverse().map(task => {
                    const user = users.find(u => u.uid === task.completedBy);
                    const mission = missions.find(m => m.id === task.missionId);
                    return (
                      <div key={task.id} className="p-4 bg-black/5 dark:bg-white/5 rounded-2xl border border-tg-border hover:border-blue-500/30 transition-all">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-lg bg-emerald-500 flex items-center justify-center">
                              <Check size={12} className="text-white" />
                            </div>
                            <p className="text-[10px] font-black text-tg-text">{mission?.title}</p>
                          </div>
                          <span className="text-[8px] font-bold text-tg-text-muted">{new Date(task.completedAt || '').toLocaleString('fa-IR')}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-[9px] font-bold text-tg-text-muted">توسط: <span className="text-tg-text">{user?.name}</span></p>
                          <span className="text-[9px] font-black text-emerald-500">+{mission?.reward || '0'} امتیاز</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}
        {activeSubTab === 'units' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black">مدیریت ساختار سازمانی (Hierarchical Structure)</h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">ایجاد ناحیه، حوزه، پایگاه و گردان</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1 space-y-6">
                <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border shadow-xl transition-colors">
                  <h4 className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest mb-6">افزودن واحد جدید</h4>
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black text-tg-text-muted uppercase">نام واحد</label>
                      <input 
                        className="tg-input text-xs" 
                        placeholder="مثلا: ناحیه مقاومت بسیج ..."
                        value={newUnit.name}
                        onChange={e => setNewUnit({...newUnit, name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-black text-slate-400 uppercase">سطح واحد</label>
                      <select 
                        className="tg-input text-xs"
                        value={newUnit.level}
                        onChange={e => setNewUnit({...newUnit, level: e.target.value as any, parentId: ''})}
                      >
                        <option value="nahiye">ناحیه (District)</option>
                        <option value="howze">حوزه (Sector)</option>
                        <option value="paygah">پایگاه (Base)</option>
                        <option value="gordan">گردان (Battalion)</option>
                      </select>
                    </div>
                    {newUnit.level !== 'nahiye' && (
                      <div className="space-y-1.5">
                        <label className="text-[9px] font-black text-slate-400 uppercase">واحد بالادستی (Parent)</label>
                        <select 
                          className="tg-input text-xs"
                          value={newUnit.parentId}
                          onChange={e => setNewUnit({...newUnit, parentId: e.target.value})}
                        >
                          <option value="">انتخاب واحد بالادستی...</option>
                          {organizationalUnits
                            .filter(u => {
                              if (newUnit.level === 'howze') return u.level === 'nahiye';
                              if (newUnit.level === 'paygah') return u.level === 'howze';
                              if (newUnit.level === 'gordan') return u.level === 'paygah';
                              return false;
                            })
                            .map(u => (
                              <option key={u.id} value={u.id}>{u.name} ({u.level})</option>
                            ))
                          }
                        </select>
                      </div>
                    )}
                    <button 
                      onClick={async () => {
                        if (!newUnit.name) return;
                        if (newUnit.level !== 'nahiye' && !newUnit.parentId) {
                          setToast({ message: 'لطفا واحد بالادستی را انتخاب کنید', type: 'error' });
                          return;
                        }
                        const unitData = {
                          name: newUnit.name,
                          level: newUnit.level,
                          parentId: newUnit.parentId || undefined,
                          createdAt: new Date().toISOString()
                        };

                        try {
                          const res = await fetch('/api/structures/update', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'add', data: unitData })
                          });
                          const result = await res.json();
                          if (result.success) {
                            setOrganizationalUnits(result.structures);
                            setNewUnit({ name: '', level: 'howze', parentId: '' });
                            setToast({ message: 'واحد جدید با موفقیت به سلسله‌مراتب اضافه شد', type: 'success' });
                          } else {
                            throw new Error();
                          }
                        } catch (err) {
                          setToast({ message: 'خطا در ارتباط با سرور', type: 'error' });
                        }
                      }}
                      className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
                    >
                      ثبت واحد در ساختار
                    </button>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-2 space-y-6">
                <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border shadow-xl min-h-[500px] transition-colors">
                  <h4 className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest mb-6 px-1">درختی ساختار عملیاتی (Visual Hierarchy)</h4>
                  <div className="space-y-4">
                    {organizationalUnits.filter(u => u.level === 'nahiye').map(nahiye => (
                      <div key={nahiye.id} className="space-y-3">
                        <div className="flex items-center gap-3 p-4 bg-blue-500/10 border border-blue-500/30 rounded-2xl">
                          <Shield size={20} className="text-blue-500" />
                          <div>
                            <p className="text-xs font-black text-tg-text">{nahiye.name}</p>
                            <p className="text-[8px] font-bold text-blue-500 uppercase">سطح اول: ناحیه</p>
                          </div>
                        </div>
                        
                        <div className="mr-8 space-y-3 border-r-2 border-tg-border pr-4">
                          {organizationalUnits.filter(u => u.parentId === nahiye.id).map(howze => (
                            <div key={howze.id} className="space-y-3">
                              <div className="flex items-center gap-3 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl">
                                <LayoutGrid size={16} className="text-emerald-500" />
                                <div>
                                  <p className="text-[11px] font-black text-white">{howze.name}</p>
                                  <p className="text-[8px] font-bold text-emerald-500 uppercase">سطح دوم: حوزه</p>
                                </div>
                              </div>

                              <div className="mr-6 space-y-3 border-r-2 border-white/5 pr-4">
                                {organizationalUnits.filter(u => u.parentId === howze.id).map(paygah => (
                                  <div key={paygah.id} className="space-y-2">
                                    <div className="flex items-center gap-3 p-2 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                                      <AtSign size={14} className="text-amber-500" />
                                      <div>
                                        <p className="text-[10px] font-black text-white">{paygah.name}</p>
                                        <p className="text-[7px] font-bold text-amber-500 uppercase">سطح سوم: پایگاه</p>
                                      </div>
                                    </div>

                                    <div className="mr-4 space-y-2 border-r-2 border-white/5 pr-3">
                                      {organizationalUnits.filter(u => u.parentId === paygah.id).map(gordan => (
                                        <div key={gordan.id} className="flex items-center gap-2 p-2 bg-purple-500/10 border border-purple-500/30 rounded-md">
                                          <Users size={12} className="text-purple-500" />
                                          <p className="text-[9px] font-black text-white">{gordan.name} (گردان)</p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                    {organizationalUnits.length === 0 && (
                      <div className="text-center py-20 opacity-40">
                        <p className="text-xs font-black">ساختاری تعریف نشده است.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'bot' && (
          <div className="space-y-6">
            <div className="space-y-1 px-1">
              <h3 className="text-sm font-black">پیکربندی ربات «بله» (Bale)</h3>
              <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">رابط مکاتبات عملیاتی در بستر پیام‌رسان بله</p>
            </div>

            <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-6 transition-colors">
              <div className="space-y-4">
                <div className="space-y-1.5 px-1">
                  <label className="text-[10px] font-black text-tg-text-muted/60 uppercase">Bale Bot Token (HTTP API)</label>
                  <div className="relative">
                    <input 
                      type="password"
                      value={botConfig.token}
                      onChange={e => setBotConfig({...botConfig, token: e.target.value})}
                      className="tg-input pr-10 font-mono text-xs text-tg-accent"
                    />
                    <Lock size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-tg-text-muted" />
                  </div>
                </div>

                <div className="space-y-1.5 px-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">پیام خوش‌آمدگویی بله</label>
                  <textarea 
                    value={botConfig.welcomeMessage}
                    onChange={e => setBotConfig({...botConfig, welcomeMessage: e.target.value})}
                    className="tg-input min-h-[100px] py-3 text-xs"
                    placeholder="متنی که کاربر هنگام زدن دکمه شروع می‌بیند..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4 px-1">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase">شناسه ادمین بله</label>
                    <input 
                      value={botConfig.adminChatId}
                      onChange={e => setBotConfig({...botConfig, adminChatId: e.target.value})}
                      className="tg-input text-xs"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-tg-text-muted/60 uppercase">وضعیت سرور بله</label>
                    <div className="flex items-center h-10 px-4 bg-black/5 dark:bg-black/40 rounded-xl border border-tg-border">
                      <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse ml-2" />
                      <span className="text-[9px] font-black text-emerald-500 uppercase">آنلاین</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-tg-border px-1">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-xs font-black text-tg-text">ارسال نوتیفیکیشن خودکار (Bale API)</p>
                      <p className="text-[8px] text-tg-text-muted font-bold">ارسال گزارشات رصد به کانال بله</p>
                    </div>
                    <button 
                      onClick={() => setBotConfig({...botConfig, notificationsEnabled: !botConfig.notificationsEnabled})}
                      className={`w-12 h-6 rounded-full relative transition-all ${botConfig.notificationsEnabled ? 'bg-tg-accent shadow-lg shadow-tg-accent/30' : 'bg-tg-bg'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${botConfig.notificationsEnabled ? 'right-1' : 'right-7'}`} />
                    </button>
                  </div>
                </div>

                <button 
                  onClick={() => {
                    updateDb('settings.bot', botConfig);
                    setToast({ message: 'تنظیمات ربات بله با موفقیت ذخیره شد', type: 'success' });
                  }}
                  className="w-full py-4 bg-tg-accent text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-tg-accent/20 active:scale-95 transition-all mt-4"
                >
                  به‌روزرسانی تنظیمات بله
                </button>
              </div>

              <div className="bg-emerald-500/5 border border-emerald-500/20 p-6 rounded-[2.5rem] space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-500">
                    <MessageSquare size={20} />
                  </div>
                  <h4 className="text-xs font-black">راهنمای اتصال به بله</h4>
                </div>
                <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                  ۱. در پیام‌رسان بله به <span className="text-emerald-400 font-black">BotFather</span> مراجعه کنید.<br/>
                  ۲. توکن ربات را دریافت و در فیلد بالا قرار دهید.<br/>
                  ۳. پس از ذخیره، تمامی پیام‌های بخش پیام‌رسان به صورت خودکار به این ربات منتقل می‌شوند.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'approvals' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-sm font-black">وظایف در انتظار تایید</h3>
              <span className="bg-blue-500/20 text-blue-500 px-3 py-1 rounded-full text-[10px] font-black">
                {tasks.filter(t => t.status === 'submitted').length} مورد جدید
              </span>
            </div>
            
            {tasks.filter(t => t.status === 'submitted').length > 0 ? (
              <div className="space-y-4">
                {tasks.filter(t => t.status === 'submitted').map(t => {
                  const user = users.find(u => u.uid === t.completedBy);
                  const mission = missions.find(m => m.id === t.missionId);
                  return (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={t.id} 
                      className="bg-tg-surface rounded-3xl border border-tg-border overflow-hidden shadow-sm"
                    >
                      {/* Header */}
                      <div className="p-4 border-b border-tg-border flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-black/5 dark:bg-white/5 rounded-2xl flex items-center justify-center text-lg font-black text-tg-text">
                            {user?.name?.[0] || '؟'}
                          </div>
                          <div>
                            <h4 className="text-xs font-black text-tg-text">{user?.name || 'کاربر ناشناس'}</h4>
                            <p className="text-[9px] text-tg-text-muted font-bold uppercase tracking-widest">{user?.rank || 'کارشناس سیستم'}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-[10px] font-black text-blue-500">+{t.points} امتیاز</p>
                          <p className="text-[8px] text-tg-text-muted font-bold">{new Date(t.completedAt || '').toLocaleDateString('fa-IR')}</p>
                          {t.deadline && (
                            <div className="flex flex-col items-end mt-1">
                              <p className="text-[7px] text-tg-text-muted font-black uppercase tracking-tighter">ضرب‌الاجل</p>
                              <p className={`text-[8px] font-black ${
                                t.completedAt && t.deadline.includes('T') && new Date(t.completedAt).getTime() > new Date(t.deadline).getTime() 
                                ? 'text-red-500 animate-pulse' 
                                : 'text-tg-text-muted'
                              }`}>
                                {t.deadline.includes('T') ? new Date(t.deadline).toLocaleString('fa-IR', { hour: '2-digit', minute: '2-digit' }) : t.deadline}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-4 space-y-4">
                        <div>
                          <p className="text-[10px] text-tg-text-muted font-black mb-1 uppercase">ماموریت مرتبط:</p>
                          <h5 className="text-xs font-bold text-tg-accent">{mission?.title || 'ماموریت عمومی'}</h5>
                        </div>

                        <div>
                          <p className="text-[10px] text-tg-text-muted font-black mb-1 uppercase">عنوان وظیفه:</p>
                          <h5 className="text-xs font-bold text-tg-text">{t.title}</h5>
                        </div>

                        {t.documentationLink && (
                          <div className="bg-black/5 dark:bg-white/5 p-3 rounded-2xl border border-tg-border">
                            <p className="text-[9px] text-tg-text-muted font-black mb-2 uppercase">لینک مستندات:</p>
                            <a 
                              href={t.documentationLink} 
                              target="_blank" 
                              rel="noreferrer"
                              className="flex items-center gap-2 text-[10px] text-blue-400 font-bold hover:underline"
                            >
                              <ExternalLink size={12} />
                              <span className="truncate">{t.documentationLink}</span>
                            </a>
                          </div>
                        )}

                        {t.documentationScreenshot && (
                          <div className="space-y-2">
                            <p className="text-[9px] text-tg-text-muted font-black uppercase">تصویر مستندات:</p>
                            <div className="rounded-2xl overflow-hidden border border-tg-border">
                              <img 
                                src={t.documentationScreenshot} 
                                className="w-full h-48 object-cover cursor-zoom-in" 
                                referrerPolicy="no-referrer" 
                                onClick={() => setViewingImage(t.documentationScreenshot)}
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="p-4 bg-black/5 dark:bg-white/5 grid grid-cols-2 gap-3">
                        <button 
                          onClick={() => handleApproveTask(t)} 
                          className="flex items-center justify-center gap-2 py-3 bg-emerald-500 text-white rounded-2xl text-[10px] font-black shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
                        >
                          <CheckCircle2 size={16} />
                          تایید و واریز امتیاز
                        </button>
                        <button 
                          onClick={() => setShowRejectTask({taskId: t.id})} 
                          className="flex items-center justify-center gap-2 py-3 bg-red-500 text-white rounded-2xl text-[10px] font-black shadow-lg shadow-red-500/20 active:scale-95 transition-all"
                        >
                          <XCircle size={16} />
                          رد وظیفه
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            ) : (
              <div className="bg-tg-surface p-12 rounded-[2.5rem] border border-tg-border text-center space-y-4">
                <div className="w-20 h-20 bg-black/5 dark:bg-white/5 rounded-3xl flex items-center justify-center mx-auto text-tg-text-muted">
                  <CheckCircle2 size={40} />
                </div>
                <div>
                  <h4 className="text-sm font-black text-tg-text">همه موارد بررسی شده‌اند</h4>
                  <p className="text-[10px] text-tg-text-muted font-bold mt-1">در حال حاضر وظیفه جدیدی در انتظار تایید نیست.</p>
                </div>
              </div>
            )}
          </div>
        )}
        
        {activeSubTab === 'settings' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-6">
                <h4 className="text-xs font-black text-blue-500 uppercase tracking-widest border-b border-tg-border pb-2">تنظیمات عمومی</h4>
                <div className="space-y-4">
                  {[
                    { label: 'حالت تعمیر و نگهداری', desc: 'غیرفعال کردن دسترسی کاربران عادی', enabled: false },
                    { label: 'تایید خودکار وظایف', desc: 'تایید سیستمی وظایف ارسالی توسط هوش مصنوعی', enabled: true },
                    { label: 'ثبت‌نام آزاد', desc: 'امکان ثبت‌نام کاربران جدید بدون دعوت‌نامه', enabled: false }
                  ].map((s, i) => (
                    <div key={i} className="flex justify-between items-center">
                      <div>
                        <p className="text-[11px] font-black text-tg-text">{s.label}</p>
                        <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">{s.desc}</p>
                      </div>
                      <button className={`w-10 h-5 rounded-full relative transition-all ${s.enabled ? 'bg-blue-500' : 'bg-tg-bg'}`}>
                        <div className={`absolute top-1 w-3 h-3 bg-white rounded-full shadow-sm transition-all ${s.enabled ? 'right-1' : 'right-6'}`} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-6">
                <h4 className="text-xs font-black text-emerald-500 uppercase tracking-widest border-b border-tg-border pb-2">امنیت و دسترسی</h4>
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-tg-text-muted uppercase px-1">محدودیت IP عملیاتی</label>
                    <input placeholder="0.0.0.0/0" className="tg-input text-xs font-mono" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-tg-text-muted uppercase px-1">زمان انقضای نشست (دقیقه)</label>
                    <input type="number" defaultValue="1440" className="tg-input text-xs font-mono" />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-1 px-1">
                <h3 className="text-sm font-black flex items-center gap-2">
                  <Settings size={18} className="text-blue-500" />
                  پیکربندی واحدهای عملیاتی
                </h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">تنظیمات واحدها و پارامترهای عملیاتی</p>
              </div>
              
              <div className="grid grid-cols-1 gap-4">
                {[
                  { name: 'واحد رصد', key: 'tracking', icon: Eye, desc: 'واحد اطلاعات و پایش' },
                  { name: 'واحد انتشار', key: 'publishing', icon: Share2, desc: 'فرماندهی استقرار و انتشار محتوا' },
                  { name: 'واحد آموزش', key: 'education', icon: GraduationCap, desc: 'فرماندهی دکترین و آموزش' }
                ].map(section => (
                  <motion.div 
                    whileHover={{ x: 4 }}
                    key={section.key} 
                    className="bg-tg-surface p-5 rounded-[2rem] border border-tg-border flex items-center justify-between group hover:border-blue-500/30 transition-all shadow-sm"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-black/5 dark:bg-white/5 rounded-2xl flex items-center justify-center text-tg-text-muted border border-tg-border group-hover:border-blue-500/50 transition-all">
                        <section.icon size={24} />
                      </div>
                      <div>
                        <h4 className="text-xs font-black text-tg-text">{section.name}</h4>
                        <p className="text-[9px] text-tg-text-muted font-bold uppercase tracking-widest mt-0.5">{section.desc}</p>
                      </div>
                    </div>
                    <button className="p-2 bg-black/5 dark:bg-white/5 hover:bg-blue-500/10 text-tg-text-muted hover:text-blue-500 rounded-xl transition-all border border-tg-border">
                      <ChevronLeft size={18} />
                    </button>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-1 px-1">
                <h3 className="text-sm font-black flex items-center gap-2">
                  <Shield size={18} className="text-emerald-500" />
                  تنظیمات امنیتی و دسترسی
                </h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">پروتکل‌های امنیتی و کنترل دسترسی</p>
              </div>
              
              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-6 shadow-sm">
                {[
                  { label: 'ثبت‌نام آزاد کاربران', desc: 'اجازه ثبت‌نام بدون دعوت‌نامه', enabled: false },
                  { label: 'تایید دو مرحله‌ای اجباری', desc: 'اجبار به استفاده از 2FA برای کادر فرماندهی', enabled: true },
                  { label: 'حالت تعمیر و نگهداری', desc: 'قفل موقت کل سیستم برای به‌روزرسانی', enabled: false }
                ].map((item, i) => (
                  <div key={i} className="flex justify-between items-center">
                    <div className="space-y-0.5">
                      <p className="text-xs font-black text-tg-text">{item.label}</p>
                      <p className="text-[9px] text-tg-text-muted font-bold uppercase tracking-tighter">{item.desc}</p>
                    </div>
                    <button className={`w-12 h-6 rounded-full relative transition-all ${item.enabled ? 'bg-emerald-500 shadow-md shadow-emerald-500/20' : 'bg-tg-bg'}`}>
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${item.enabled ? 'right-1' : 'right-7'}`} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-1 px-1">
                <h3 className="text-sm font-black flex items-center gap-2">
                  <Bell size={18} className="text-amber-500" />
                  اطلاع‌رسانی و اعلان‌ها
                </h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">موتور اعلان‌ها و قالب‌های پیام</p>
              </div>
              
            <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-4 shadow-sm">
                <div className="space-y-2">
                  <label className="text-[8px] font-black text-tg-text-muted uppercase px-2">قالب اعلان تلگرام</label>
                  <textarea 
                    className="tg-input bg-black/5 dark:bg-white/5 border-tg-border focus:border-blue-500/50 text-[10px] h-24 font-mono leading-relaxed text-tg-text" 
                    defaultValue="عملیات جدید: {title}\nپاداش: {reward}\nمهلت: {deadline}" 
                  />
                </div>
                <button className="w-full py-4 bg-tg-accent text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-tg-accent/20 active:scale-95 transition-all">
                  ذخیره پروتکل‌های اعلان
                </button>
              </div>
            </div>

            {/* Danger Zone */}
            <div className="bg-red-500/5 border border-red-500/20 p-6 rounded-[2.5rem] space-y-4">
              <h4 className="text-xs font-black text-red-500 uppercase tracking-widest">منطقه خطر (Danger Zone)</h4>
              <p className="text-[10px] text-slate-500 font-bold">عملیات‌های زیر غیرقابل بازگشت هستند. لطفاً با احتیاط عمل کنید.</p>
              <div className="flex gap-3">
                <button 
                  onClick={() => {
                    if (confirm('آیا از پاکسازی تمامی لاگ‌های سیستمی اطمینان دارید؟')) {
                      setActivityLogs([]);
                      setToast({ message: 'تمامی لاگ‌های سیستمی پاکسازی شدند', type: 'success' });
                    }
                  }}
                  className="px-6 py-3 bg-red-500/10 text-red-500 border border-red-500/20 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all"
                >
                  پاکسازی تمامی لاگ‌ها
                </button>
                <button 
                  onClick={() => {
                    if (confirm('آیا از بازگردانی تمامی تنظیمات به حالت اولیه اطمینان دارید؟')) {
                      setToast({ message: 'تنظیمات به حالت پیش‌فرض بازگشت', type: 'success' });
                    }
                  }}
                  className="px-6 py-3 bg-red-500/10 text-red-500 border border-red-500/20 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all"
                >
                  ریست تنظیمات کارخانه
                </button>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'observations' && (
          <div className="space-y-4">
            <div className="space-y-1 px-1">
              <h3 className="text-sm font-black">گزارشات رصد مردمی (مخبر)</h3>
              <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">گزارشات اطلاعات مردمی و پایش متن‌باز</p>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              {observations.map(obs => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={obs.id} 
                  className="bg-tg-surface rounded-[2rem] border border-tg-border overflow-hidden group hover:border-blue-500/30 transition-all shadow-sm"
                >
                  <div className="p-5 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex gap-3">
                        <div className="w-12 h-12 bg-black/5 dark:bg-white/5 rounded-2xl flex items-center justify-center text-amber-500 border border-tg-border group-hover:border-amber-500/50 transition-all">
                          <Eye size={24} />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-tg-text">{obs.fakeContentTitle}</h4>
                          <p className="text-[10px] text-tg-text-muted font-mono" dir="ltr">{obs.instagramPage}</p>
                        </div>
                      </div>
                      <span className={`text-[8px] font-black px-2.5 py-1 rounded-xl uppercase tracking-widest ${
                        obs.status === 'pending' ? 'bg-amber-500/10 text-amber-500' : 
                        obs.status === 'reviewed' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'
                      }`}>
                        {obs.status === 'pending' ? 'در انتظار' : obs.status === 'reviewed' ? 'بررسی شده' : 'رد شده'}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {obs.screenshots.map((s, i) => (
                        <div key={i} className="relative aspect-square rounded-2xl overflow-hidden border border-tg-border group/img">
                          <img 
                            src={s} 
                            className="w-full h-full object-cover transition-transform group-hover/img:scale-110 cursor-zoom-in" 
                            referrerPolicy="no-referrer" 
                            onClick={() => setViewingImage(s)}
                          />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                            <Maximize2 size={16} className="text-white" />
                          </div>
                        </div>
                      ))}
                    </div>

                    {obs.status === 'pending' && (
                      <div className="flex gap-3 pt-2">
                        <button 
                          onClick={async () => {
                            const updated = observations.map(o => o.id === obs.id ? {...o, status: 'reviewed' as any} : o);
                            await updateDb('observations', updated);
                          }}
                          className="flex-1 py-3 bg-emerald-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
                        >
                          تایید گزارش
                        </button>
                        <button 
                          onClick={async () => {
                            const updated = observations.map(o => o.id === obs.id ? {...o, status: 'rejected' as any} : o);
                            await updateDb('observations', updated);
                          }}
                          className="flex-1 py-3 bg-white/5 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all"
                        >
                          رد گزارش
                        </button>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {activeSubTab === 'tracking' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black text-tg-text">مدیریت لیست رصد</h3>
                <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">پایش دارایی‌های هدف</p>
              </div>
              <button 
                onClick={() => setShowAddAccount(true)}
                className="p-2 bg-tg-accent text-white rounded-xl shadow-lg shadow-tg-accent/10 active:scale-95 transition-all"
              >
                <Plus size={18} />
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {trackedAccounts.map(acc => (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={acc.id} 
                  className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex justify-between items-center group hover:border-blue-500/30 transition-all shadow-sm"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border border-tg-border group-hover:border-blue-500/50 transition-all shadow-sm ${
                      acc.platform === 'twitter' ? 'bg-blue-500/10 text-blue-500' :
                      acc.platform === 'bale' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-pink-500/10 text-pink-500'
                    }`}>
                      {acc.platform === 'twitter' && <Twitter size={24} />}
                      {acc.platform === 'bale' && <MessageSquare size={24} />}
                      {acc.platform === 'instagram' && <Instagram size={24} />}
                      {!['twitter', 'bale', 'instagram'].includes(acc.platform) && <AtSign size={24} />}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-black text-tg-text">{acc.name}</h4>
                        <span className={`text-[7px] font-black px-1.5 py-0.5 rounded uppercase ${
                          acc.category === 'enemy' ? 'bg-red-500/20 text-red-500' :
                          acc.category === 'friendly' ? 'bg-emerald-500/20 text-emerald-500' : 'bg-black/5 dark:bg-white/5 text-tg-text-muted border border-tg-border'
                        }`}>
                          {acc.category === 'enemy' ? 'معاند' : acc.category === 'friendly' ? 'همسو' : 'خنثی'}
                        </span>
                      </div>
                      <p className="text-[10px] text-tg-text-muted font-mono" dir="ltr">{acc.handle}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="p-2 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 text-tg-text-muted hover:text-tg-text rounded-xl transition-all border border-tg-border shadow-sm">
                      <Activity size={16} />
                    </button>
                    <button 
                      onClick={async () => {
                        if (confirm('آیا از حذف این حساب از لیست رصد اطمینان دارید؟')) {
                          const updated = trackedAccounts.filter(a => a.id !== acc.id);
                          setTrackedAccounts(updated);
                          await updateDb('tracking.accounts', updated);
                        }
                      }}
                      className="p-2 bg-black/5 dark:bg-white/5 hover:bg-red-500/10 text-tg-text-muted hover:text-red-500 rounded-xl transition-all border border-tg-border shadow-sm"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {activeSubTab === 'monitoring' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black">داشبورد پایش فعالیت‌ها</h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">گزارش وضعیت و فعالیت حساب‌های تحت نظر</p>
              </div>
              <button 
                onClick={() => setShowAddAccount(true)}
                className="p-2 bg-blue-500 text-white rounded-xl shadow-lg shadow-blue-500/20 active:scale-95 transition-all flex items-center gap-2"
              >
                <Plus size={18} />
                <span className="text-[10px] font-black uppercase">افزودن حساب جدید</span>
              </button>
            </div>

            <div className="bg-tg-surface rounded-[2.5rem] border border-tg-border overflow-hidden shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-right border-collapse">
                  <thead>
                    <tr className="bg-black/5 dark:bg-black/20 border-b border-tg-border">
                      <th className="px-6 py-4 text-[10px] font-black text-tg-text-muted uppercase tracking-widest">پلتفرم</th>
                      <th className="px-6 py-4 text-[10px] font-black text-tg-text-muted uppercase tracking-widest">نام و آیدی</th>
                      <th className="px-6 py-4 text-[10px] font-black text-tg-text-muted uppercase tracking-widest">دسته‌بندی</th>
                      <th className="px-6 py-4 text-[10px] font-black text-tg-text-muted uppercase tracking-widest">آخرین فعالیت</th>
                      <th className="px-6 py-4 text-[10px] font-black text-tg-text-muted uppercase tracking-widest">وضعیت</th>
                      <th className="px-6 py-4 text-[10px] font-black text-tg-text-muted uppercase tracking-widest text-center">عملیات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-tg-border">
                    {trackedAccounts.map(acc => (
                      <tr key={acc.id} className="hover:bg-black/5 dark:hover:bg-white/[0.02] transition-colors group">
                        <td className="px-6 py-4">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                            acc.platform === 'twitter' ? 'bg-blue-500/10 text-blue-500' : 
                            acc.platform === 'instagram' ? 'bg-pink-500/10 text-pink-500' : 'bg-sky-500/10 text-sky-500'
                          }`}>
                            {acc.platform === 'twitter' ? <Twitter size={16} /> : acc.platform === 'instagram' ? <Instagram size={16} /> : <MessageSquare size={16} />}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="text-xs font-black text-tg-text">{acc.name}</span>
                            <span className="text-[10px] text-tg-text-muted font-mono ltr inline-block text-right">{acc.handle}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`text-[9px] font-black px-2 py-1 rounded-lg uppercase tracking-tight ${
                            acc.category === 'enemy' ? 'bg-red-500/10 text-red-500' : 
                            acc.category === 'friendly' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-black/10 dark:bg-white/5 text-tg-text-muted border border-tg-border'
                          }`}>
                            {acc.category === 'enemy' ? 'معاند' : acc.category === 'friendly' ? 'خودی' : 'خنثی'}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-[10px] font-bold text-tg-text-muted">
                          {new Date(acc.lastActivity).toLocaleString('fa-IR')}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <div className={`w-1.5 h-1.5 rounded-full ${acc.status === 'active' ? 'bg-emerald-500 glow-point-sm' : 'bg-slate-600'}`} />
                            <span className={`text-[10px] font-black ${acc.status === 'active' ? 'text-emerald-500' : 'text-tg-text-muted'}`}>
                              {acc.status === 'active' ? 'فعال' : 'غیرفعال'}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center justify-center gap-2">
                            <button className="p-2 bg-black/5 dark:bg-white/5 hover:bg-blue-500/10 text-tg-text-muted hover:text-blue-500 rounded-xl transition-all border border-tg-border">
                              <Activity size={14} />
                            </button>
                            <button 
                              onClick={async () => {
                                if (confirm('آیا از حذف این حساب اطمینان دارید؟')) {
                                  const updated = trackedAccounts.filter(a => a.id !== acc.id);
                                  setTrackedAccounts(updated);
                                  await updateDb('tracking.accounts', updated);
                                }
                              }}
                              className="p-2 bg-black/5 dark:bg-white/5 hover:bg-red-500/10 text-tg-text-muted hover:text-red-500 rounded-xl transition-all border border-tg-border"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'reports' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black">گزارشات مکتوب و تحلیلی</h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">گزارش‌های اطلاعاتی راهبردی و عملیاتی</p>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={async () => {
                    setLoading(true);
                    try {
                      const brief = await getDailyBrief();
                      const report = {
                        id: `rep-${Date.now()}`,
                        title: `گزارش تحلیلی روزانه - ${new Date().toLocaleDateString('fa-IR')}`,
                        content: brief.map((b: any) => `${b.title}: ${b.description}`).join('\n\n'),
                        date: new Date().toISOString(),
                        category: 'analysis' as any,
                        author: user.name
                      };
                      await updateDb('reports', [report, ...reports]);
                      setToast({ message: 'گزارش هوشمند با موفقیت تولید شد', type: 'success' });
                    } catch (err) {
                      setToast({ message: 'خطا در تولید گزارش', type: 'error' });
                    } finally {
                      setLoading(false);
                    }
                  }}
                  disabled={loading}
                  className="p-2 bg-blue-500 text-white rounded-xl shadow-lg shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-50"
                >
                  <Zap size={18} className={loading ? 'animate-spin' : ''} />
                </button>
                <button 
                  onClick={() => setShowAddReport(true)}
                  className="p-2 bg-white text-black rounded-xl shadow-lg shadow-white/10 active:scale-95 transition-all"
                >
                  <Plus size={18} />
                </button>
              </div>
            </div>
            
            {reports.length > 0 ? (
              <div className="space-y-3">
                {reports.map(r => (
                  <motion.div 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    key={r.id} 
                    className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex justify-between items-center group hover:border-blue-500/30 transition-all shadow-sm"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-blue-500/5 text-blue-500 rounded-2xl flex items-center justify-center border border-tg-border group-hover:border-blue-500/50 transition-all">
                        <FileText size={24} />
                      </div>
                      <div>
                        <h4 className="text-xs font-black truncate max-w-[180px] text-tg-text">{r.title}</h4>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[8px] font-black text-tg-text-muted uppercase tracking-widest">{r.category}</span>
                          <span className="text-tg-border">•</span>
                          <span className="text-[8px] font-black text-tg-text-muted">{new Date(r.date).toLocaleDateString('fa-IR')}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button className="p-2 bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white rounded-xl transition-all">
                        <Eye size={16} />
                      </button>
                      <button 
                        onClick={async () => {
                          if (confirm('آیا از حذف این گزارش اطمینان دارید؟')) {
                            await updateDb('reports', reports.filter(item => item.id !== r.id));
                          }
                        }}
                        className="p-2 bg-white/5 hover:bg-red-500/10 text-slate-400 hover:text-red-500 rounded-xl transition-all"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="bg-tg-surface p-12 rounded-[2.5rem] border border-tg-border text-center space-y-4 shadow-sm">
                <div className="w-20 h-20 bg-black/5 dark:bg-white/5 rounded-3xl flex items-center justify-center mx-auto text-tg-text-muted">
                  <FileText size={40} />
                </div>
                <div>
                  <h4 className="text-sm font-black text-tg-text">هنوز گزارشی ثبت نشده است</h4>
                  <p className="text-[10px] text-tg-text-muted font-bold mt-1">گزارشات تحلیلی و عملیاتی در این بخش قرار می‌گیرند.</p>
                </div>
                <button 
                  onClick={() => setShowAddReport(true)}
                  className="tg-btn-secondary py-3 px-6"
                >
                  ایجاد اولین گزارش
                </button>
              </div>
            )}
          </div>
        )}

        {activeSubTab === 'education' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black">مدیریت محتوای آموزشی</h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">مدیریت آموزش و دکترین</p>
              </div>
              <button 
                onClick={() => setShowAddEducation(true)}
                className="p-2 bg-white text-black rounded-xl shadow-lg shadow-white/10 active:scale-95 transition-all"
              >
                <Plus size={18} />
              </button>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {educationItems.map(item => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={item.id} 
                  className="bg-tg-surface rounded-[2rem] border border-tg-border overflow-hidden group hover:border-blue-500/30 transition-all shadow-sm"
                >
                  <div className="p-5 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex gap-3">
                        <div className="w-12 h-12 bg-black/5 dark:bg-white/5 rounded-2xl flex items-center justify-center text-blue-500 border border-tg-border group-hover:border-blue-500/50 transition-all">
                          <GraduationCap size={24} />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-tg-text">{item.title}</h4>
                          <p className="text-[9px] text-tg-text-muted font-bold uppercase tracking-widest mt-0.5">{item.sessions?.length || 0} Sessions Active</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => setEditingEducation(item)}
                          className="p-2 bg-white/5 hover:bg-blue-500/10 text-slate-400 hover:text-blue-500 rounded-xl transition-all"
                        >
                          <Edit3 size={16} />
                        </button>
                        <button 
                          onClick={() => setShowAddSession({itemId: item.id})}
                          className="p-2 bg-white/5 hover:bg-emerald-500/10 text-slate-400 hover:text-emerald-500 rounded-xl transition-all"
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                    </div>
                    
                    {item.sessions && item.sessions.length > 0 && (
                      <div className="space-y-2 pr-4 border-r-2 border-white/5">
                        {item.sessions.map(s => (
                          <div key={s.id} className="flex justify-between items-center text-[10px] bg-white/5 p-3 rounded-2xl border border-white/5">
                            <div className="flex items-center gap-2">
                              {s.type === 'video' ? <Video size={14} className="text-blue-500" /> : <FileText size={14} className="text-emerald-500" />}
                              <span className="font-bold">{s.title}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <button 
                                onClick={() => setEditingSession({itemId: item.id, session: s})}
                                className="p-1.5 bg-white/5 hover:bg-blue-500/10 text-slate-400 hover:text-blue-500 rounded-lg transition-all"
                                title="ویرایش جلسه"
                              >
                                <Edit3 size={12} />
                              </button>
                              <button 
                                onClick={async () => {
                                  if (confirm('آیا از حذف این جلسه اطمینان دارید؟')) {
                                    const updatedItems = educationItems.map(i => i.id === item.id ? { ...i, sessions: i.sessions.filter(sess => sess.id !== s.id) } : i);
                                    await updateDb('education.items', updatedItems);
                                  }
                                }}
                                className="p-1.5 bg-white/5 hover:bg-red-500/10 text-slate-400 hover:text-red-500 rounded-lg transition-all"
                                title="حذف جلسه"
                              >
                                <Trash2 size={12} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-4 border-t border-white/5">
                      <div className="flex gap-4">
                        <div className="flex items-center gap-1.5">
                          <Users size={12} className="text-slate-500" />
                          <span className="text-[10px] font-black text-slate-400">۴۲ نفر در حال یادگیری</span>
                        </div>
                      </div>
                      <button 
                        onClick={async () => {
                          if (confirm('آیا از حذف این دوره آموزشی اطمینان دارید؟')) {
                            await updateDb('education.items', educationItems.filter(i => i.id !== item.id));
                          }
                        }}
                        className="p-2 bg-white/5 hover:bg-red-500/10 text-slate-400 hover:text-red-500 rounded-xl transition-all"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}
        {activeSubTab === 'tasks' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black">مدیریت کل وظایف</h3>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">پایش و فیلتر تمامی تسک‌های عملیاتی</p>
              </div>
            </div>

            {/* Filters */}
            <div className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex flex-wrap gap-4 shadow-sm">
               <div className="flex flex-col gap-1.5 flex-1 min-w-[150px]">
                  <label className="text-[8px] font-black text-slate-500 uppercase px-1">فیلتر پلتفرم</label>
                  <select 
                    className="tg-input text-[10px] py-2"
                    value={taskFilterPlatform}
                    onChange={(e) => setTaskFilterPlatform(e.target.value)}
                  >
                    <option value="all">همه پلتفرم‌ها</option>
                    <option value="twitter">توییتر (X)</option>
                    <option value="instagram">اینستاگرام</option>
                    <option value="bale">بله (Bale)</option>
                  </select>
               </div>
               <div className="flex flex-col gap-1.5 flex-1 min-w-[150px]">
                  <label className="text-[8px] font-black text-slate-500 uppercase px-1">فیلتر وضعیت</label>
                  <select 
                    className="tg-input text-[10px] py-2"
                    value={taskFilterStatus}
                    onChange={(e) => setTaskFilterStatus(e.target.value)}
                  >
                    <option value="all">همه وضعیت‌ها</option>
                    <option value="pending">در انتظار (Pending)</option>
                    <option value="submitted">ارسال شده (Submitted)</option>
                    <option value="completed">تکمیل شده (Completed)</option>
                    <option value="rejected">رد شده (Rejected)</option>
                    <option value="in_progress">در حال انجام (In Progress)</option>
                  </select>
               </div>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {tasks
                .filter(t => taskFilterPlatform === 'all' || t.platform === taskFilterPlatform)
                .filter(t => taskFilterStatus === 'all' || t.status === taskFilterStatus)
                .map(t => {
                  const completionsForTask = taskCompletions.filter(c => c.taskId === t.id);
                  const completionCount = completionsForTask.length;
                  
                  return (
                    <div key={t.id} className="bg-tg-surface p-4 rounded-3xl border border-tg-border group space-y-4 shadow-sm">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-4 text-right">
                          <div className={`w-10 h-10 rounded-2xl flex items-center justify-center border border-white/5 ${
                            t.platform === 'twitter' ? 'bg-blue-500/10 text-blue-500' : 
                            t.platform === 'instagram' ? 'bg-pink-500/10 text-pink-500' : 
                            t.platform === 'bale' ? 'bg-emerald-500/10 text-emerald-500' :
                            'bg-slate-500/10 text-slate-400'
                          }`}>
                            {t.platform === 'twitter' ? <Twitter size={18} /> : 
                             t.platform === 'instagram' ? <Instagram size={18} /> : 
                             t.platform === 'bale' ? <Send size={18} /> : <Target size={18} />}
                          </div>
                          <div>
                            <h5 className="text-[11px] font-black">{t.title}</h5>
                            <div className="flex items-center gap-2 mt-0.5">
                              {t.department && (
                                <span className="text-[7px] font-black bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded-md border border-blue-500/20 uppercase">
                                  {t.department}
                                </span>
                              )}
                              <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">{t.platform}</span>
                              <span className="text-slate-700">•</span>
                              <span className={`text-[8px] font-black uppercase tracking-widest ${
                                t.status === 'completed' ? 'text-emerald-500' :
                                t.status === 'rejected' ? 'text-red-500' :
                                t.status === 'submitted' ? 'text-blue-500' :
                                'text-slate-400'
                              }`}>{t.status}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                           <div className="text-left px-4">
                             <p className="text-[14px] font-black text-white">{completionCount}</p>
                             <p className="text-[7px] font-black text-slate-500 uppercase">مشارکت کل</p>
                           </div>
                           <button 
                            onClick={() => handleDeleteTask(t.id)}
                            className="p-2 bg-white/5 hover:bg-red-500/10 text-slate-400 hover:text-red-500 rounded-xl transition-all"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>

                      {completionCount > 0 && (
                        <div className="pt-3 border-t border-white/5">
                          <p className="text-[8px] font-black text-slate-500 uppercase mb-2">لیست آخرین مشارکت‌کنندگان:</p>
                          <div className="flex flex-wrap gap-2">
                            {completionsForTask.slice(0, 10).map(c => {
                              const u = users.find(user => user.uid === c.userId);
                              return (
                                <div key={c.id} className="flex items-center gap-1.5 bg-black/20 px-2 py-1 rounded-full border border-white/5">
                                  <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center text-[7px] font-black text-white">
                                    {u?.name?.charAt(0) || '?'}
                                  </div>
                                  <span className="text-[8px] font-medium text-slate-300">{u?.name || 'ناشناس'}</span>
                                  {c.status === 'pending' && <Clock size={8} className="text-amber-500" />}
                                  {c.status === 'verified' && <CheckCircle size={8} className="text-emerald-500" />}
                                </div>
                              );
                            })}
                            {completionCount > 10 && (
                              <div className="text-[8px] font-black text-blue-500 px-2 py-1">
                                + {completionCount - 10} نفر دیگر
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
                {tasks.filter(t => (taskFilterPlatform === 'all' || t.platform === taskFilterPlatform) && (taskFilterStatus === 'all' || t.status === taskFilterStatus)).length === 0 && (
                  <div className="text-center py-12 bg-white/5 rounded-[2.5rem] border border-dashed border-white/10">
                    <p className="text-xs text-slate-500 font-bold">هیچ وظیفه‌ای با این مشخصات یافت نشد.</p>
                  </div>
                )}
            </div>
          </div>
        )}

        {activeSubTab === 'missions' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard icon={Users} label="کل اعضا" value={users.length.toString()} color="text-blue-500" />
              <StatCard icon={Target} label="ماموریت‌های فعال" value={missions.length.toString()} color="text-emerald-500" />
              <StatCard icon={AlertCircle} label="در انتظار تایید" value={tasks.filter(t => t.status === 'submitted').length.toString()} color="text-amber-500" />
              <StatCard icon={Activity} label="سلامت سیستم" value="۱۰۰٪" color="text-emerald-500" />
            </div>

            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  {selectedAdminMissionId && (
                    <button 
                      onClick={() => setSelectedAdminMissionId(null)}
                      className="p-1.5 bg-white/5 text-slate-400 rounded-lg hover:text-white transition-all"
                    >
                      <ChevronRight size={18} />
                    </button>
                  )}
                  <h3 className="text-sm font-black">
                    {selectedAdminMissionId ? 'مدیریت وظایف ماموریت' : 'مدیریت ماموریت‌های عملیاتی'}
                  </h3>
                </div>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">
                  {selectedAdminMissionId ? 'تنظیم وظایف فرعی برای ماموریت انتخابی' : 'ماموریت‌ها و اهداف عملیاتی'}
                </p>
              </div>
              {!selectedAdminMissionId && (
                <button 
                  onClick={() => setShowAddMission(true)} 
                  className="w-10 h-10 bg-white/10 text-white rounded-2xl flex items-center justify-center border border-white/10 hover:bg-white/20 active:scale-95 transition-all"
                >
                  <Plus size={24} />
                </button>
              )}
            </div>

            {showAddMission && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-tg-surface p-6 rounded-[2.5rem] border border-blue-500/30 space-y-4 shadow-2xl shadow-blue-500/10"
              >
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-black text-blue-500 uppercase tracking-widest border-b border-white/5 pb-2">اطلاعات پایه ماموریت</h4>
                    <input 
                      placeholder="عنوان ماموریت" 
                      className="tg-input bg-black/20 border-white/5 focus:border-blue-500/50" 
                      value={newMission.title} 
                      onChange={e => setNewMission({...newMission, title: e.target.value})} 
                    />
                    <textarea 
                      placeholder="توضیحات و جزئیات عملیاتی" 
                      className="tg-input bg-black/20 border-white/5 focus:border-blue-500/50 min-h-[100px]" 
                      value={newMission.description} 
                      onChange={e => setNewMission({...newMission, description: e.target.value})} 
                    />
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-[10px] font-black text-blue-500 uppercase tracking-widest border-b border-white/5 pb-2">تنظیمات و پاداش</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-slate-500 uppercase px-2">سطح دشواری</label>
                        <select 
                          className="tg-input bg-black/20 border-white/5 focus:border-blue-500/50" 
                          value={newMission.type} 
                          onChange={e => setNewMission({...newMission, type: e.target.value as any})}
                        >
                          <option value="daily">روزانه (Standard)</option>
                          <option value="urgent">فوری (High Priority)</option>
                          <option value="special">ویژه (Critical)</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-slate-500 uppercase px-2">پاداش ماموریت</label>
                        <input 
                          placeholder="مثلا: ۵۰۰ امتیاز" 
                          className="tg-input bg-black/20 border-white/5 focus:border-blue-500/50" 
                          value={newMission.reward} 
                          onChange={e => setNewMission({...newMission, reward: e.target.value})} 
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[8px] font-black text-slate-500 uppercase px-2">اولویت اعلان</label>
                        <select 
                          className="tg-input bg-black/20 border-white/5 focus:border-blue-500/50" 
                          value={newMission.priority} 
                          onChange={e => setNewMission({...newMission, priority: e.target.value as any})}
                        >
                          <option value="low">کم (Low)</option>
                          <option value="medium">متوسط (Medium)</option>
                          <option value="high">زیاد (High)</option>
                          <option value="critical">بسیار مهم/فوری (Critical)</option>
                        </select>
                      </div>
                      <div className="flex items-center gap-3 pt-5 px-2">
                        <input 
                          type="checkbox" 
                          id="send-bale-alert"
                          className="w-4 h-4 rounded bg-black/20 border-white/5 text-blue-500"
                          checked={newMission.sendBaleAlert}
                          onChange={e => setNewMission({...newMission, sendBaleAlert: e.target.checked})}
                        />
                        <label htmlFor="send-bale-alert" className="text-[10px] font-black text-tg-text uppercase">ارسال اعلان بله</label>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-slate-500 uppercase px-2">محتوای آموزشی مرتبط</label>
                      <select 
                        className="tg-input bg-black/20 border-white/5 focus:border-blue-500/50" 
                        value={newMission.educationId} 
                        onChange={e => setNewMission({...newMission, educationId: e.target.value})}
                      >
                        <option value="">بدون محتوای آموزشی</option>
                        {educationItems.map(item => (
                          <option key={item.id} value={item.id}>{item.title}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 pt-2">
                  <button 
                    onClick={handleAddMission} 
                    className="flex-1 py-4 bg-blue-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
                  >
                    انتشار ماموریت
                  </button>
                  <button 
                    onClick={() => setShowAddMission(false)} 
                    className="flex-1 py-4 bg-white/5 text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all"
                  >
                    انصراف
                  </button>
                </div>
              </motion.div>
            )}

            {!selectedAdminMissionId ? (
              <div className="grid grid-cols-1 gap-4">
                {missions.sort((a, b) => (a.isArchived === b.isArchived ? 0 : a.isArchived ? 1 : -1)).map(m => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={m.id} 
                    className="bg-tg-surface rounded-[2rem] border border-tg-border overflow-hidden group hover:border-blue-500/30 transition-all shadow-sm"
                  >
                    <div className="p-5 space-y-4">
                      <div className="flex justify-between items-start">
                        <div className="flex gap-3">
                          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border border-tg-border group-hover:border-opacity-50 transition-all ${
                            m.type === 'urgent' ? 'bg-red-500/10 text-red-500 border-red-500/20' : 
                            m.type === 'special' ? 'bg-purple-500/10 text-purple-500 border-purple-500/20' : 
                            'bg-blue-500/10 text-blue-500 border-blue-500/20'
                          }`}>
                            <Target size={24} />
                          </div>
                          <div>
                            <h4 className={`text-xs font-black ${m.isArchived ? 'text-tg-text-muted line-through' : 'text-tg-text'}`}>{m.title}</h4>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className={`text-[8px] font-black uppercase tracking-widest ${
                                m.type === 'urgent' ? 'text-red-500' : 
                                m.type === 'special' ? 'text-purple-500' : 
                                'text-blue-500'
                              }`}>{m.type}</span>
                              <span className="text-tg-border">•</span>
                              <span className="text-[8px] font-black text-tg-text-muted uppercase tracking-widest">{m.reward}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button 
                            onClick={async () => {
                              if (confirm('آیا از آرشیو کردن این ماموریت اطمینان دارید؟')) {
                                const updatedMissions = missions.map(mission => mission.id === m.id ? { ...mission, isArchived: true } : mission);
                                await updateDb('operations.missions', updatedMissions);
                              }
                            }}
                            className="p-2 bg-white/5 hover:bg-amber-500/10 text-slate-400 hover:text-amber-500 rounded-xl transition-all"
                            title="آرشیو ماموریت"
                          >
                            <Archive size={16} />
                          </button>
                          <button 
                            onClick={() => setEditingMission(m)}
                            className="p-2 bg-white/5 hover:bg-blue-500/10 text-slate-400 hover:text-blue-500 rounded-xl transition-all"
                          >
                            <Edit3 size={16} />
                          </button>
                          <button 
                            onClick={() => handleDeleteMission(m.id)}
                            className="p-2 bg-white/5 hover:bg-red-500/10 text-slate-400 hover:text-red-500 rounded-xl transition-all"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>

                      <p className="text-[10px] text-slate-400 font-medium leading-relaxed line-clamp-2">{m.description}</p>

                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-2">
                          <div className="flex -space-x-2">
                            {[1, 2, 3].map(i => (
                              <div key={i} className="w-6 h-6 rounded-full border-2 border-[#171e28] bg-slate-800 flex items-center justify-center text-[8px] font-black">
                                {i}
                              </div>
                            ))}
                          </div>
                          <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">
                            {tasks.filter(t => t.missionId === m.id).length} وظیفه فعال
                          </span>
                        </div>
                        <button 
                          onClick={() => setSelectedAdminMissionId(m.id)}
                          className="text-[9px] font-black text-blue-500 uppercase tracking-widest flex items-center gap-1 hover:gap-2 transition-all"
                        >
                          مدیریت وظایف
                          <ChevronLeft size={14} />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))}
                {missions.length === 0 && (
                  <div className="text-center py-12 bg-white/5 rounded-[2rem] border border-dashed border-white/10">
                    <p className="text-xs text-slate-500 font-bold">هیچ ماموریت فعالی وجود ندارد.</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {missions.filter(m => m.id === selectedAdminMissionId).map(m => (
                  <div key={m.id} className="bg-blue-500/5 border border-blue-500/20 p-4 rounded-3xl space-y-2">
                    <h4 className="text-xs font-black text-blue-500">{m.title}</h4>
                    <p className="text-[10px] text-slate-400 leading-relaxed">{m.description}</p>
                  </div>
                ))}
                
                <div className="flex justify-between items-center px-1">
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">لیست وظایف عملیاتی</p>
                  {user?.role === 'admin' || user?.role === 'manager' || user?.unitLevel === 'nahiye' || (user?.unitLevel === 'howze' && user?.isTrusted) ? (
                    <button 
                      onClick={() => setShowAddTask({missionId: selectedAdminMissionId})}
                      className="flex items-center gap-1.5 py-2 px-4 bg-blue-500 text-white rounded-xl font-black text-[9px] uppercase tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
                    >
                      <Plus size={14} />
                      افزودن وظیفه جدید
                    </button>
                  ) : null}
                </div>

                <div className="grid grid-cols-1 gap-3">
                  {tasks.filter(t => t.missionId === selectedAdminMissionId).map(t => (
                    <div key={t.id} className="bg-tg-surface p-4 rounded-3xl border border-tg-border group/task flex justify-between items-center shadow-sm">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-2xl flex items-center justify-center border border-white/5 ${
                          t.platform === 'twitter' ? 'bg-blue-500/10 text-blue-500' : 
                          t.platform === 'instagram' ? 'bg-pink-500/10 text-pink-500' : 
                          'bg-slate-500/10 text-slate-400'
                        }`}>
                          {t.platform === 'twitter' ? <Twitter size={18} /> : <Target size={18} />}
                        </div>
                        <div>
                          <h5 className="text-[11px] font-black">{t.title}</h5>
                          <div className="flex items-center gap-2 mt-0.5">
                            {t.department && (
                              <span className="text-[7px] font-black bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded-md border border-blue-500/20 uppercase">
                                {t.department}
                              </span>
                            )}
                            <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">{t.platform}</span>
                            <span className="text-slate-700">•</span>
                            <span className="text-[8px] font-black text-blue-500 uppercase tracking-widest">{t.points} امتیاز</span>
                            {t.deadline && (
                              <>
                                <span className="text-slate-700">•</span>
                                <span className="text-[8px] font-black text-amber-500 uppercase tracking-widest flex items-center gap-1">
                                  <Clock size={10} />
                                  {t.deadline.includes('T') ? new Date(t.deadline).toLocaleString('fa-IR', { hour: '2-digit', minute: '2-digit' }) : t.deadline}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {t.status === 'submitted' && (
                          <button 
                            onClick={async () => {
                              if (!confirm('آیا از تایید این وظیفه اطمینان دارید؟')) return;
                              const updatedTasks = tasks.map(task => task.id === t.id ? { ...task, status: 'completed' as any } : task);
                              await updateDb('operations.tasks', updatedTasks);
                              
                              // Check if all tasks for this mission are completed
                              const missionTasks = updatedTasks.filter(task => task.missionId === t.missionId);
                              const allCompleted = missionTasks.every(task => task.status === 'completed');
                              if (allCompleted) {
                                const updatedMissions = missions.map(m => m.id === t.missionId ? { ...m, isArchived: true } : m);
                                await updateDb('operations.missions', updatedMissions);
                                setToast({ message: 'ماموریت با موفقیت انجام و آرشیو شد', type: 'success' });
                              } else {
                                setToast({ message: 'وظیفه تایید شد', type: 'success' });
                              }
                            }}
                            className="p-2 bg-emerald-500/10 text-emerald-500 rounded-xl hover:bg-emerald-500/20 transition-all"
                            title="تایید وظیفه"
                          >
                            <CheckCircle2 size={16} />
                          </button>
                        )}
                        <button 
                          onClick={() => handleDeleteTask(t.id)}
                          className="p-2 bg-white/5 hover:bg-red-500/10 text-slate-400 hover:text-red-500 rounded-xl transition-all"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                  {tasks.filter(t => t.missionId === selectedAdminMissionId).length === 0 && (
                    <div className="text-center py-8 bg-white/5 rounded-3xl border border-dashed border-white/10">
                      <p className="text-[10px] text-slate-500 font-bold">هنوز وظیفه‌ای برای این ماموریت تعریف نشده است.</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {activeSubTab === 'users' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black text-tg-text">مدیریت کاربران و عوامل</h3>
                <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">مدیریت پرسنل و دارایی‌ها</p>
              </div>
              <button 
                onClick={() => setShowAddUser(true)}
                className="p-2 bg-tg-accent text-white rounded-xl shadow-lg shadow-tg-accent/10 active:scale-95 transition-all"
              >
                <UserPlus size={18} />
              </button>
            </div>
            
            <div className="space-y-3">
              {users.map(u => (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={u.uid} 
                  className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex items-center gap-4 group hover:border-blue-500/30 transition-all shadow-sm"
                >
                  <div className="relative">
                    <div className="w-14 h-14 bg-black/5 dark:bg-white/5 rounded-2xl flex items-center justify-center text-xl font-black border border-tg-border group-hover:border-tg-accent/50 transition-all text-tg-text">
                      {u.name[0]}
                    </div>
                    <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-tg-surface ${u.role === 'admin' ? 'bg-red-500' : u.role === 'manager' ? 'bg-blue-500' : 'bg-emerald-500'}`} />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-black truncate">{u.name}</h4>
                      <span className={`text-[7px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter ${
                        u.role === 'admin' ? 'bg-red-500/10 text-red-500' : 
                        u.role === 'manager' ? 'bg-blue-500/10 text-blue-500' : 'bg-emerald-500/10 text-emerald-500'
                      }`}>
                        {u.role}
                      </span>
                      {user.isTrusted && (
                        <span className="bg-amber-500/10 text-amber-500 text-[6px] font-black px-1 py-0.5 rounded border border-amber-500/20">TRUSTED</span>
                      )}
                    </div>
                    <p className="text-[10px] text-tg-text-muted font-mono mt-0.5" dir="ltr">{u.phone}</p>
                    <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                      {u.departments?.map(d => (
                        <span key={d} className="bg-blue-500/5 text-blue-400 text-[7px] font-black px-2 py-0.5 rounded-full border border-blue-500/10">
                          {d === 'shamsa' ? 'شمسا' : d === 'matna' ? 'متنا' : d === 'nasra' ? 'نصرا' : 'رسانه محله'}
                        </span>
                      ))}
                      {(!u.departments || u.departments.length === 0) && (
                        <span className="text-[7px] text-tg-text-muted font-black border border-tg-border px-2 rounded-full">بدون دپارتمان</span>
                      )}
                    </div>
                    <div className="flex items-center gap-3 mt-1 pt-1 border-t border-tg-border">
                      <div className="flex items-center gap-1">
                        <Trophy size={10} className="text-orange-500" />
                        <span className="text-[9px] font-black text-tg-text-muted">{u.points}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Zap size={10} className="text-blue-500" />
                        <span className="text-[9px] font-black text-tg-text-muted">Lvl {u.level}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button 
                      onClick={() => {
                        const newRole: UserRole = u.role === 'admin' ? 'user' : u.role === 'manager' ? 'admin' : 'manager';
                        const updatedUsers = users.map(user => user.uid === u.uid ? { ...user, role: newRole } : user);
                        updateDb('auth.users', updatedUsers);
                        setToast({ message: `نقش ${u.name} به ${newRole} تغییر یافت`, type: 'success' });
                      }}
                      className="p-2 bg-black/5 dark:bg-white/5 hover:bg-blue-500/10 text-tg-text-muted hover:text-blue-500 rounded-xl transition-all border border-tg-border shadow-sm"
                      title="تغییر نقش"
                    >
                      <Shield size={16} />
                    </button>
                    <button 
                      onClick={() => setEditingUser(u)}
                      className="p-2 bg-black/5 dark:bg-white/5 hover:bg-blue-500/10 text-tg-text-muted hover:text-blue-500 rounded-xl transition-all border border-tg-border shadow-sm"
                    >
                      <Edit3 size={16} />
                    </button>
                    {u.uid !== user.uid && (
                      <button 
                        onClick={async () => {
                          if (confirm('آیا از حذف این کاربر اطمینان دارید؟')) {
                            await updateDb('auth.users', users.filter(user => user.uid !== u.uid));
                          }
                        }}
                        className="p-2 bg-black/5 dark:bg-white/5 hover:bg-red-500/10 text-tg-text-muted hover:text-red-500 rounded-xl transition-all border border-tg-border shadow-sm"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {activeSubTab === 'content' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <div className="space-y-1">
                <h3 className="text-sm font-black text-tg-text">مدیریت بانک محتوا</h3>
                <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">مدیریت مخزم محتوا</p>
              </div>
              <button 
                onClick={() => setShowAddContent(true)}
                className="p-2 bg-tg-accent text-white rounded-xl shadow-lg shadow-tg-accent/10 active:scale-95 transition-all"
              >
                <Plus size={18} />
              </button>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {content.map(c => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={c.id} 
                  className="bg-tg-surface rounded-[2rem] border border-tg-border overflow-hidden group hover:border-blue-500/30 transition-all shadow-sm"
                >
                  <div className="p-5 space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex gap-3">
                        <div className="w-10 h-10 bg-black/5 dark:bg-white/5 rounded-xl flex items-center justify-center text-tg-accent border border-tg-border">
                          {c.type === 'poster' ? <ImageIcon size={20} /> : c.type === 'video' ? <Video size={20} /> : <FileText size={20} />}
                        </div>
                        <div>
                          <h4 className="text-xs font-black">{c.title}</h4>
                          <div className="flex gap-2 mt-1">
                            {c.hashtags.slice(0, 2).map(h => (
                              <span key={h} className="text-[8px] font-black text-blue-500">#{h}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <button 
                          onClick={async () => {
                            const updated = content.map(item => item.id === c.id ? { ...item, isPublished: !item.isPublished } : item);
                            await updateDb('content.library', updated);
                          }}
                          className={`text-[8px] font-black px-2 py-1 rounded-lg transition-all ${
                            c.isPublished ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-800 text-slate-500'
                          }`}
                        >
                          {c.isPublished ? 'منتشر شده' : 'پیش‌نویس'}
                        </button>
                      </div>
                    </div>
                    
                    <p className="text-[10px] text-tg-text-muted font-medium leading-relaxed line-clamp-2">{c.content}</p>
                    
            <div className="flex items-center justify-between pt-4 border-t border-tg-border">
              <div className="flex gap-4">
                <div className="flex items-center gap-1.5">
                  <Download size={12} className="text-tg-text-muted" />
                  <span className="text-[10px] font-black text-tg-text-muted">{c.downloadCount}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Eye size={12} className="text-tg-text-muted" />
                  <span className="text-[10px] font-black text-tg-text-muted">{c.downloadCount * 4}</span>
                </div>
              </div>
              
              <div className="flex gap-2">
                <button 
                  onClick={() => onShare(c)}
                  className="p-2 bg-black/5 dark:bg-white/5 hover:bg-blue-500/10 text-tg-text-muted hover:text-blue-500 rounded-xl transition-all border border-tg-border shadow-sm"
                  title="اشتراک گذاری"
                >
                  <Share2 size={14} />
                </button>
                <button 
                  onClick={() => setEditingContent(c)}
                  className="p-2 bg-black/5 dark:bg-white/5 hover:bg-blue-500/10 text-tg-text-muted hover:text-blue-500 rounded-xl transition-all border border-tg-border shadow-sm"
                >
                  <Edit3 size={14} />
                </button>
                <button 
                  onClick={async () => {
                    if (confirm('آیا از حذف این محتوا اطمینان دارید؟')) {
                      await updateDb('content.library', content.filter(item => item.id !== c.id));
                    }
                  }}
                  className="p-2 bg-black/5 dark:bg-white/5 hover:bg-red-500/10 text-tg-text-muted hover:text-red-500 rounded-xl transition-all border border-tg-border shadow-sm"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Modals for Admin Actions */}
        <BottomSheet isOpen={showAddMission} onClose={() => setShowAddMission(false)} title="افزودن ماموریت جدید">
        <div className="space-y-4">
          <input placeholder="عنوان ماموریت" className="tg-input" value={newMission.title} onChange={e => setNewMission({...newMission, title: e.target.value})} />
          <textarea placeholder="توضیحات" className="tg-input" value={newMission.description} onChange={e => setNewMission({...newMission, description: e.target.value})} />
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-[8px] font-black text-tg-text-muted uppercase px-1">نوع ماموریت</label>
              <select className="tg-input" value={newMission.type} onChange={e => setNewMission({...newMission, type: e.target.value as any})}>
                <option value="daily">روزانه</option>
                <option value="urgent">فوری</option>
                <option value="special">ویژه</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-[8px] font-black text-tg-text-muted uppercase px-1">دسته‌بندی</label>
              <select className="tg-input" value={newMission.category} onChange={e => setNewMission({...newMission, category: e.target.value as any})}>
                <option value="social">شبکه‌های اجتماعی</option>
                <option value="intelligence">رصد و پایش</option>
                <option value="content">تولید محتوا</option>
                <option value="technical">فنی و سایبری</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-[8px] font-black text-tg-text-muted uppercase px-1">سطح دشواری</label>
              <select className="tg-input" value={newMission.difficulty} onChange={e => setNewMission({...newMission, difficulty: e.target.value as any})}>
                <option value="easy">آسان</option>
                <option value="medium">متوسط</option>
                <option value="hard">سخت</option>
                <option value="expert">حرفه‌ای</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-[8px] font-black text-tg-text-muted uppercase px-1">پاداش عملیاتی</label>
              <input placeholder="مثلا: ۵۰۰ امتیاز" className="tg-input" value={newMission.reward} onChange={e => setNewMission({...newMission, reward: e.target.value})} />
            </div>
          </div>
          <button onClick={handleAddMission} className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black shadow-lg shadow-emerald-500/20">ثبت و انتشار ماموریت</button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={!!showAddTask} onClose={() => setShowAddTask(null)} title="انتشار وظیفه جدید">
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-tg-text-muted uppercase px-2">هدف و عنوان وظیفه</label>
            <input 
              placeholder="مثلاً: بازنشر محتوای عملیاتی..." 
              className="tg-input" 
              value={newTask.title} 
              onChange={e => setNewTask({...newTask, title: e.target.value})} 
            />
          </div>
          
          <div className="space-y-4 p-4 bg-blue-500/5 rounded-2xl border border-blue-500/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] font-black text-tg-text">وظیفه آموزشی (نصرا)</p>
                <p className="text-[8px] text-tg-text-muted font-bold uppercase">آموزش، وبینار و رزمایش سواد رسانه</p>
              </div>
              <button 
                type="button"
                onClick={() => setNewTask({...newTask, isNasra: !newTask.isNasra, department: !newTask.isNasra ? 'nasra' : newTask.department})}
                className={`w-10 h-5 rounded-full relative transition-all ${newTask.isNasra ? 'bg-blue-500 shadow-lg shadow-blue-500/30' : 'bg-black/10 dark:bg-white/5 border border-tg-border'}`}
              >
                <div className={`absolute top-1 w-3 h-3 bg-white rounded-full shadow-sm transition-all ${newTask.isNasra ? 'right-1' : 'right-6'}`} />
              </button>
            </div>

            {newTask.isNasra && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} className="space-y-3 pt-2">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-tg-text-muted uppercase px-1">نوع آموزش</label>
                  <select 
                    className="tg-input" 
                    value={newTask.nasraType} 
                    onChange={e => setNewTask({...newTask, nasraType: e.target.value as any})}
                  >
                    <option value="webinar">وبینار اسکای‌روم</option>
                    <option value="live">پخش زنده (Rubika)</option>
                    <option value="video">نمایش ویدیو</option>
                    <option value="article">مطالعه مقاله</option>
                    <option value="tutorial">آموزش گام‌به‌گام (Tutorial)</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-tg-text-muted uppercase px-1">لینک ورود به جلسه / آموزش</label>
                  <input 
                    placeholder="https://skyroom.online/ch/..." 
                    className="tg-input" 
                    value={newTask.nasraUrl} 
                    onChange={e => setNewTask({...newTask, nasraUrl: e.target.value})} 
                  />
                </div>
              </motion.div>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-tg-text-muted uppercase px-2">دپارتمان عملیاتی (رسته)</label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'shamsa', label: 'شمسا (توییتر/اینستاگرام)' },
                { id: 'matna', label: 'متنا (تولید محتوا)' },
                { id: 'nasra', label: 'نصرا (آموزش)' },
                { id: 'resane_mahale', label: 'رسانه محله' }
              ].map(dept => (
                <button
                  key={dept.id}
                  type="button"
                  onClick={() => setNewTask({...newTask, department: dept.id as any})}
                  className={`px-3 py-2 text-[8px] font-black rounded-xl border transition-all ${
                    newTask.department === dept.id 
                    ? 'bg-blue-500 border-blue-400 text-white shadow-lg shadow-blue-500/20' 
                    : 'bg-black/5 dark:bg-white/5 border-tg-border text-tg-text-muted hover:bg-black/10 transition-colors'
                  }`}
                >
                  {dept.label}
                </button>
              ))}
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-tg-text-muted uppercase px-2">پلتفرم هدف</label>
              <select 
                className="tg-input" 
                value={newTask.platform} 
                onChange={e => setNewTask({...newTask, platform: e.target.value as any})}
              >
                <option value="twitter">توییتر / X</option>
                <option value="instagram">اینستاگرام</option>
                <option value="bale">بله</option>
                <option value="other">سایر</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-tg-text-muted uppercase px-2">امتیاز پاداش</label>
              <input 
                placeholder="100" 
                type="number" 
                className="tg-input" 
                value={newTask.points} 
                onChange={e => setNewTask({...newTask, points: e.target.value})} 
              />
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center px-2">
              <label className="text-[10px] font-black text-tg-text-muted uppercase">مراحل عملیاتی (توالی اقدامات)</label>
              <button 
                onClick={() => setNewTask({...newTask, steps: [...newTask.steps, '']})}
                className="text-[10px] font-black text-blue-500 hover:underline"
              >
                + افزودن گام جدید
              </button>
            </div>
            <div className="space-y-2">
              {newTask.steps.map((step, i) => (
                <div key={i} className="flex gap-2">
                  <div className="w-8 h-10 bg-black/5 dark:bg-white/5 rounded-xl flex items-center justify-center text-[10px] font-black text-tg-text-muted border border-tg-border shadow-sm">
                    {i + 1}
                  </div>
                  <input 
                    placeholder={`توضیح گام ${i + 1} عملیات...`}
                    className="tg-input flex-1 text-xs"
                    value={step}
                    onChange={e => {
                      const updatedSteps = [...newTask.steps];
                      updatedSteps[i] = e.target.value;
                      setNewTask({...newTask, steps: updatedSteps});
                    }}
                  />
                  <button 
                    onClick={() => setNewTask({...newTask, steps: newTask.steps.filter((_, idx) => idx !== i)})}
                    className="w-10 h-10 bg-red-500/10 text-red-500 rounded-xl flex items-center justify-center hover:bg-red-500/20 transition-all border border-tg-border"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              {newTask.steps.length === 0 && (
                <p className="text-[9px] text-tg-text-muted font-bold text-center py-2 border border-dashed border-tg-border rounded-2xl italic">گامی تعریف نشده است. این یک وظیفه تک‌مرحله‌ای خواهد بود.</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-tg-text-muted uppercase px-2">مهلت انجام (Deadline)</label>
            <input 
              type="datetime-local"
              className="tg-input text-tg-text" 
              value={newTask.deadline} 
              onChange={e => setNewTask({...newTask, deadline: e.target.value})} 
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-tg-text-muted uppercase px-2">واگذاری به کارشناس (Assign to User)</label>
            <select 
              className="tg-input" 
              value={newTask.assignedTo} 
              onChange={e => setNewTask({...newTask, assignedTo: e.target.value})}
            >
              <option value="">انتشار عمومی (بدون واگذاری)</option>
              {users.map(u => (
                <option key={u.uid} value={u.uid}>{u.name} ({u.rank})</option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-tg-text-muted uppercase px-2">محتوای آموزشی مرتبط</label>
            <select 
              className="tg-input" 
              value={newTask.educationId} 
              onChange={e => setNewTask({...newTask, educationId: e.target.value})}
            >
              <option value="">بدون محتوای آموزشی</option>
              {educationItems.map(item => (
                <option key={item.id} value={item.id}>{item.title}</option>
              ))}
            </select>
          </div>

          <div className="space-y-4 border-t border-tg-border pt-4">
            <label className="text-[10px] font-black text-tg-text-muted uppercase px-2">محتوای عملیاتی (Caption & Body)</label>
            <input 
              placeholder="کپشن محتوا..." 
              className="tg-input" 
              value={newTask.contentCaption} 
              onChange={e => setNewTask({...newTask, contentCaption: e.target.value})} 
            />
            <textarea 
              placeholder="متن اصلی محتوا..." 
              className="tg-input h-24" 
              value={newTask.contentBody} 
              onChange={e => setNewTask({...newTask, contentBody: e.target.value})} 
            />
            <input 
              placeholder="لینک تصویر محتوا (URL)..." 
              className="tg-input" 
              value={newTask.contentImage} 
              onChange={e => setNewTask({...newTask, contentImage: e.target.value})} 
            />
          </div>

          <button 
            onClick={handleAddTask} 
            className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
          >
            Confirm Deployment
          </button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={!!showRejectTask} onClose={() => setShowRejectTask(null)} title="رد وظیفه عملیاتی">
        <div className="space-y-4">
          <p className="text-xs text-tg-text-muted font-bold">لطفاً دلیل رد را بنویسید:</p>
          <textarea placeholder="دلیل رد..." className="tg-input h-32" value={rejectFeedback} onChange={e => setRejectFeedback(e.target.value)} />
          <button onClick={handleRejectTask} className="w-full py-4 bg-red-500 text-white rounded-2xl font-black shadow-lg shadow-red-500/20 active:scale-95 transition-all">ارسال بازخورد و رد نهایی</button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={showAddReport} onClose={() => setShowAddReport(false)} title="ایجاد گزارش تحلیلی جدید">
        <div className="space-y-4">
          <input placeholder="عنوان گزارش" className="tg-input" value={newReport.title} onChange={e => setNewReport({...newReport, title: e.target.value})} />
          <select className="tg-input" value={newReport.category} onChange={e => setNewReport({...newReport, category: e.target.value as any})}>
            <option value="analysis">تحلیلی</option>
            <option value="operational">عملیاتی</option>
            <option value="security">امنیتی</option>
          </select>
          <textarea placeholder="متن گزارش..." className="tg-input h-48" value={newReport.content} onChange={e => setNewReport({...newReport, content: e.target.value})} />
          <button 
            onClick={async () => {
              if (newReport.title) {
                const report = { 
                  id: `rep-${Date.now()}`, 
                  title: newReport.title, 
                  content: newReport.content, 
                  date: new Date().toISOString(), 
                  author: user.name,
                  category: newReport.category 
                };
                await updateDb('operations.reports', [...reports, report]);
                setShowAddReport(false);
                setNewReport({ title: '', content: '', category: 'analysis' });
              }
            }} 
            className="w-full py-4 bg-tg-accent text-white rounded-2xl font-black shadow-lg shadow-tg-accent/20"
          >
            ثبت و انتشار گزارش
          </button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={showAddAccount} onClose={() => setShowAddAccount(false)} title="افزودن اکانت به لیست رصد">
        <div className="space-y-4">
          <input placeholder="نام نمایشی" className="tg-input" value={newAccount.name} onChange={e => setNewAccount({...newAccount, name: e.target.value})} />
          <input placeholder="آدرس اکانت (handle@)" className="tg-input" value={newAccount.handle} onChange={e => setNewAccount({...newAccount, handle: e.target.value})} />
          <div className="flex gap-2">
            <select className="tg-input flex-1" value={newAccount.platform} onChange={e => setNewAccount({...newAccount, platform: e.target.value as any})}>
              <option value="twitter">توییتر</option>
              <option value="instagram">اینستاگرام</option>
              <option value="bale">بله</option>
            </select>
            <select className="tg-input flex-1" value={newAccount.category} onChange={e => setNewAccount({...newAccount, category: e.target.value as any})}>
              <option value="enemy">معاند</option>
              <option value="friendly">خودی</option>
              <option value="neutral">خنثی</option>
            </select>
          </div>
          <button 
            onClick={async () => {
              if (newAccount.handle) {
                const acc = { ...newAccount, id: `acc-${Date.now()}`, lastActivity: new Date().toISOString(), status: 'active' as any };
                const updated = [...trackedAccounts, acc];
                setTrackedAccounts(updated);
                await updateDb('tracking.accounts', updated);
                setShowAddAccount(false);
                setNewAccount({ handle: '', name: '', platform: 'twitter', category: 'enemy' });
              }
            }} 
            className="w-full py-4 bg-tg-accent text-white rounded-2xl font-black shadow-lg shadow-tg-accent/20 active:scale-95 transition-all"
          >
            افزودن به لیست
          </button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={showAddSale} onClose={() => setShowAddSale(false)} title="ثبت تراکنش مالی جدید">
        <div className="space-y-4">
          <input placeholder="عنوان تراکنش" className="tg-input" value={newSale.title} onChange={e => setNewSale({...newSale, title: e.target.value})} />
          <input placeholder="مبلغ (ریال)" type="number" className="tg-input" value={newSale.amount} onChange={e => setNewSale({...newSale, amount: e.target.value})} />
          <button 
            onClick={async () => {
              if (newSale.title && newSale.amount) {
                const record = { id: `sale-${Date.now()}`, title: newSale.title, amount: parseInt(newSale.amount), date: new Date().toISOString(), recordedBy: user.uid, status: 'verified' as any };
                setShowAddSale(false);
                setNewSale({ title: '', amount: '' });
              }
            }} 
            className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black"
          >
            ثبت تراکنش
          </button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={showAddEducation} onClose={() => setShowAddEducation(false)} title="افزودن محتوای آموزشی">
        <div className="space-y-4">
          <input placeholder="عنوان آموزش" className="tg-input" value={newEducation.title} onChange={e => setNewEducation({...newEducation, title: e.target.value})} />
          <textarea placeholder="توضیحات" className="tg-input" value={newEducation.description} onChange={e => setNewEducation({...newEducation, description: e.target.value})} />
          <input placeholder="لینک تصویر کاور" className="tg-input" value={newEducation.coverImage} onChange={e => setNewEducation({...newEducation, coverImage: e.target.value})} />
          <button 
            onClick={handleAddEducation} 
            className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black"
          >
            ایجاد آموزش
          </button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={!!showAddSession} onClose={() => setShowAddSession(null)} title="افزودن جلسه جدید">
        <div className="space-y-4">
          <input placeholder="عنوان جلسه" className="tg-input" value={newSession.title} onChange={e => setNewSession({...newSession, title: e.target.value})} />
          <select className="tg-input" value={newSession.type} onChange={e => setNewSession({...newSession, type: e.target.value as any})}>
            <option value="video">ویدیو</option>
            <option value="audio">صوت</option>
            <option value="text">متن</option>
            <option value="html">HTML</option>
          </select>
          <textarea placeholder="محتوا (لینک یا متن)" className="tg-input h-32" value={newSession.content} onChange={e => setNewSession({...newSession, content: e.target.value})} />
          <button 
            onClick={handleAddSession} 
            className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black"
          >
            افزودن جلسه
          </button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={showAddContent} onClose={() => setShowAddContent(false)} title="افزودن محتوای جدید">
        <div className="space-y-4">
          <input placeholder="عنوان محتوا" className="tg-input" value={newContent.title} onChange={e => setNewContent({...newContent, title: e.target.value})} />
          <textarea placeholder="متن محتوا..." className="tg-input h-32" value={newContent.content} onChange={e => setNewContent({...newContent, content: e.target.value})} />
          <input placeholder="هشتگ‌ها (با فاصله جدا کنید)" className="tg-input" value={newContent.hashtags} onChange={e => setNewContent({...newContent, hashtags: e.target.value})} />
          <button 
            onClick={async () => {
              if (newContent.title) {
                const item = { 
                  ...newContent, 
                  id: `c-${Date.now()}`, 
                  type: 'tweet', 
                  isPublished: true, 
                  downloadCount: 0, 
                  hashtags: newContent.hashtags.split(/[ ,]+/).filter(Boolean) 
                };
                await updateDb('content.library', [...content, item]);
                setShowAddContent(false);
                setNewContent({ title: '', content: '', hashtags: '' });
              }
            }} 
            className="w-full py-4 bg-tg-accent text-white rounded-2xl font-black shadow-lg shadow-tg-accent/20 active:scale-95 transition-all"
          >
            ثبت محتوا
          </button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={!!editingMission} onClose={() => setEditingMission(null)} title="ویرایش ماموریت">
        {editingMission && (
          <div className="space-y-4">
            <input placeholder="عنوان ماموریت" className="tg-input" value={editingMission.title} onChange={e => setEditingMission({...editingMission, title: e.target.value})} />
            <textarea placeholder="توضیحات" className="tg-input" value={editingMission.description} onChange={e => setEditingMission({...editingMission, description: e.target.value})} />
            <div className="flex gap-2">
              <select className="tg-input flex-1" value={editingMission.type} onChange={e => setEditingMission({...editingMission, type: e.target.value as any})}>
                <option value="daily">روزانه</option>
                <option value="urgent">فوری</option>
                <option value="special">ویژه</option>
              </select>
              <input placeholder="پاداش" className="tg-input flex-1" value={editingMission.reward} onChange={e => setEditingMission({...editingMission, reward: e.target.value})} />
            </div>
            <button onClick={handleEditMission} className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black">ذخیره تغییرات</button>
          </div>
        )}
      </BottomSheet>

      <BottomSheet isOpen={showAddUser} onClose={() => setShowAddUser(false)} title="افزودن کاربر جدید">
        <div className="space-y-4">
          <input placeholder="نام و نام خانوادگی" className="tg-input" value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} />
          <input placeholder="شماره تماس" className="tg-input" value={newUser.phone} onChange={e => setNewUser({...newUser, phone: e.target.value})} />
          <input type="password" placeholder="رمز عبور عملیاتی" className="tg-input" value={newUser.password} onChange={e => setNewUser({...newUser, password: e.target.value})} />
          
          <div className="space-y-1.5 px-1">
            <label className="text-[9px] font-black text-tg-text-muted uppercase">انتخاب واحد سازمانی</label>
            <select className="tg-input" value={newUser.unitId} onChange={e => setNewUser({...newUser, unitId: e.target.value})}>
              <option value="">بدون واحد (مدیر کل ستادی)</option>
              {organizationalUnits.map(u => (
                <option key={u.id} value={u.id}>{u.name} ({u.level === 'nahiye' ? 'ناحیه' : u.level === 'howze' ? 'حوزه' : u.level === 'paygah' ? 'پایگاه' : 'گردان'})</option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5 px-1">
            <label className="text-[9px] font-black text-tg-text-muted uppercase">دپارتمان تخصصی (اختیاری)</label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'shamsa', label: 'شمسا (توییتر/اینستاگرام)' },
                { id: 'matna', label: 'متنا (تولید محتوا)' },
                { id: 'nasra', label: 'نصرا (سواد رسانه)' },
                { id: 'resane_mahale', label: 'رسانه محله (پایش)' }
              ].map(dept => (
                <button
                  key={dept.id}
                  onClick={() => {
                    const depts = newUser.departments || [];
                    if (depts.includes(dept.id as any)) {
                      setNewUser({...newUser, departments: depts.filter(d => d !== dept.id)});
                    } else {
                      setNewUser({...newUser, departments: [...depts, dept.id as any]});
                    }
                  }}
                  className={`p-2.5 text-[8px] font-black rounded-xl border transition-all ${
                    (newUser.departments || []).includes(dept.id as any) 
                    ? 'bg-blue-500 border-blue-400 text-white shadow-lg shadow-blue-500/20' 
                    : 'bg-black/5 dark:bg-white/5 border-tg-border text-tg-text-muted'
                  }`}
                >
                  {dept.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1.5 px-1 flex items-center justify-between bg-black/5 dark:bg-white/5 p-3 rounded-2xl border border-tg-border shadow-sm">
            <div>
              <p className="text-[10px] font-black text-tg-text">کاربر مورد اعتماد (Trusted)</p>
              <p className="text-[7px] text-tg-text-muted font-bold uppercase">اجازه ابلاغ وظیفه در سطح حوزه</p>
            </div>
            <button 
              onClick={() => setNewUser({...newUser, isTrusted: !(newUser as any).isTrusted})}
              className={`w-10 h-5 rounded-full relative transition-all ${(newUser as any).isTrusted ? 'bg-emerald-500 shadow-lg shadow-emerald-500/30' : 'bg-black/10 dark:bg-white/5 border border-tg-border'}`}
            >
              <div className={`absolute top-1 w-3 h-3 bg-white rounded-full shadow-sm transition-all ${(newUser as any).isTrusted ? 'right-1' : 'right-6'}`} />
            </button>
          </div>

          <div className="space-y-1.5 px-1">
            <label className="text-[9px] font-black text-tg-text-muted uppercase">نقش سیستمی</label>
            <select className="tg-input" value={newUser.role} onChange={e => setNewUser({...newUser, role: e.target.value as any})}>
              <option value="user">افسر (کاربر معمولی)</option>
              <option value="manager">مدیر واحد (Howze/Paygah)</option>
              <option value="admin">مدیر فنی (Admin)</option>
            </select>
          </div>

          <button onClick={handleAddUser} className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black shadow-lg shadow-emerald-500/20 active:scale-95 transition-all">ثبت و ایجاد دسترسی</button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={!!editingUser} onClose={() => setEditingUser(null)} title="ویرایش اطلاعات کاربر">
        {editingUser && (
          <div className="space-y-4">
            <input placeholder="نام و نام خانوادگی" className="tg-input" value={editingUser.name} onChange={e => setEditingUser({...editingUser, name: e.target.value})} />
            <input placeholder="شماره تماس" className="tg-input" value={editingUser.phone} onChange={e => setEditingUser({...editingUser, phone: e.target.value})} />
            <input 
              type="password" 
              placeholder="تغییر رمز عبور (در صورت نیاز)" 
              className="tg-input" 
              value={editingUser.password || ''} 
              onChange={e => setEditingUser({...editingUser, password: e.target.value})} 
            />
            
            <div className="space-y-1.5 px-1">
              <label className="text-[9px] font-black text-tg-text-muted uppercase">واحد سازمانی</label>
              <select className="tg-input" value={editingUser.unitId || ''} onChange={e => setEditingUser({...editingUser, unitId: e.target.value})}>
                <option value="">بدون واحد</option>
                {organizationalUnits.map(u => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
              </select>
            </div>

            <select className="tg-input" value={editingUser.role} onChange={e => setEditingUser({...editingUser, role: e.target.value as any})}>
              <option value="user">کاربر</option>
              <option value="manager">مدیر واحد</option>
              <option value="admin">مدیر کل</option>
            </select>
            <button onClick={handleEditUser} className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black shadow-lg shadow-blue-500/20 active:scale-95 transition-all">بروزرسانی اطلاعات</button>
          </div>
        )}
      </BottomSheet>

      <BottomSheet isOpen={!!editingContent} onClose={() => setEditingContent(null)} title="ویرایش محتوا">
        {editingContent && (
          <div className="space-y-4">
            <input placeholder="عنوان محتوا" className="tg-input" value={editingContent.title} onChange={e => setEditingContent({...editingContent, title: e.target.value})} />
            <textarea placeholder="متن محتوا" className="tg-input h-32" value={editingContent.content} onChange={e => setEditingContent({...editingContent, content: e.target.value})} />
            <input 
              placeholder="هشتگ‌ها (با فاصله جدا کنید)" 
              className="tg-input" 
              value={editingContent.hashtags.join(' ')} 
              onChange={e => setEditingContent({...editingContent, hashtags: e.target.value.split(/[ ,]+/)})} 
            />
            <button 
              onClick={async () => {
                const cleaned = { ...editingContent, hashtags: editingContent.hashtags.filter(Boolean) };
                const updatedContent = content.map(c => c.id === cleaned.id ? cleaned : c);
                await updateDb('content.library', updatedContent);
                setEditingContent(null);
              }} 
              className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black"
            >
              ذخیره تغییرات
            </button>
          </div>
        )}
      </BottomSheet>

      <BottomSheet isOpen={!!editingEducation} onClose={() => setEditingEducation(null)} title="ویرایش دوره آموزشی">
        {editingEducation && (
          <div className="space-y-4">
            <input placeholder="عنوان دوره" className="tg-input" value={editingEducation.title} onChange={e => setEditingEducation({...editingEducation, title: e.target.value})} />
            <textarea placeholder="توضیحات دوره" className="tg-input" value={editingEducation.description} onChange={e => setEditingEducation({...editingEducation, description: e.target.value})} />
            <input placeholder="لینک تصویر کاور" className="tg-input" value={editingEducation.coverImage} onChange={e => setEditingEducation({...editingEducation, coverImage: e.target.value})} />
            <button onClick={handleEditEducation} className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black shadow-lg shadow-blue-500/20 active:scale-95 transition-all">بروزرسانی دوره</button>
          </div>
        )}
      </BottomSheet>

      <BottomSheet isOpen={!!editingSession} onClose={() => setEditingSession(null)} title="ویرایش جلسه آموزشی">
        {editingSession && (
          <div className="space-y-4">
            <input 
              placeholder="عنوان جلسه" 
              className="tg-input" 
              value={editingSession.session.title} 
              onChange={e => setEditingSession({
                ...editingSession, 
                session: { ...editingSession.session, title: e.target.value }
              })} 
            />
            <select 
              className="tg-input" 
              value={editingSession.session.type} 
              onChange={e => setEditingSession({
                ...editingSession, 
                session: { ...editingSession.session, type: e.target.value as any }
              })}
            >
              <option value="video">ویدیو</option>
              <option value="audio">صوت</option>
              <option value="text">متن</option>
              <option value="html">HTML</option>
            </select>
            <textarea 
              placeholder="محتوا (لینک یا متن)" 
              className="tg-input h-32" 
              value={editingSession.session.content} 
              onChange={e => setEditingSession({
                ...editingSession, 
                session: { ...editingSession.session, content: e.target.value }
              })} 
            />
            <button onClick={handleEditSession} className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black shadow-lg shadow-blue-500/20 active:scale-95 transition-all">بروزرسانی جلسه</button>
          </div>
        )}
      </BottomSheet>
    </div>
  </div>
);
};

const ExploreScreen = ({ content, onShare }: { content: ContentItem[], onShare: (i: ContentItem) => void }) => {
  const [selectedItem, setSelectedItem] = useState<ContentItem | null>(null);
  const [filter, setFilter] = useState<'all' | 'marked' | 'video' | 'image'>('all');

  const filteredContent = content.filter(item => {
    if (filter === 'marked') return item.isMarked;
    if (filter === 'video') return item.type === 'video';
    if (filter === 'poster') return item.type === 'poster';
    return true;
  });

  return (
    <div className="p-2 space-y-4 pb-24">
      <div className="px-2 pt-2">
        <div className="relative h-48 rounded-[2.5rem] overflow-hidden shadow-2xl mb-4">
          <img src="https://picsum.photos/seed/cyber/800/400" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-8">
            <h2 className="text-white text-2xl font-black tracking-tighter">ویترین دستاوردهای سایبری</h2>
            <p className="text-white/70 text-xs font-bold">برترین محتواهای تبیین در هفته اخیر</p>
          </div>
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
          {[
            { id: 'all', label: 'همه', icon: LayoutGrid },
            { id: 'marked', label: 'نشان شده', icon: Bookmark },
            { id: 'video', label: 'ویدیو', icon: Video },
            { id: 'poster', label: 'تصویر', icon: ImageIcon },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-[10px] font-black transition-all whitespace-nowrap border ${
                filter === f.id 
                ? 'bg-blue-500 text-white border-blue-500 shadow-lg shadow-blue-500/20' 
                : 'bg-tg-surface text-tg-text-muted border-tg-border'
              }`}
            >
              <f.icon size={14} />
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-0.5">
        {filteredContent.map((item, idx) => (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: idx * 0.02 }}
            key={item.id} 
            onClick={() => setSelectedItem(item)}
            className="aspect-square relative group cursor-pointer overflow-hidden"
          >
            <img 
              src={item.imageUrl || `https://picsum.photos/seed/${item.id}/400/400`} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
              referrerPolicy="no-referrer" 
            />
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 text-white">
              <div className="flex items-center gap-1 font-bold text-xs">
                <Download size={16} />
                <span>{item.downloadCount}</span>
              </div>
            </div>
            {item.type === 'video' && (
              <div className="absolute top-2 right-2 text-white drop-shadow-md">
                <Video size={16} />
              </div>
            )}
            {item.isMarked && (
              <div className="absolute top-2 left-2 text-amber-500 drop-shadow-md">
                <Bookmark size={16} fill="currentColor" />
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {filteredContent.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 opacity-30">
          <AlertCircle size={48} className="mb-4" />
          <p className="text-xs font-black">محتوایی یافت نشد</p>
        </div>
      )}

      <BottomSheet 
        isOpen={!!selectedItem} 
        onClose={() => setSelectedItem(null)} 
        title={selectedItem?.title || 'جزئیات محتوا'}
      >
        {selectedItem && (
          <div className="space-y-6">
            <div className="rounded-3xl overflow-hidden border border-slate-800">
              <img src={selectedItem.imageUrl || `https://picsum.photos/seed/${selectedItem.id}/800/800`} className="w-full" referrerPolicy="no-referrer" />
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-black">{selectedItem.title}</h3>
                  <p className="text-xs text-slate-500 font-bold">واحد تولید محتوای گردان</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={async () => {
                      if (!selectedItem) return;
                      const updated = content.map(item => 
                        item.id === selectedItem.id ? { ...item, isMarked: !item.isMarked } : item
                      );
                      // In a real app we'd update state here
                      setSelectedItem(updated.find(i => i.id === selectedItem.id) || null);
                      await fetch('/api/data/update', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ path: 'content.library', value: updated })
                      });
                    }}
                    className={`p-3 rounded-2xl transition-all ${selectedItem.isMarked ? 'bg-amber-500/10 text-amber-500' : 'bg-tg-surface text-tg-text-muted border border-tg-border'}`}
                  >
                    <Bookmark size={20} fill={selectedItem.isMarked ? 'currentColor' : 'none'} />
                  </button>
                  <button 
                    onClick={() => onShare(selectedItem)}
                    className="p-3 bg-tg-accent text-white rounded-2xl shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
                  >
                    <Share2 size={20} />
                  </button>
                </div>
              </div>

              <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-400 font-medium">
                {selectedItem.content}
              </p>

              <div className="flex flex-wrap gap-2">
                {selectedItem.hashtags.map((tag, i) => (
                  <span key={i} className="px-3 py-1.5 bg-tg-accent/10 text-tg-accent text-[10px] font-black rounded-full border border-tg-accent/20">
                    #{tag}
                  </span>
                ))}
              </div>

              <div className="pt-4 grid grid-cols-2 gap-3">
                <button className="flex items-center justify-center gap-2 py-4 bg-emerald-500 text-white rounded-2xl font-black text-xs shadow-lg shadow-emerald-500/20 active:scale-95 transition-all">
                  <Download size={18} />
                  <span>دریافت فایل اصلی</span>
                </button>
                <button className="flex items-center justify-center gap-2 py-4 bg-tg-text text-tg-bg rounded-2xl font-black text-xs active:scale-95 transition-all">
                  <ExternalLink size={18} />
                  <span>انتشار سریع</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </BottomSheet>
    </div>
  );
};

const AnalyticsScreen = () => {
  const stats = [
    { label: 'کل محتوای تولیدی', value: '۱۲,۴۵۰', change: '+۱۲٪', icon: Layout, color: '#3b82f6' },
    { label: 'مجموع بازدیدها', value: '۱.۲M', change: '+۴۵٪', icon: Eye, color: '#10b981' },
    { label: 'نرخ تعامل', value: '۸.۴٪', change: '+۲٪', icon: Activity, color: '#8b5cf6' },
    { label: 'ماموریت‌های موفق', value: '۹۴٪', change: '+۱٪', icon: Target, color: '#f59e0b' },
  ];

  const chartData = [
    { name: 'Sat', activity: 400, impact: 240 },
    { name: 'Sun', activity: 300, impact: 139 },
    { name: 'Mon', activity: 200, impact: 980 },
    { name: 'Tue', activity: 278, impact: 390 },
    { name: 'Wed', activity: 189, impact: 480 },
    { name: 'Thu', activity: 239, impact: 380 },
    { name: 'Fri', activity: 349, impact: 430 },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-2 gap-4">
        {stats.map((stat, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.1 }}
            className="p-5 rounded-[2.5rem] bg-tg-surface border border-tg-border hover:border-blue-500/30 transition-all group shadow-sm"
          >
            <div className="flex justify-between items-start mb-3">
              <div className="p-2.5 rounded-2xl bg-black/5 dark:bg-white/5 border border-tg-border group-hover:border-blue-500/50 transition-all">
                <stat.icon size={18} className="text-tg-text-muted group-hover:text-blue-500 transition-all" />
              </div>
              <span className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full">{stat.change}</span>
            </div>
            <p className="text-[10px] font-black text-tg-text-muted uppercase tracking-tighter mb-1">{stat.label}</p>
            <p className="text-xl font-black text-tg-text">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="bg-tg-surface p-6 rounded-[3rem] border border-tg-border shadow-xl space-y-6 transition-colors">
        <div className="flex justify-between items-center px-2">
          <div className="space-y-1">
            <h3 className="font-black text-sm text-tg-text">تحلیل عملکرد شبکه</h3>
            <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-widest">نمودار تعاملی فعالیت و اثرگذاری</p>
          </div>
          <div className="flex gap-4">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
              <span className="text-[10px] font-black text-tg-text-muted uppercase tracking-tighter">فعالیت</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="text-[10px] font-black text-tg-text-muted uppercase tracking-tighter">اثرگذاری</span>
            </div>
          </div>
        </div>
        
        <div className="h-64 w-full ltr">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorActivity" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorImpact" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--tg-surface)', 
                  border: '1px solid var(--tg-border)', 
                  borderRadius: '1.5rem',
                  fontSize: '10px',
                  fontWeight: '900',
                  color: 'var(--tg-text)'
                }} 
              />
              <Area 
                type="monotone" 
                dataKey="activity" 
                stroke="#3b82f6" 
                strokeWidth={3}
                fillOpacity={1} 
                fill="url(#colorActivity)" 
              />
              <Area 
                type="monotone" 
                dataKey="impact" 
                stroke="#10b981" 
                strokeWidth={3}
                fillOpacity={1} 
                fill="url(#colorImpact)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-black text-xs uppercase tracking-widest text-tg-text-muted px-4">رتبه‌بندی واحدهای عملیاتی</h3>
        {[
          { name: 'واحد رصد تهران (شمال)', points: '۴۵,۰۰۰', rank: 1, color: 'text-blue-500' },
          { name: 'واحد رسانه مشهد', points: '۴۲,۵۰۰', rank: 2, color: 'text-emerald-500' },
          { name: 'واحد تبیین اصفهان', points: '۳۸,۹۰۰', rank: 3, color: 'text-purple-500' },
        ].map((unit, idx) => (
          <motion.div 
            whileHover={{ x: 5 }}
            key={idx} 
            className="flex items-center gap-4 p-5 rounded-[2rem] bg-tg-surface border border-tg-border hover:border-blue-500/20 transition-all shadow-sm"
          >
            <div className={`w-10 h-10 rounded-2xl bg-black/5 dark:bg-white/5 border border-tg-border flex items-center justify-center font-black text-xs ${unit.color}`}>
              #{unit.rank}
            </div>
            <div className="flex-1">
              <p className="text-[11px] font-black text-tg-text">{unit.name}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <Trophy size={10} className="text-orange-500" />
                <p className="text-[9px] font-bold text-tg-text-muted uppercase tracking-tighter">{unit.points} امتیاز تجمعی</p>
              </div>
            </div>
            <ChevronLeft size={16} className="text-tg-border" />
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const NasraCenterScreen = ({ tasks, onCompleteTask }: { tasks: Task[], onCompleteTask: (mId: string, tId: string) => void }) => {
  const nasraTasks = tasks.filter(t => t.isNasra);
  
  return (
    <div className="p-6 space-y-8 pb-24 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-gradient-to-br from-blue-900 to-indigo-900 p-8 rounded-[3rem] text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -mr-32 -mt-32" />
        <div className="relative z-10 flex flex-col md:flex-row gap-6 items-center">
          <div className="w-20 h-20 bg-white/10 rounded-3xl flex items-center justify-center text-white border border-white/20 shadow-inner">
            <GraduationCap size={48} />
          </div>
          <div className="text-center md:text-right space-y-2">
            <h2 className="text-2xl font-black tracking-tight">مرکز آموزش فضای مجازی (نصرا)</h2>
            <p className="text-[11px] opacity-70 font-bold max-w-sm">نهضت سواد رسانه‌ای انقلاب اسلامی - ارتقای توان رزم سایبری در بستر اسکای‌روم و روبیکا</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-tg-surface p-5 rounded-3xl border border-tg-border space-y-3 transition-colors">
          <div className="flex items-center gap-2 text-blue-500">
            <Video size={18} />
            <span className="text-[10px] font-black">اسکای‌روم</span>
          </div>
          <p className="text-lg font-black text-tg-text">۳ وبینار فعال</p>
          <div className="h-1 bg-blue-500/10 rounded-full overflow-hidden">
            <div className="h-full w-2/3 bg-blue-500" />
          </div>
        </div>
        <div className="bg-tg-surface p-5 rounded-3xl border border-tg-border space-y-3 transition-colors">
          <div className="flex items-center gap-2 text-emerald-500">
            <Mic size={18} />
            <span className="text-[10px] font-black">روبیکا (لایو)</span>
          </div>
          <p className="text-lg font-black text-tg-text">۱ آموزش لایو</p>
          <div className="h-1 bg-emerald-500/10 rounded-full overflow-hidden">
            <div className="h-full w-1/4 bg-emerald-500" />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center px-2">
          <h3 className="text-xs font-black text-tg-text uppercase tracking-widest">دوره‌های آموزشی و رزمایش‌ها</h3>
          <span className="text-[9px] font-black text-tg-text-muted uppercase tracking-tighter">{nasraTasks.length} مورد یافت شد</span>
        </div>
        
        <div className="space-y-4">
          {nasraTasks.map(task => (
            <motion.div 
              whileHover={{ y: -4 }}
              key={task.id} 
              className="bg-tg-surface p-5 rounded-[2.5rem] border border-tg-border flex flex-col sm:flex-row gap-5 items-center justify-between group shadow-lg hover:border-blue-500/20 transition-all"
            >
              <div className="flex items-center gap-5">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-xl ${
                  task.platform === 'skyroom' ? 'bg-blue-600' : task.platform === 'rubika' ? 'bg-emerald-600' : 'bg-tg-accent'
                }`}>
                  {task.nasraType === 'webinar' ? <Video size={28} /> : 
                   task.nasraType === 'tutorial' ? <FileText size={28} /> : <Users size={28} />}
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-black text-tg-text">{task.title}</h4>
                    <span className="text-[8px] font-black bg-black/5 dark:bg-white/5 border border-tg-border px-2 py-0.5 rounded-full text-tg-text-muted uppercase tracking-tighter">
                      {task.platform}
                    </span>
                  </div>
                  <p className="text-[10px] text-tg-text-muted font-bold line-clamp-1">{task.description}</p>
                  <div className="flex items-center gap-3 mt-1 text-[9px] font-black text-tg-text-muted uppercase">
                    <div className="flex items-center gap-1">
                      <Trophy size={10} className="text-amber-500" />
                      <span>{task.points} امتیاز</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock size={10} className="text-blue-500" />
                      <span className="ltr">{task.deadline}</span>
                    </div>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => onCompleteTask('', task.id)}
                className={`px-8 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  task.status === 'completed' || task.status === 'submitted'
                    ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                    : 'bg-tg-accent text-white shadow-lg shadow-blue-500/20 active:scale-95'
                }`}
              >
                {task.status === 'completed' ? 'تکمیل شده' : task.status === 'submitted' ? 'در انتظار تایید' : 'شرکت در دوره'}
              </button>
            </motion.div>
          ))}
          {nasraTasks.length === 0 && (
            <div className="text-center py-20 bg-tg-surface rounded-[2.5rem] border border-dashed border-tg-border opacity-50 transition-colors">
              <GraduationCap size={48} className="mx-auto mb-4" />
              <p className="text-xs font-black">در حال حاضر رزمایش آموزشی فعالی در واحد نصرا ثبت نشده است.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const ProfileScreen = ({ profile, setProfile, setToast, darkMode, setDarkMode, notifyBale }: { 
  profile: UserProfile, 
  setProfile: (p: UserProfile) => void, 
  setToast: (t: any) => void,
  darkMode: boolean,
  setDarkMode: (d: boolean) => void,
  notifyBale: (text: string, chatId?: string) => Promise<void>
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempProfile, setTempProfile] = useState(profile);

  const handleSave = () => {
    setProfile(tempProfile);
    setIsEditing(false);
    setToast({ message: 'تغییرات با موفقیت ذخیره شد', type: 'success' });
  };

  const fields = [
    { key: 'name', label: 'نام' },
    { key: 'unit', label: 'واحد عملیاتی' },
    { key: 'bio', label: 'بیوگرافی' },
    { key: 'email', label: 'ایمیل' },
    { key: 'phone', label: 'شماره تماس' },
    { key: 'baleId', label: 'شناسه بله' }
  ];

  const missingFields = fields.filter(f => !tempProfile[f.key as any]);
  const completionPercentage = Math.round(((fields.length - missingFields.length) / fields.length) * 100);

  return (
    <div className={`p-6 space-y-6 pb-24 bg-tg-bg text-tg-text transition-colors`}>
      {completionPercentage < 100 && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-tg-surface rounded-[2.5rem] p-6 space-y-4 border border-tg-border shadow-xl shadow-black/5 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-tg-accent/5 rounded-full -mr-16 -mt-16 blur-3xl pointer-events-none" />
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-500/10 rounded-2xl flex items-center justify-center text-amber-500 border border-amber-500/20">
                <AlertCircle size={24} />
              </div>
              <div>
                <h4 className="text-[10px] font-black text-tg-text uppercase tracking-widest">تکمیل فایل پرسنلی</h4>
                <p className="text-[14px] text-amber-500 font-black tracking-tighter">{completionPercentage}% تکمیل شده</p>
              </div>
            </div>
            <button 
              onClick={() => setIsEditing(true)}
              className="px-5 py-2.5 bg-tg-accent text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all"
            >
              به‌روزرسانی
            </button>
          </div>
          
          <div className="space-y-2 relative z-10">
            <div className="w-full h-2 bg-black/5 dark:bg-white/5 rounded-full overflow-hidden border border-tg-border">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${completionPercentage}%` }}
                className="h-full bg-gradient-to-r from-tg-accent to-blue-400 rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]"
              />
            </div>
            <p className="text-[9px] text-tg-text-muted font-bold leading-relaxed px-1">
              کادر عملیاتی: برای هماهنگی بهتر سامانه، لطفاً 
              <span className="text-amber-500 font-black mx-1">
                {missingFields.map(f => f.label).join('، ')}
              </span>
              را تکمیل بفرمایید.
            </p>
          </div>
        </motion.div>
      )}

      <div className="flex flex-col items-center space-y-4 py-4">
        <div className="relative group">
          <div className="relative w-28 h-28 rounded-[2.5rem] bg-tg-surface flex items-center justify-center text-4xl font-black text-tg-accent shadow-2xl overflow-hidden border-2 border-tg-border transition-all">
            {tempProfile.avatar || (tempProfile.name && tempProfile.name[0]) || 'U'}
            <div className="absolute inset-0 bg-gradient-to-tr from-tg-accent/20 to-transparent pointer-events-none" />
          </div>
          {isEditing && (
            <button className="absolute -bottom-2 -right-2 w-10 h-10 bg-tg-accent text-white rounded-2xl flex items-center justify-center shadow-xl active:scale-90 transition-all border-4 border-tg-bg">
              <Plus size={20} />
            </button>
          )}
        </div>
        <div className="text-center space-y-1">
          <h2 className="text-2xl font-black tracking-tight text-tg-text">{profile.name}</h2>
          <div className="flex items-center justify-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <p className="text-[10px] text-tg-text-muted font-black uppercase tracking-[0.2em]">{profile.unit}</p>
          </div>
        </div>
      </div>

      <div className="bg-tg-surface rounded-3xl border border-tg-border p-6 space-y-6 shadow-sm transition-colors">
        <div className="flex justify-between items-center">
          <h3 className="text-sm font-black text-tg-text-muted">اطلاعات کاربری</h3>
          <button 
            onClick={() => isEditing ? handleSave() : setIsEditing(true)}
            className="text-xs font-black text-white px-4 py-2 bg-tg-accent rounded-xl shadow-lg shadow-blue-500/20"
          >
            {isEditing ? 'ذخیره تغییرات' : 'ویرایش پروفایل'}
          </button>
        </div>

        {/* Theme Settings Card in Profile */}
        <div className="bg-tg-bg/50 rounded-2xl p-4 border border-tg-border space-y-4 transition-colors">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
               <Sun size={18} className="text-amber-500" />
               <span className="text-[11px] font-black text-tg-text">حالت تیره (Dark Mode)</span>
            </div>
            <button 
              onClick={() => setDarkMode(!darkMode)}
              className={`w-12 h-6 rounded-full transition-colors flex items-center px-1 ${darkMode ? 'bg-tg-accent' : 'bg-black/10'}`}
            >
              <motion.div 
                animate={{ x: darkMode ? 24 : 0 }}
                className="w-4 h-4 bg-white rounded-full shadow-md"
              />
            </button>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-tg-text-muted uppercase px-1">نام و نام خانوادگی</label>
            <input 
              disabled={!isEditing}
              value={tempProfile.name}
              onChange={e => setTempProfile({...tempProfile, name: e.target.value})}
              className="tg-input disabled:opacity-60"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase px-1">واحد عملیاتی</label>
            <input 
              disabled={!isEditing}
              value={tempProfile.unit}
              onChange={e => setTempProfile({...tempProfile, unit: e.target.value})}
              className="tg-input disabled:opacity-60"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase px-1">بیوگرافی / شعار عملیاتی</label>
            <textarea 
              disabled={!isEditing}
              value={tempProfile.bio}
              onChange={e => setTempProfile({...tempProfile, bio: e.target.value})}
              className="tg-input min-h-[80px] py-3 disabled:opacity-60"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase px-1">ایمیل</label>
              <input 
                disabled={!isEditing}
                value={tempProfile.email}
                onChange={e => setTempProfile({...tempProfile, email: e.target.value})}
                className="tg-input disabled:opacity-60"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase px-1">شماره تماس</label>
              <input 
                disabled={!isEditing}
                value={tempProfile.phone}
                onChange={e => setTempProfile({...tempProfile, phone: e.target.value})}
                className="tg-input disabled:opacity-60"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-emerald-400 uppercase px-1 flex items-center gap-2">
              <Send size={12} />
              شناسه بله (برای دریافت نوتیفیکیشن)
            </label>
            <div className="relative">
              <input 
                disabled={!isEditing}
                placeholder="@username or ID"
                value={tempProfile.baleId || ''}
                onChange={e => setTempProfile({...tempProfile, baleId: e.target.value})}
                className="tg-input pl-10 disabled:opacity-60"
              />
              <AtSign size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            </div>
            
            {/* Bale Notification Toggle */}
            <div className="flex items-center justify-between p-4 bg-emerald-500/5 rounded-2xl border border-emerald-500/10 mt-2">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${tempProfile.baleNotificationsEnabled ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'}`}>
                  <Bell size={14} />
                </div>
                <div>
                  <h4 className="text-[10px] font-black dark:text-white uppercase tracking-widest">اعلان‌های بله</h4>
                  <p className="text-[8px] text-slate-500 font-bold uppercase">Bale Operations Alerts</p>
                </div>
              </div>
              <button 
                disabled={!isEditing}
                onClick={() => setTempProfile({...tempProfile, baleNotificationsEnabled: !tempProfile.baleNotificationsEnabled})}
                className={`w-12 h-6 rounded-full p-1 transition-all duration-300 ${tempProfile.baleNotificationsEnabled ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'} ${!isEditing ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${tempProfile.baleNotificationsEnabled ? 'translate-x-6' : 'translate-x-0'}`} />
              </button>
            </div>

            <p className="text-[8px] text-slate-500 font-bold px-1">با فعال‌سازی این گزینه، تمامی دستورات و بروزرسانی‌های عملیاتی مهم از طریق بات گردان به بله شما ارسال می‌شود.</p>
          </div>
        </div>
      </div>
      <div className="max-w-[70%] mx-auto w-full pt-4">
        <div className="bg-tg-surface p-8 rounded-[3rem] border border-tg-border text-center space-y-4 shadow-2xl hover:shadow-tg-accent/10 transition-all group overflow-hidden relative border-b-8 border-b-tg-accent ring-1 ring-black/5 dark:ring-white/5">
          <div className="absolute inset-0 bg-gradient-to-br from-tg-accent/5 via-transparent to-tg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="relative z-10 space-y-1">
            <p className="text-[10px] text-tg-text-muted font-black uppercase tracking-[0.4em] opacity-60">کل امتیازات تجمیعی</p>
            <p className="text-[8px] text-tg-accent font-bold uppercase tracking-widest leading-none">Net Worth Operations</p>
          </div>
          <div className="flex items-center justify-center gap-4 relative z-10">
            <div className="w-1.5 h-10 bg-tg-accent/20 rounded-full blur-sm animate-pulse" />
            <p className="font-black text-tg-accent text-5xl tracking-tighter tabular-nums drop-shadow-sm">۲,۴۵۰</p>
            <div className="w-1.5 h-10 bg-tg-accent/20 rounded-full blur-sm animate-pulse" />
          </div>
          <div className="flex items-center justify-center gap-2 relative z-10">
             <span className="text-[12px] font-black text-tg-text uppercase tracking-widest">تغییر نسبت به هفته گذشته:</span>
             <span className="text-[12px] font-black text-emerald-500">+۱۵٪</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const SecurityNoticeScreen = () => (
  <div className="p-6 space-y-6 pb-24">
    <div className="bg-red-900/10 p-6 rounded-3xl border border-red-900/20 space-y-4">
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 bg-red-900/30 rounded-2xl flex items-center justify-center text-red-600">
          <Shield size={32} />
        </div>
        <div>
          <h2 className="font-black text-lg text-red-100">امنیت و حریم خصوصی</h2>
          <p className="text-xs text-red-600 font-bold">پروتکل‌های حفاظتی گردان</p>
        </div>
      </div>
      <p className="text-xs text-red-200 leading-relaxed font-bold">
        امنیت شما و داده‌های عملیاتی در اولویت اول ماست. تمامی ارتباطات در این سامانه رمزنگاری شده و تحت نظارت واحد امنیت سایبری قرار دارد.
      </p>
    </div>

    <div className="space-y-4">
      <h3 className="text-xs font-black text-slate-400 px-1">نکات امنیتی ضروری</h3>
      <div className="space-y-3">
        {[
          { title: 'رمزنگاری سرتاسری', desc: 'تمامی پیام‌ها و گزارش‌های شما به صورت سرتاسری رمزنگاری می‌شوند.', icon: Shield },
          { title: 'احراز هویت دو مرحله‌ای', desc: 'برای امنیت بیشتر، همیشه از تایید دو مرحله‌ای استفاده کنید.', icon: CheckCircle2 },
          { title: 'پاکسازی خودکار', desc: 'داده‌های حساس پس از اتمام عملیات به صورت خودکار پاکسازی می‌شوند.', icon: Clock },
          { title: 'گزارش نفوذ', desc: 'در صورت مشاهده هرگونه فعالیت مشکوک، سریعاً به واحد امنیت گزارش دهید.', icon: AlertCircle }
        ].map((item, i) => (
          <div key={i} className="bg-tg-surface p-4 rounded-2xl border border-tg-border flex gap-4 items-start shadow-sm transition-colors">
            <div className="p-2 rounded-xl bg-black/5 dark:bg-white/5 text-tg-text-muted border border-tg-border">
              <item.icon size={20} />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-black text-tg-text">{item.title}</h4>
              <p className="text-[10px] text-tg-text-muted leading-relaxed">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>

    <div className="bg-tg-surface p-6 rounded-3xl border border-tg-border space-y-4 shadow-sm transition-colors">
      <h3 className="font-black text-sm text-tg-text">بیانیه حریم خصوصی</h3>
      <p className="text-[10px] text-tg-text-muted leading-relaxed">
        ما متعهد هستیم که هیچ‌گونه اطلاعات شخصی غیرضروری را جمع‌آوری نکنیم. داده‌های شما صرفاً برای اهداف عملیاتی و بهبود عملکرد گردان استفاده می‌شود و هرگز در اختیار شخص ثالث قرار نخواهد گرفت.
      </p>
    </div>

    <div className="pt-4">
      <button className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black text-sm shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 active:scale-95 transition-all">
        <Users size={20} />
        <span>درخواست عضویت در گردان</span>
      </button>
      <p className="text-[9px] text-center text-slate-400 mt-3 font-bold">
        با عضویت در مرکز، به جمع کارشناسان تحلیل بپیوندید و در اشتراک دانش سهیم شوید.
      </p>
    </div>
  </div>
);

const BattalionInfoScreen = () => (
  <div className="p-6 space-y-6 pb-24">
    <div className="bg-tg-surface p-8 rounded-[2.5rem] border border-tg-border shadow-2xl relative overflow-hidden group">
      <div className="absolute top-0 right-0 w-48 h-48 bg-tg-accent/10 rounded-full blur-3xl -mr-24 -mt-24 group-hover:bg-tg-accent/20 transition-all duration-500" />
      <div className="relative z-10 space-y-6">
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 bg-tg-accent/10 rounded-3xl flex items-center justify-center text-tg-accent border border-tg-accent/20 shadow-lg shadow-tg-accent/10">
            <Shield size={40} className="animate-pulse" />
          </div>
          <div className="space-y-1">
            <p className="text-[10px] text-tg-accent font-black uppercase tracking-[0.3em]">واحد مرکزی عملیات</p>
            <h2 className="font-black text-2xl tracking-tighter text-tg-text">قرارگاه سایبری شکن</h2>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <p className="text-[10px] text-tg-text-muted font-bold">نسخه پایدار v3.5.0 • وضعیت: عملیاتی</p>
            </div>
          </div>
        </div>
        <p className="text-xs text-tg-text-muted leading-relaxed font-bold border-l-4 border-tg-accent/30 pl-4 py-1 italic">
          این سامانه به عنوان هسته مرکزی مدیریت عملیات‌های نوین، وظیفه پایش مستمر، تامین امنیت شبکه و تبیین دستاوردهای راهبردی را بر عهده دارد. تکنولوژی استفاده شده در این نسخه، امنیت حداکثری داده‌ها را تضمین می‌کند.
        </p>
      </div>
    </div>

    <div className="grid grid-cols-2 gap-4">
      <div className="bg-tg-surface p-5 rounded-3xl border border-tg-border space-y-3 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-12 h-12 bg-emerald-500/10 rounded-bl-[2rem]" />
        <div className="flex items-center gap-2 text-emerald-500">
          <Signal size={18} />
          <span className="text-[10px] font-black uppercase">وضعیت DNS</span>
        </div>
        <p className="text-lg font-black text-tg-text">فعال (ایمن)</p>
        <div className="flex items-center gap-1.5">
          <div className="h-1 flex-1 bg-emerald-500/20 rounded-full overflow-hidden">
            <div className="h-full w-full bg-emerald-500" />
          </div>
          <span className="text-[8px] font-black text-emerald-500 uppercase">10ms</span>
        </div>
      </div>
      <div className="bg-tg-surface p-5 rounded-3xl border border-tg-border space-y-3 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-12 h-12 bg-tg-accent/10 rounded-bl-[2rem]" />
        <div className="flex items-center gap-2 text-tg-accent">
          <Lock size={18} />
          <span className="text-[10px] font-black uppercase">تونل امن</span>
        </div>
        <p className="text-lg font-black text-tg-text">برقرار</p>
        <div className="flex items-center gap-1.5">
          <div className="h-1 flex-1 bg-tg-accent/20 rounded-full overflow-hidden">
            <div className="h-full w-3/4 bg-tg-accent" />
          </div>
          <span className="text-[8px] font-black text-tg-accent uppercase">AES-256</span>
        </div>
      </div>
    </div>

    <div className="space-y-4">
      <h3 className="text-[10px] font-black text-tg-text-muted px-2 uppercase tracking-widest">ماموریت‌های ابلاغی قرارگاه</h3>
      <div className="grid grid-cols-1 gap-4">
        {[
          { title: 'رصد هوشمند', desc: 'پایش مستمر زیرساخت‌های حیاتی و شناسایی الگوهای نفوذ.', icon: Eye, color: 'text-blue-500', bg: 'bg-blue-500/5' },
          { title: 'جهاد تبیین', desc: 'تولید محتوای استراتژیک برای خنثی‌سازی جنگ رسانه‌ای.', icon: Zap, color: 'text-amber-500', bg: 'bg-amber-500/5' },
          { title: 'امنیت شبکه', desc: 'توسعه پروتکل‌های بومی و مدیریت ترافیک DNS.', icon: ShieldCheck, color: 'text-emerald-500', bg: 'bg-emerald-500/5' },
          { title: 'آموزش فنی', desc: 'ارتقای دانش فنی کادر عملیاتی در حوزه‌های نوین سایبری.', icon: Terminal, color: 'text-purple-500', bg: 'bg-purple-500/5' }
        ].map((m, i) => (
          <motion.div 
            key={i} 
            whileHover={{ x: 5 }}
            className={`p-5 rounded-[2rem] border border-tg-border flex gap-5 items-center transition-all hover:bg-tg-surface/60 group`}
          >
            <div className={`w-14 h-14 rounded-2xl ${m.bg} flex items-center justify-center ${m.color} border border-transparent group-hover:border-current transition-all shrink-0`}>
              <m.icon size={28} />
            </div>
            <div className="space-y-1">
              <h4 className="font-black text-sm">{m.title}</h4>
              <p className="text-[10px] text-tg-text-muted font-bold leading-relaxed">{m.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>

    <div className="pt-4 border-t border-tg-border">
      <button className="w-full py-5 bg-tg-text text-tg-bg rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all">
        <Upload size={18} />
        <span>دریافت دستورالعمل‌های محرمانه</span>
      </button>
      <p className="text-[8px] text-center text-tg-text-muted mt-4 font-bold opacity-60 uppercase tracking-widest">
        کلیه فعالیت‌های این سامانه تحت نظارت مستقیم مرکز پایش قرار دارد.
      </p>
    </div>
  </div>
);

const CalendarScreen = ({ 
  events, 
  userRole, 
  onAddEvent, 
  showTutorial, 
  onCloseTutorial 
}: { 
  events: CalendarEvent[], 
  userRole: UserRole,
  onAddEvent?: (date: string) => void,
  showTutorial?: boolean,
  onCloseTutorial?: () => void
}) => {
  const [currentJDate, setCurrentJDate] = useState(() => {
    const d = new Date();
    return jalaali.toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  });
  const [selectedJDate, setSelectedJDate] = useState<{jy: number, jm: number, jd: number} | null>(() => {
    const d = new Date();
    return jalaali.toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  });

  const { jy, jm } = currentJDate;
  
  // Find first day of the month
  const gFirstDay = jalaali.toGregorian(jy, jm, 1);
  const firstDayDate = new Date(gFirstDay.gy, gFirstDay.gm - 1, gFirstDay.gd);
  const firstDayOfWeek = firstDayDate.getDay(); 
  
  // Iran Week Mapping: Sat=0, Sun=1, ..., Fri=6
  // JS Day Mapping: Sun=0, Mon=1, ..., Sat=6
  const persianFirstDayIdx = (firstDayOfWeek + 1) % 7;
  
  const daysInMonth = jalaali.jalaaliMonthLength(jy, jm);
  
  const days: ({jy: number, jm: number, jd: number} | null)[] = [];
  for (let i = 0; i < persianFirstDayIdx; i++) days.push(null);
  for (let i = 1; i <= daysInMonth; i++) days.push({ jy, jm, jd: i });

  const monthNames = [
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
  ];

  const weekDays = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

  const handlePrevMonth = () => {
    if (jm === 1) setCurrentJDate({ jy: jy - 1, jm: 12, jd: 1 });
    else setCurrentJDate({ ...currentJDate, jm: jm - 1, jd: 1 });
  };
  
  const handleNextMonth = () => {
    if (jm === 12) setCurrentJDate({ jy: jy + 1, jm: 1, jd: 1 });
    else setCurrentJDate({ ...currentJDate, jm: jm + 1, jd: 1 });
  };

  const getDayEvents = (jd: number) => {
    return events.filter(e => {
      try {
        const d = new Date(e.date);
        const j = jalaali.toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
        return j.jy === jy && j.jm === jm && j.jd === jd;
      } catch { return false; }
    });
  };

  const selectedDayEvents = selectedJDate ? getDayEvents(selectedJDate.jd) : [];

  return (
    <div className="p-6 space-y-6 pb-24 rtl">
      {/* Calendar Tutorial Popup */}
      <AnimatePresence>
        {showTutorial && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm"
          >
            <div className="bg-tg-surface p-8 rounded-[3rem] border border-tg-border max-w-sm w-full space-y-6 shadow-2xl relative overflow-hidden transition-colors">
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl -mr-16 -mt-16" />
              <div className="w-16 h-16 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500 mx-auto border border-blue-500/20">
                <Calendar size={32} />
              </div>
              <div className="text-center space-y-2">
                <h3 className="text-lg font-black text-tg-text">خوش آمدید به تقویم عملیاتی</h3>
                <p className="text-[10px] text-tg-text-muted font-bold leading-relaxed px-4">
                  در این بخش می‌توانید تمامی برنامه‌ها، رزمایش‌ها و عملیات‌های پیش‌رو را مشاهده و مدیریت کنید. برای افزودن برنامه جدید، روی هر روز کلیک کنید.
                </p>
              </div>
              <button 
                onClick={onCloseTutorial}
                className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all"
              >
                متوجه شدم، شروع کنید
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Calendar Header */}
      <div className="relative h-32 flex items-end justify-between px-2 overflow-hidden bg-tg-surface rounded-[2.5rem] border border-tg-border p-6 mb-8 text-tg-text transition-colors">
        <div className="absolute top-[-20px] right-[-20px] opacity-5 pointer-events-none select-none">
          <span className="text-[180px] font-black leading-none opacity-20">
            {(jm).toLocaleString('fa-IR')}
          </span>
        </div>
        
        <div className="relative z-10 space-y-1 text-right">
          <h2 className="text-3xl font-black tracking-tighter uppercase">{monthNames[jm - 1]}</h2>
          <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.3em]">{jy.toLocaleString('fa-IR', {useGrouping: false})} • برنامه عملیاتی</p>
        </div>

        <div className="flex gap-2 relative z-10">
          <button onClick={handleNextMonth} className="p-3 bg-black/5 dark:bg-white/5 rounded-2xl border border-tg-border hover:bg-tg-border transition-all">
            <ChevronRight size={20} />
          </button>
          <button onClick={handlePrevMonth} className="p-3 bg-black/5 dark:bg-white/5 rounded-2xl border border-tg-border hover:bg-tg-border transition-all">
            <ChevronLeft size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Calendar Grid */}
        <div className="lg:col-span-2 bg-tg-surface p-8 rounded-[3rem] border border-tg-border shadow-2xl relative overflow-hidden group transition-colors">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-500/50 to-transparent" />
          
          <div className="grid grid-cols-7 mb-6">
            {weekDays.map(day => (
              <div key={day} className="text-center">
                <span className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">{day}</span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-y-4 gap-x-2">
            {days.map((day, idx) => {
              if (day === null) return <div key={`empty-${idx}`} />;
              
              const dayEvents = getDayEvents(day.jd);
              const isSelected = selectedJDate?.jd === day.jd && selectedJDate?.jm === jm;
              const isToday = (() => {
                const now = new Date();
                const todayJ = jalaali.toJalaali(now.getFullYear(), now.getMonth() + 1, now.getDate());
                return todayJ.jy === day.jy && todayJ.jm === day.jm && todayJ.jd === day.jd;
              })();
              const isWeekend = (idx + 1) % 7 === 0;

              return (
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  key={day.jd}
                  onClick={() => {
                    setSelectedJDate(day);
                  }}
                  onDoubleClick={() => {
                    const g = jalaali.toGregorian(day.jy, day.jm, day.jd);
                    const gDate = new Date(g.gy, g.gm - 1, g.gd).toISOString().split('T')[0];
                    onAddEvent?.(gDate);
                  }}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setSelectedJDate(day);
                    }
                  }}
                  className={`relative p-4 rounded-2xl transition-all aspect-square flex flex-col items-center justify-center gap-1 group/day border cursor-pointer ${
                    isSelected ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/30 border-blue-500 font-bold scale-105' : 
                    isToday ? 'bg-blue-500/10 text-blue-500 border-blue-500/30' :
                    'bg-black/5 dark:bg-slate-800/10 text-tg-text-muted border-transparent hover:bg-black/10 dark:hover:bg-slate-800/30 hover:border-tg-border'
                  }`}
                >
                  <span className={`text-sm font-black ${isWeekend && !isSelected ? 'text-red-500' : ''}`}>
                    {day.jd.toLocaleString('fa-IR')}
                  </span>
                  
                  {dayEvents.length > 0 && (
                    <div className="flex gap-0.5">
                      {dayEvents.slice(0, 3).map((e, ei) => (
                        <div key={ei} className={`w-1 h-1 rounded-full ${isSelected ? 'bg-white' : 'bg-blue-500'}`} />
                      ))}
                    </div>
                  )}
                  
                  {isToday && !isSelected && (
                    <div className="absolute top-1 right-1 w-1.5 h-1.5 bg-blue-500 rounded-full" />
                  )}

                  {isSelected && onAddEvent && (
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/day:opacity-100 transition-opacity bg-blue-600/80 rounded-2xl z-10">
                      <button 
                        onClick={(e) => { e.stopPropagation(); onAddEvent(`${day.jy}-${day.jm}-${day.jd}`); }}
                        className="p-2 bg-white text-blue-600 rounded-xl shadow-lg active:scale-90 transition-all"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Day Events Detail - Multi-layout Pattern */}
        <div className="hidden lg:block space-y-6">
          <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-4 shadow-xl transition-colors">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-xs font-black text-tg-text-muted uppercase tracking-widest">
                برنامه‌های {selectedJDate ? `${selectedJDate.jd.toLocaleString('fa-IR')} ${monthNames[selectedJDate.jm - 1]}` : ''}
              </h3>
              <Calendar size={14} className="text-tg-text-muted" />
            </div>

            <div className="space-y-3">
              {selectedDayEvents.length > 0 ? (
                selectedDayEvents.map(e => (
                  <div key={e.id} className="p-4 rounded-2xl bg-black/5 dark:bg-slate-800/20 border border-tg-border space-y-2 group hover:border-blue-500/30 transition-all cursor-pointer">
                    <div className="flex justify-between items-start">
                      <h4 className="text-xs font-black text-tg-text leading-tight group-hover:text-blue-500 transition-colors">{e.title}</h4>
                      <span className={`text-[8px] font-black px-2 py-1 rounded-lg uppercase tracking-widest ${
                        e.type === 'operation' ? 'bg-blue-500/10 text-blue-500' :
                        e.type === 'drill' ? 'bg-orange-500/10 text-orange-500' :
                        'bg-black/10 dark:bg-slate-500/10 text-tg-text-muted'
                      }`}>
                        {e.type}
                      </span>
                    </div>
                    <p className="text-[10px] text-tg-text-muted line-clamp-2">{e.description}</p>
                    <div className="flex items-center gap-2 pt-2 border-t border-tg-border">
                      <Clock size={12} className="text-blue-500" />
                      <span className="text-[10px] font-bold text-blue-500">{e.date.split('T')[1]?.substring(0, 5)}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center bg-black/5 dark:bg-slate-800/10 rounded-2xl border border-dashed border-tg-border">
                  <p className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest text-center mx-auto">رویدادی ثبت نشده است</p>
                </div>
              )}
            </div>
            
            {userRole === 'admin' && (
              <button className="w-full py-4 bg-blue-500/10 text-blue-500 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-blue-500/20 hover:bg-blue-500/20 transition-all flex items-center justify-center gap-2">
                <Plus size={16} />
                افزودن رویداد
              </button>
            )}
          </div>
        </div>

        {/* Mobile BottomSheet Detail */}
        <div className="lg:hidden">
          <BottomSheet 
            isOpen={!!selectedJDate} 
            onClose={() => setSelectedJDate(null)} 
            title={selectedJDate ? `برنامه‌های ${selectedJDate.jd.toLocaleString('fa-IR')} ${monthNames[selectedJDate.jm - 1]}` : 'برنامه‌های روز'}
          >
            <div className="space-y-6 pb-4">
              <div className="space-y-3">
                {selectedDayEvents.length > 0 ? (
                  selectedDayEvents.map(e => (
                    <div key={e.id} className="p-5 rounded-[2.5rem] bg-slate-800/20 border border-white/5 space-y-3">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${e.type === 'operation' ? 'bg-blue-500' : 'bg-orange-500'}`} />
                          <h4 className="text-xs font-black dark:text-white leading-tight">{e.title}</h4>
                        </div>
                        <span className="text-[7px] font-black px-2 py-1 bg-blue-500/10 text-blue-500 rounded-lg uppercase tracking-widest border border-blue-500/20">
                          {e.type}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 font-medium leading-relaxed">{e.description}</p>
                      <div className="flex items-center gap-2 pt-3 border-t border-white/5">
                        <Clock size={12} className="text-blue-500" />
                        <span className="text-[11px] font-bold text-blue-500">{e.date.split('T')[1]?.substring(0, 5)}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-12 text-center bg-slate-800/10 rounded-[2.5rem] border border-dashed border-white/5">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">موردی یافت نشد</p>
                  </div>
                )}
              </div>
              {userRole === 'admin' && (
                <button className="w-full py-5 bg-blue-500 text-white rounded-[2rem] font-black text-[11px] uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all flex items-center justify-center gap-3">
                  <Plus size={20} />
                  افزودن رویداد جدید
                </button>
              )}
            </div>
          </BottomSheet>
        </div>
      </div>
    </div>
  );
};

const HomeScreen = ({ 
  user, 
  missions, 
  tasks,
  contentLibrary,
  trackedAccounts,
  gordanContent,
  educationItems,
  observations,
  onTabChange,
  onBack,
  activeUnit,
  setActiveUnit,
  reports,
  setReports,
  setToast,
  integrations,
  onShare,
  dailyPlans = [],
  setTrackedAccounts
}: { 
  user: UserProfile, 
  missions: Mission[], 
  tasks: Task[],
  contentLibrary: ContentItem[],
  trackedAccounts: TrackedAccount[],
  gordanContent: GordanContent[],
  educationItems: EducationItem[],
  observations: Observation[],
  onTabChange: (tab: any) => void,
  onBack: () => void,
  activeUnit: 'main' | 'monitor' | 'studio' | 'tutorial' | 'explore',
  setActiveUnit: (unit: any) => void,
  reports: Report[],
  setReports: (reports: Report[]) => void,
  setToast: (t: {message: string, type: 'success' | 'error'} | null) => void,
  integrations: any,
  onShare: (i: ContentItem) => void,
  dailyPlans?: CalendarEvent[],
  setTrackedAccounts: (a: TrackedAccount[]) => void
}) => {
  const pendingTasks = tasks.filter(t => t.status === 'pending');
  const completedTasksCount = tasks.filter(t => t.status === 'completed').length;
  const userPendingTasksCount = tasks.filter(t => t.status === 'pending' && (!t.assignedTo || t.assignedTo === user.uid)).length;
  const urgentUserTasks = tasks.filter(t => 
    t.status === 'pending' && 
    (!t.assignedTo || t.assignedTo === user.uid) && 
    t.deadline && 
    t.deadline.includes('T') && 
    new Date(t.deadline).getTime() - new Date().getTime() < 12 * 60 * 60 * 1000
  );

    if (activeUnit === 'monitor') return (
      <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
        <MonitorScreen reports={reports} setReports={setReports} user={user} setToast={setToast} trackedAccounts={trackedAccounts} setTrackedAccounts={setTrackedAccounts} />
      </div>
    );

  if (activeUnit === 'studio') return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
      <StudioScreen integrations={integrations} setToast={setToast} user={user} gordanContent={gordanContent} onShare={onShare} />
    </div>
  );

  if (activeUnit === 'tutorial') return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
      <EducationScreen items={educationItems} />
    </div>
  );

  if (activeUnit === 'explore') return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
      <ExploreScreen content={contentLibrary} onShare={onShare} />
    </div>
  );

  return (
    <div className="p-4 space-y-6 pb-24 animate-in fade-in duration-500">
      {/* Active Tasks Notification */}
      {userPendingTasksCount > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`${urgentUserTasks.length > 0 ? 'bg-amber-600 shadow-amber-500/20' : 'bg-blue-500 shadow-blue-500/20'} rounded-[2rem] p-5 flex items-center justify-between shadow-xl border border-white/10`}
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center text-white backdrop-blur-md">
              {urgentUserTasks.length > 0 ? <AlertTriangle size={24} /> : <Target size={24} />}
            </div>
            <div>
              <h4 className="text-sm font-black text-white">
                {urgentUserTasks.length > 0 ? 'هشدار ضرب‌الاجل عملیاتی' : 'وظایف عملیاتی فعال'}
              </h4>
              <p className="text-[10px] text-white/80 font-bold">
                {urgentUserTasks.length > 0 
                  ? `${urgentUserTasks.length} وظیفه فوری در انتظار اقدام است!` 
                  : `شما ${userPendingTasksCount} وظیفه انجام نشده دارید.`}
              </p>
            </div>
          </div>
          <button 
            onClick={() => onTabChange('missions')}
            className={`px-5 py-2.5 bg-white ${urgentUserTasks.length > 0 ? 'text-amber-600' : 'text-blue-500'} rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg active:scale-95 transition-all`}
          >
            مشاهده
          </button>
        </motion.div>
      )}

      {/* Hero Section */}
      <div className="bg-gradient-to-br from-tg-accent via-blue-600 to-indigo-800 p-8 rounded-[3rem] text-white shadow-2xl shadow-tg-accent/30 relative overflow-hidden group">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-white/10 rounded-full blur-[80px] group-hover:scale-110 transition-transform duration-700" />
        <div className="absolute -left-16 -bottom-16 w-64 h-64 bg-black/20 rounded-full blur-[80px]" />
        
        <div className="relative z-10 space-y-6">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <div className="flex items-center gap-2 opacity-80 backdrop-blur-md bg-white/10 px-3 py-1 rounded-full w-fit">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <p className="text-[10px] font-black uppercase tracking-widest">سیستم عملیاتی آنلاین</p>
              </div>
              <h2 className="text-3xl font-black tracking-tighter">{user.name} عزیز</h2>
            </div>
            <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-xl border border-white/20 shadow-inner group-hover:rotate-12 transition-transform">
              <ShieldCheck size={32} />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/10 p-4 rounded-3xl backdrop-blur-md border border-white/10 shadow-lg group-hover:bg-white/15 transition-colors">
              <p className="text-[9px] font-black opacity-60 uppercase tracking-widest mb-1">ارزش عملیاتی</p>
              <div className="flex items-baseline gap-1">
                <p className="text-2xl font-black">{user.points.toLocaleString()}</p>
                <span className="text-[10px] font-bold opacity-60">امتیاز</span>
              </div>
            </div>
            <div className="bg-black/10 p-4 rounded-3xl backdrop-blur-md border border-white/5 shadow-lg group-hover:bg-black/20 transition-colors">
              <p className="text-[9px] font-black opacity-60 uppercase tracking-widest mb-1">سطح استراتژیک</p>
              <div className="flex items-baseline gap-1">
                <p className="text-2xl font-black">{user.rank}</p>
                <span className="text-[10px] font-bold opacity-60">LVL {user.level}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Network & DNS Status Widget */}
      <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border shadow-xl relative overflow-hidden group">
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500 border border-emerald-500/10 group-hover:scale-110 transition-transform">
              <Signal size={24} />
            </div>
            <div>
              <h4 className="text-sm font-black text-tg-text">وضعیت زیرساخت DNS</h4>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-emerald-500">امن و پایدار</span>
                <span className="w-1 h-1 rounded-full bg-slate-300 dark:bg-slate-600" />
                <span className="text-[10px] font-bold text-tg-text-muted">Latency: 12ms</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
             <div className="w-1.5 h-4 bg-emerald-500 rounded-full" />
             <div className="w-1.5 h-6 bg-emerald-500 rounded-full" />
             <div className="w-1.5 h-3 bg-emerald-500 rounded-full" />
             <div className="w-1.5 h-5 bg-emerald-500 rounded-full opacity-40" />
          </div>
        </div>
        <div className="absolute top-0 right-0 w-32 h-full bg-gradient-to-l from-emerald-500/5 to-transparent pointer-events-none" />
      </div>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { icon: Zap, label: 'عملیات', color: 'text-amber-500', onClick: () => onTabChange('missions') },
          { icon: Send, label: 'پیام‌رسان', color: 'text-blue-500', onClick: () => onTabChange('messenger') },
          { icon: ShieldAlert, label: 'گزارش', color: 'text-red-500', onClick: () => setActiveUnit('monitor') },
          { icon: LayoutGrid, label: 'بیشتر', color: 'text-slate-500', onClick: () => {} },
        ].map((action, i) => (
          <button 
            key={i} 
            onClick={action.onClick}
            className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex flex-col items-center gap-2 shadow-sm active:scale-95 transition-all hover:bg-tg-surface/80"
          >
            <action.icon size={20} className={action.color} />
            <span className="text-[9px] font-black text-tg-text uppercase">{action.label}</span>
          </button>
        ))}
      </div>

      {/* Quick Stats Summary */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-tg-surface p-5 rounded-[2rem] border border-tg-border flex items-center gap-4 transition-colors shadow-sm">
          <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500">
            <Target size={20} />
          </div>
          <div>
            <p className="text-[9px] text-tg-text-muted font-black uppercase">وظایف جاری</p>
            <p className="font-black text-lg">{pendingTasks.length}</p>
          </div>
        </div>
        <div className="bg-tg-surface p-5 rounded-[2rem] border border-tg-border flex items-center gap-4 transition-colors shadow-sm">
          <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-500">
            <CheckCircle size={20} />
          </div>
          <div>
            <p className="text-[9px] text-tg-text-muted font-black uppercase">تکمیل شده</p>
            <p className="font-black text-lg">{completedTasksCount}</p>
          </div>
        </div>
      </div>

      {/* Daily Schedule - Tomorrow's Plan */}
      {dailyPlans.length > 0 && (
        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <h3 className="font-black text-sm">برنامه‌های آتی گردان</h3>
            <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">{dailyPlans.length} رویداد ثبت شده</span>
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2 -mx-4 px-4">
            {dailyPlans.map(plan => (
              <div 
                key={plan.id}
                className="min-w-[240px] bg-tg-surface p-5 rounded-[2.5rem] border border-tg-border space-y-4 shadow-sm transition-colors"
              >
                <div className="flex justify-between items-start">
                  <div className={`p-2 rounded-xl ${
                    plan.type === 'training' ? 'bg-amber-500/10 text-amber-500' :
                    plan.type === 'mission' ? 'bg-red-500/10 text-red-500' : 'bg-blue-500/10 text-blue-500'
                  }`}>
                    {plan.type === 'training' ? <GraduationCap size={18} /> : <Target size={18} />}
                  </div>
                  <span className="text-[8px] font-black px-2 py-1 bg-white/5 rounded-lg text-slate-500 uppercase tracking-widest">
                    {plan.type === 'training' ? 'آموزشی' : 'عملیاتی'}
                  </span>
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-black">{plan.title}</h4>
                  <div className="flex items-center gap-2">
                    <Clock size={12} className="text-blue-500" />
                    <span className="text-[10px] font-bold text-slate-500">{plan.time}</span>
                  </div>
                </div>
                {plan.description && (
                  <p className="text-[10px] text-slate-400 font-medium line-clamp-2 leading-relaxed">
                    {plan.description}
                  </p>
                )}
                {plan.location && (
                  <div className="flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-white/5">
                    <MapPin size={10} className="text-slate-400" />
                    <span className="text-[9px] font-black text-slate-400 truncate">{plan.location}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Vitrine Units - Bento Grid */}
      <div className="space-y-4">
        <div className="flex justify-between items-center px-1">
          <h3 className="font-black text-sm">واحدهای عملیاتی (ویترین)</h3>
          <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">۵ واحد فعال</span>
        </div>
        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 -mx-4 px-4">
          <button 
            onClick={() => setActiveUnit('monitor')}
            className="min-w-[140px] bg-tg-surface p-5 rounded-[2rem] border border-tg-border flex flex-col items-center justify-center gap-3 shadow-sm active:scale-95 transition-all transition-colors"
          >
            <div className="w-12 h-12 bg-black/5 dark:bg-red-900/20 rounded-2xl flex items-center justify-center text-red-500">
              <Eye size={24} />
            </div>
            <span className="text-xs font-black text-tg-text">واحد رصد</span>
          </button>
          <button 
            onClick={() => setActiveUnit('studio')}
            className="min-w-[140px] bg-tg-surface p-5 rounded-[2rem] border border-tg-border flex flex-col items-center justify-center gap-3 shadow-sm active:scale-95 transition-all transition-colors"
          >
            <div className="w-12 h-12 bg-black/5 dark:bg-purple-900/20 rounded-2xl flex items-center justify-center text-purple-500">
              <Share2 size={24} />
            </div>
            <span className="text-xs font-black text-tg-text">واحد انتشار</span>
          </button>
          <button 
            onClick={() => setActiveUnit('tutorial')}
            className="min-w-[140px] bg-tg-surface p-5 rounded-[2rem] border border-tg-border flex flex-col items-center justify-center gap-3 shadow-sm active:scale-95 transition-all transition-colors"
          >
            <div className="w-12 h-12 bg-black/5 dark:bg-emerald-900/20 rounded-2xl flex items-center justify-center text-emerald-500">
              <GraduationCap size={24} />
            </div>
            <span className="text-xs font-black text-tg-text">واحد آموزش</span>
          </button>
          <button 
            onClick={() => setActiveUnit('explore')}
            className="min-w-[140px] bg-tg-surface p-5 rounded-[2rem] border border-tg-border flex flex-col items-center justify-center gap-3 shadow-sm active:scale-95 transition-all transition-colors"
          >
            <div className="w-12 h-12 bg-black/5 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center text-blue-500">
              <Compass size={24} />
            </div>
            <span className="text-xs font-black text-tg-text">ویترین محتوا</span>
          </button>
          <button 
            onClick={() => onTabChange('messenger')}
            className="min-w-[140px] bg-tg-surface p-5 rounded-[2rem] border border-tg-border flex flex-col items-center justify-center gap-3 shadow-sm active:scale-95 transition-all transition-colors"
          >
            <div className="w-12 h-12 bg-black/5 dark:bg-amber-900/20 rounded-2xl flex items-center justify-center text-amber-500">
              <MessageSquare size={24} />
            </div>
            <span className="text-xs font-black text-tg-text">پیام‌رسان</span>
          </button>
        </div>
      </div>

      {/* Recent Missions */}
      <div className="space-y-4">
        <div className="flex justify-between items-center px-1">
          <h3 className="font-black text-sm text-tg-text">آخرین ماموریت‌ها</h3>
          <button onClick={() => onTabChange('missions')} className="text-[10px] font-black text-blue-500">مشاهده همه</button>
        </div>
        <div className="space-y-3">
          {missions.slice(0, 2).map(mission => (
            <div key={mission.id} onClick={() => onTabChange('missions')} className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex items-center gap-4 active:scale-[0.98] cursor-pointer transition-all shadow-sm">
              <div className="w-12 h-12 bg-black/5 dark:bg-slate-800 rounded-2xl flex items-center justify-center shrink-0 border border-tg-border transition-colors">
                <Zap size={24} className="text-blue-500" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-black truncate text-tg-text">{mission.title}</h4>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex-1 h-1 bg-black/5 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-blue-500 transition-all duration-500" 
                      style={{ 
                        width: `${(tasks.filter(t => t.missionId === mission.id && t.status === 'completed').length / 
                                  tasks.filter(t => t.missionId === mission.id).length || 0) * 100}%` 
                      }} 
                    />
                  </div>
                  <span className="text-[8px] font-black text-tg-text-muted">
                    {Math.round((tasks.filter(t => t.missionId === mission.id && t.status === 'completed').length / 
                                 tasks.filter(t => t.missionId === mission.id).length || 0) * 100)}%
                  </span>
                </div>
              </div>
              <ChevronLeft size={16} className="text-tg-text-muted" />
            </div>
          ))}
        </div>
      </div>

      {/* Daily Briefing */}
      <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-4 shadow-xl transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center">
            <Activity size={20} />
          </div>
          <div>
            <h3 className="text-xs font-black">گزارش روزانه قرارگاه</h3>
            <p className="text-[9px] opacity-60">به‌روزرسانی: همین الان</p>
          </div>
        </div>
        <p className="text-xs leading-relaxed opacity-80 font-bold">
          تمامی واحدها در وضعیت آماده‌باش قرار دارند. رصد هشتگ‌های عملیاتی در توییتر اولویت اول امروز است.
        </p>
      </div>
    </div>
  );
};

const NavigationDrawer = ({ 
  isOpen, 
  onClose, 
  onTabChange,
  onUnitChange,
  onLogout,
  userRole,
  activeTab
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  onTabChange: (tab: any) => void,
  onUnitChange: (unit: any) => void,
  onLogout: () => void,
  userRole: UserRole,
  activeTab: string
}) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') setDeferredPrompt(null);
    } else {
      alert('این اپلیکیشن در حال حاضر نصب شده است یا مرورگر شما از نصب پشتیبانی نمی‌کند.');
    }
  };

  const handleTabClick = (tab: any) => {
    onTabChange(tab);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[150] flex">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 220 }}
            className="relative w-80 bg-tg-bg h-full shadow-[0_0_50px_rgba(0,0,0,0.3)] flex flex-col border-l border-tg-border transition-colors"
          >
            {/* Sidebar Header */}
            <div className="p-8 bg-tg-surface text-tg-text space-y-5 shadow-sm border-b border-tg-border transition-colors relative overflow-hidden">
               {/* Decorative background shape */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full -mr-16 -mt-16 pointer-events-none" />
              
              <div className="flex justify-between items-center relative z-10">
                <div className="w-14 h-14 rounded-2xl bg-blue-500 flex items-center justify-center text-white text-2xl font-black shadow-xl shadow-blue-500/30 border border-blue-400/20">
                  گ
                </div>
                <button onClick={onClose} className="p-2 hover:bg-tg-border rounded-xl text-tg-text-muted transition-colors">
                  <ChevronLeft size={20} />
                </button>
              </div>
              <div className="relative z-10">
                <h2 className="font-black text-xl text-tg-text tracking-tighter">گردان سایبری</h2>
                <div className="flex items-center gap-2 mt-1">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <p className="text-[10px] font-black uppercase tracking-widest text-blue-500">واحد عملیاتی مرکز</p>
                </div>
              </div>
            </div>

            {/* Sidebar Menu */}
            <div className="flex-1 overflow-y-auto py-6 px-4 space-y-6 no-scrollbar backdrop-blur-3xl">
              <section className="space-y-1">
                <div className="px-4 mb-3">
                  <p className="text-[10px] font-black text-tg-text-muted/60 uppercase tracking-[0.2em]">منوی اصلی</p>
                </div>
                <SidebarItem icon={Layout} label="ویترین (خانه)" onClick={() => handleTabClick('home')} active={activeTab === 'home'} />
                <SidebarItem icon={GraduationCap} label="مرکز آموزش (نصرا)" onClick={() => handleTabClick('nasra')} active={activeTab === 'nasra'} highlight />
                <SidebarItem icon={Calendar} label="تقویم عملیاتی" onClick={() => handleTabClick('calendar')} active={activeTab === 'calendar'} />
                <SidebarItem icon={MessageSquare} label="پیام‌رسان قرارگاه" onClick={() => handleTabClick('messenger')} active={activeTab === 'messenger'} />
                <SidebarItem icon={Target} label="مرکز کنترل عملیات" onClick={() => handleTabClick('missions')} active={activeTab === 'missions'} />
              </section>
              
              <section className="space-y-1">
                <div className="px-4 mb-3">
                  <p className="text-[10px] font-black text-tg-text-muted/60 uppercase tracking-[0.2em]">واحدهای عملیاتی</p>
                </div>
                <SidebarItem icon={Eye} label="واحد رصد و پایش" onClick={() => { onTabChange('home'); onUnitChange('monitor'); onClose(); }} />
                <SidebarItem icon={Share2} label="واحد ابلاغ و انتشار" onClick={() => { onTabChange('home'); onUnitChange('studio'); onClose(); }} />
                <SidebarItem icon={GraduationCap} label="واحد آموزش" onClick={() => { onTabChange('home'); onUnitChange('tutorial'); onClose(); }} />
              </section>

              <div className="h-px bg-tg-border mx-4" />
              
              <section className="space-y-1">
                <SidebarItem icon={Bookmark} label="نشان شده‌ها" onClick={() => handleTabClick('saved')} active={activeTab === 'saved'} />
                <SidebarItem icon={Shield} label="امنیت و حریم خصوصی" onClick={() => handleTabClick('security')} active={activeTab === 'security'} />
                <SidebarItem icon={Info} label="درباره گردان" onClick={() => handleTabClick('info')} active={activeTab === 'info'} />
              </section>
              
              {(userRole === 'admin' || userRole === 'manager') && (
                <section className="space-y-1">
                  <div className="h-px bg-tg-border my-2 mx-4" />
                  <SidebarItem icon={ShieldAlert} label="پنل مدیریت عملیات" onClick={() => handleTabClick('admin')} active={activeTab === 'admin'} color="text-red-500" />
                </section>
              )}


            </div>

            {/* Sidebar Footer */}
            <div className="p-6 border-t border-tg-border text-center bg-tg-surface/30">
              <p className="text-[9px] text-tg-text-muted font-black uppercase tracking-[0.3em] opacity-50">نسخه ۳.۱.۰ - بستر امن بله</p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const SidebarItem = ({ 
  icon: Icon, 
  label, 
  onClick, 
  color = 'text-tg-text', 
  highlight = false,
  active = false 
}: { 
  icon: any, 
  label: string, 
  onClick?: () => void, 
  color?: string, 
  highlight?: boolean,
  active?: boolean
}) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-between gap-3 p-3.5 rounded-2xl transition-all relative group overflow-hidden ${
      active 
      ? 'bg-blue-500/10 text-blue-500 shadow-sm border border-blue-500/20' 
      : 'hover:bg-tg-surface border border-transparent hover:border-tg-border'
    }`}
  >
    <div className="flex items-center gap-3 relative z-10">
      <div className={`p-2 rounded-xl transition-all duration-300 ${
        active 
        ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/20 rotate-0' 
        : highlight 
          ? 'bg-blue-500 text-white' 
          : 'bg-tg-border text-tg-text-muted group-hover:bg-blue-500 group-hover:text-white group-hover:scale-110 group-hover:rotate-12'
      }`}>
        <Icon size={18} />
      </div>
      <span className={`text-[11px] font-black tracking-tight ${active ? 'text-blue-500' : color}`}>{label}</span>
    </div>
    
    {active && (
      <motion.div 
        layoutId="activeIndicator"
        className="w-1 h-5 bg-blue-500 rounded-full relative z-10"
        transition={{ type: 'spring', damping: 20, stiffness: 300 }}
      />
    )}
  </button>
);

const Header = ({ 
  title, 
  onMenuClick, 
  onNotificationsClick, 
  activeTab, 
  unreadNotifications,
  showBack = false,
  onBack
}: { 
  title: string, 
  onMenuClick: () => void, 
  onNotificationsClick?: () => void, 
  activeTab: string, 
  unreadNotifications: number,
  showBack?: boolean,
  onBack?: () => void
}) => (
  <header className="h-20 px-6 flex items-center justify-between bg-tg-surface/40 backdrop-blur-3xl border-b border-tg-border sticky top-0 z-[100] transition-all">
    <div className="flex items-center gap-4">
      {showBack ? (
        <button onClick={onBack} className="w-12 h-12 flex items-center justify-center bg-white/5 hover:bg-tg-border rounded-[1.25rem] transition-all active:scale-95 text-tg-text-muted border border-tg-border shadow-inner">
          <ChevronRight size={24} />
        </button>
      ) : (
        <button onClick={onMenuClick} className="w-12 h-12 flex items-center justify-center bg-white/5 hover:bg-tg-border rounded-[1.25rem] transition-all active:scale-95 text-tg-text-muted border border-tg-border shadow-inner">
          <Menu size={24} />
        </button>
      )}
      <div className="hidden sm:flex flex-col border-l border-tg-border pl-4 ml-1">
        <span className="text-[10px] font-black text-tg-accent uppercase tracking-[0.2em] leading-none">Command Center</span>
        <div className="flex items-center gap-1.5 mt-0.5">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
          <span className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">Network Secure</span>
        </div>
      </div>
    </div>

    <div className="flex flex-col items-center">
      <div className="flex items-center gap-3 px-6 py-2.5 bg-tg-surface/60 backdrop-blur-xl border border-tg-border rounded-full shadow-2xl">
        <div className="w-2 h-2 bg-tg-accent rounded-full animate-bounce shadow-[0_0_12px_rgba(36,129,204,0.6)]" />
        <h1 className="font-black text-[11px] uppercase tracking-[0.3em] text-tg-text leading-none drop-shadow-sm">{title}</h1>
      </div>
    </div>

    <div className="flex items-center gap-2">
      <div className="hidden xs:flex items-center gap-2 bg-black/5 dark:bg-white/5 px-3 py-2 rounded-xl border border-tg-border">
        <div className="w-2 h-2 rounded-full bg-emerald-500" />
        <span className="text-[9px] font-black text-tg-text-muted uppercase tracking-tighter">DNS: 10ms</span>
      </div>
      <button onClick={onNotificationsClick} className="w-12 h-12 flex items-center justify-center bg-white/5 hover:bg-tg-border rounded-[1.25rem] transition-all text-tg-text-muted relative border border-tg-border shadow-inner">
        <Bell size={20} />
        {unreadNotifications > 0 && (
          <span className="absolute top-3 right-3 w-3 h-3 bg-red-500 rounded-full border-2 border-tg-surface shadow-lg" />
        )}
      </button>
    </div>
  </header>
);


const TaskExecutionModal = ({ 
  isOpen, 
  onClose, 
  task, 
  contentBank, 
  onTabChange, 
  setToast, 
  onShare,
  onComplete 
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  task: Task | null, 
  contentBank: ContentItem[],
  onTabChange: (t: any) => void,
  setToast: (t: any) => void,
  onShare: (c: ContentItem) => void,
  onComplete: (link: string, screenshot?: string) => void
}) => {
  const [step, setStep] = useState<'details' | 'publish' | 'submit'>('details');
  const [link, setLink] = useState('');
  const [screenshot, setScreenshot] = useState<string | undefined>(undefined);

  if (!task) return null;

  const selectedContent = contentBank.find(c => c.id === task.contentId);

  const isNasra = task.isNasra;

  return (
    <BottomSheet 
      isOpen={isOpen} 
      onClose={() => {
        onClose();
        setStep('details');
        setLink('');
        setScreenshot(undefined);
      }} 
      title={isNasra ? 'حضور در رزمایش آموزشی (نصرا)' : (step === 'details' ? 'جزئیات عملیات' : step === 'publish' ? 'انتشار محتوا' : 'تکمیل و ثبت گزارش')}
    >
      <div className="space-y-6 p-2">
        {step === 'details' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="flex gap-4 items-start bg-black/5 dark:bg-white/5 p-5 rounded-[2rem] border border-tg-border transition-colors">
              <div className="w-14 h-14 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-500 shadow-xl border border-blue-500/20">
                {isNasra ? <GraduationCap size={32} /> : <Target size={32} />}
              </div>
              <div className="flex-1 space-y-1">
                <h3 className="text-lg font-black text-tg-text">{task.title}</h3>
                <p className="text-xs text-tg-text-muted font-bold leading-relaxed">{task.description}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex items-center gap-3 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500">
                  <Trophy size={20} />
                </div>
                <div>
                  <p className="text-[9px] font-black text-tg-text-muted uppercase">پاداش</p>
                  <p className="text-xs font-black text-tg-text">{task.points} امتیاز</p>
                </div>
              </div>
              <div className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex items-center gap-3 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500">
                  {task.platform === 'skyroom' ? <Video size={20} /> : task.platform === 'rubika' ? <Mic size={20} /> : <Twitter size={20} />}
                </div>
                <div>
                  <p className="text-[9px] font-black text-tg-text-muted uppercase">پلتفرم</p>
                  <p className="text-xs font-black text-tg-text uppercase">{task.platform}</p>
                </div>
              </div>
            </div>

            {isNasra && task.nasraUrl && (
              <div className="p-5 bg-blue-500/5 rounded-3xl border border-blue-500/20 space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                  <p className="text-[10px] font-black text-blue-500 uppercase">لینک ورود به جلسه لایو</p>
                </div>
                <button 
                  onClick={() => window.open(task.nasraUrl, '_blank')}
                  className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20"
                >
                  <ExternalLink size={18} />
                  ورود به اسکای‌روم / روبیکا
                </button>
              </div>
            )}

            <div className="space-y-3">
              <div className="flex items-center gap-2 px-1">
                <h4 className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">گام‌های عملیاتی</h4>
                <div className="h-[1px] flex-1 bg-tg-border" />
              </div>
              <div className="space-y-2">
                {(isNasra ? [
                  'ورود به لینک جلسه آموزشی',
                  'حضور فعال در تمام طول جلسه',
                  'تهیه اسکرین‌شات از لحظه حضور (الزامی)',
                  'ارسال گزارش حضور جهت دریافت امتیاز'
                ] : (task.steps || [
                  'بررسی دقیق متن و کپشن بازنشر',
                  'کپی لینک محتوا از استودیو',
                  'انتشار در پلتفرم مورد نظر',
                  'ثبت لینک نهایی جهت تایید ستاد'
                ])).map((step, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 bg-black/5 dark:bg-black/20 rounded-2xl border border-tg-border group hover:border-tg-accent/30 transition-all">
                    <div className="w-6 h-6 rounded-lg bg-tg-bg border border-tg-border flex items-center justify-center text-[10px] font-black text-tg-text-muted transition-colors">
                      {i + 1}
                    </div>
                    <span className="text-[10px] font-bold text-tg-text-muted group-hover:text-tg-text transition-colors">{step}</span>
                    <Check size={14} className="mr-auto text-emerald-500 opacity-40" />
                  </div>
                ))}
              </div>
            </div>

            <button 
              onClick={() => isNasra ? setStep('submit') : setStep('publish')}
              className="w-full py-5 bg-tg-accent text-white rounded-[2rem] font-black text-sm uppercase tracking-widest shadow-2xl shadow-tg-accent/30 active:scale-95 transition-all flex items-center justify-center gap-3"
            >
              {isNasra ? 'ثبت گزارش و آپلود مدرک' : 'شروع گام‌های عملیاتی'}
              <ArrowLeft size={20} />
            </button>
          </div>
        )}

        {step === 'publish' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-300">
            {task.contentCaption && (
              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-accent/20 space-y-4 shadow-xl relative overflow-hidden transition-colors">
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-8 h-8 rounded-xl bg-tg-accent/10 flex items-center justify-center text-tg-accent">
                    <AtSign size={16} />
                  </div>
                  <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest">کپشن پیشنهادی</p>
                </div>
                <div className="bg-black/20 p-5 rounded-2xl border border-white/5">
                  <p className="text-sm text-slate-300 leading-relaxed font-bold">
                    {task.contentCaption}
                  </p>
                </div>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(task.contentCaption!);
                    setToast({ message: 'کپشن کپی شد', type: 'success' });
                  }}
                  className="w-full py-3 bg-white/5 text-blue-400 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-blue-500/5 transition-all"
                >
                  <Copy size={14} />
                  کپی کردن کپشن
                </button>
              </div>
            )}

            {task.contentBody && (
              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-emerald-500/20 space-y-4 shadow-xl relative overflow-hidden transition-colors">
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                    <FileText size={16} />
                  </div>
                  <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">متن محتوا</p>
                </div>
                <div className="bg-black/20 p-5 rounded-2xl border border-white/5 max-h-40 overflow-y-auto no-scrollbar">
                  <p className="text-sm text-slate-300 leading-relaxed font-bold">
                    {task.contentBody}
                  </p>
                </div>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(task.contentBody!);
                    setToast({ message: 'متن محتوا کپی شد', type: 'success' });
                  }}
                  className="w-full py-3 bg-white/5 text-emerald-400 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-emerald-500/5 transition-all"
                >
                  <Copy size={14} />
                  کپی کردن متن
                </button>
              </div>
            )}

            {task.contentImage && (
              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-accent/20 space-y-4 shadow-xl relative overflow-hidden transition-colors">
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-500">
                    <Camera size={16} />
                  </div>
                  <p className="text-[10px] font-black text-purple-500 uppercase tracking-widest">تصویر عملیاتی</p>
                </div>
                <div className="rounded-2xl overflow-hidden border border-white/5">
                  <img src={task.contentImage} className="w-full h-auto" referrerPolicy="no-referrer" />
                </div>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(task.contentImage!);
                    setToast({ message: 'لینک تصویر کپی شد', type: 'success' });
                  }}
                  className="w-full py-3 bg-white/5 text-purple-400 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-purple-500/5 transition-all"
                >
                  <Copy size={14} />
                  کپی لینک تصویر
                </button>
              </div>
            )}

            {selectedContent && (
              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-accent/20 space-y-4 shadow-xl relative overflow-hidden transition-colors">
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-8 h-8 rounded-xl bg-tg-accent/10 flex items-center justify-center text-tg-accent">
                    <Zap size={16} />
                  </div>
                  <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest">محتوای پیشنهادی برای انتشار</p>
                </div>
                <div className="bg-black/20 p-5 rounded-2xl border border-white/5 max-h-40 overflow-y-auto no-scrollbar">
                  <p className="text-sm text-slate-300 leading-relaxed font-bold">
                    {selectedContent.content}
                  </p>
                </div>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(selectedContent.content!);
                    setToast({ message: 'محتوا کپی شد', type: 'success' });
                  }}
                  className="w-full py-3 bg-black/5 dark:bg-white/5 text-tg-accent rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-tg-accent/5 transition-all border border-tg-border"
                >
                  <Copy size={14} />
                  کپی کردن محتوا
                </button>
              </div>
            )}

            <div className="flex gap-3">
              <button 
                onClick={() => setStep('details')}
                className="flex-1 py-5 bg-white/5 text-slate-400 rounded-[2rem] font-black text-xs uppercase tracking-widest transition-colors"
              >
                بازگشت
              </button>
              <button 
                onClick={() => setStep('submit')}
                className="flex-[2] py-5 bg-blue-500 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl shadow-blue-500/30 active:scale-95 transition-all"
              >
                مرحله بعد: ثبت گزارش
              </button>
            </div>
          </div>
        )}

        {step === 'submit' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-emerald-500/20 space-y-4 shadow-xl transition-colors">
              <div className="flex items-center gap-3 mb-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                  <LinkIcon size={16} />
                </div>
                <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">لینک انتشار نهایی</p>
              </div>
              <div className="space-y-2">
                <label className="text-[9px] font-black text-tg-text-muted uppercase px-1 transition-colors">لینک پست منتشر شده را وارد کنید</label>
                <input 
                  type="url"
                  dir="ltr"
                  placeholder="https://x.com/username/status/..."
                  className="tg-input text-left"
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[9px] font-black text-tg-text-muted uppercase px-1 transition-colors">
                  {isNasra ? 'تصویر اسکرین‌شات از حضور (الزامی)' : 'مستنتدات عملیاتی (اختیاری)'}
                </label>
                <div 
                  onClick={() => {
                    const url = prompt('لینک تصویر اسکرین‌شات مدرک:');
                    if (url) setScreenshot(url);
                  }}
                  className={`h-32 bg-black/20 rounded-[2rem] border-2 border-dashed flex flex-col items-center justify-center gap-2 cursor-pointer transition-all group ${isNasra && !screenshot ? 'border-amber-500/40 bg-amber-500/5' : 'border-white/5 hover:border-blue-500/30'}`}
                >
                  {screenshot ? (
                    <img src={screenshot} className="w-full h-full object-cover rounded-[2rem]" />
                  ) : (
                    <>
                      <Camera size={24} className={isNasra ? "text-amber-500/50" : "text-slate-600 group-hover:text-blue-500"} />
                      <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">آپلود اسکرین‌شات</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button 
                onClick={() => isNasra ? setStep('details') : setStep('publish')}
                className="flex-1 py-5 bg-white/5 text-slate-400 rounded-[2rem] font-black text-xs uppercase tracking-widest transition-colors"
              >
                بازگشت
              </button>
              <button 
                onClick={() => {
                  if (confirm('آیا از ثبت نهایی این گزارش و تکمیل عملیات اطمینان دارید؟')) {
                    onComplete(link, screenshot);
                  }
                }}
                disabled={!link && !isNasra || (isNasra && !screenshot)}
                className="flex-[2] py-5 bg-emerald-500 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl shadow-emerald-500/30 active:scale-95 disabled:opacity-30 transition-all"
              >
                {isNasra ? 'ثبت مدرک و پایان' : 'ثبت و تکمیل عملیات'}
              </button>
            </div>
          </div>
        )}
      </div>
    </BottomSheet>
  );
};

const MissionControlScreen = ({ 
  missions, 
  tasks,
  onCompleteTask, 
  user,
  contentBank,
  educationItems,
  onTabChange,
  setToast,
  onShare,
  dailyPlans = [],
  onAddTask,
  onAddMission,
  onAddUser,
  onAddEvent,
  updateDb
}: { 
  missions: Mission[], 
  tasks: Task[],
  onCompleteTask: (missionId: string, taskId: string, link?: string, screenshot?: string) => void, 
  user: UserProfile,
  contentBank: ContentItem[],
  educationItems: EducationItem[],
  onTabChange: (tab: any) => void,
  setToast: (t: {message: string, type: 'success' | 'error'} | null) => void,
  onShare: (i: ContentItem) => void,
  dailyPlans?: CalendarEvent[],
  onAddTask?: () => void,
  onAddMission?: () => void,
  onAddUser?: () => void,
  onAddEvent?: () => void,
  updateDb: (path: string, value: any) => Promise<void>
}) => {
  const [showArchived, setShowArchived] = useState(false);
  const [selectedTask, setSelectedTask] = useState<{missionId: string, task: Task} | null>(null);

  const userTasks = tasks.filter(t => t.assignedTo === user.uid || !t.assignedTo);
  
  const getMissionCompletion = (mId: string) => {
    const mTasks = tasks.filter(t => t.missionId === mId);
    if (mTasks.length === 0) return 0;
    return mTasks.filter(t => t.status === 'completed').length / mTasks.length;
  };

  const activeMissions = missions.filter(m => !m.isArchived && getMissionCompletion(m.id) < 1);
  const archivedMissions = missions.filter(m => m.isArchived || getMissionCompletion(m.id) === 1);

  const missionProgressData = activeMissions.map(m => {
    const mTasks = tasks.filter(t => t.missionId === m.id);
    const completedCount = mTasks.filter(t => t.status === 'completed').length;
    return {
      name: m.title.length > 20 ? m.title.substring(0, 20) + '...' : m.title,
      fullName: m.title,
      progress: Math.round((completedCount / mTasks.length) * 100) || 0,
      completedCount,
      totalCount: mTasks.length
    };
  });

  return (
    <div className="flex flex-col p-6 space-y-8 pb-32 bg-tg-bg min-h-screen transition-colors">
      <TaskExecutionModal 
        isOpen={!!selectedTask}
        onClose={() => setSelectedTask(null)}
        task={selectedTask?.task || null}
        contentBank={contentBank}
        onTabChange={onTabChange}
        setToast={setToast}
        onShare={onShare}
        onComplete={(link, screenshot) => {
          if (selectedTask) {
            onCompleteTask(selectedTask.missionId, selectedTask.task.id, link, screenshot);
            setSelectedTask(null);
          }
        }}
      />

      {/* User Status Card */}
      <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border shadow-2xl shadow-black/40 relative overflow-hidden group transition-colors">
        <div className="absolute top-0 right-0 w-40 h-40 bg-blue-500/5 blur-3xl -mr-20 -mt-20 group-hover:bg-blue-500/10 transition-all" />
        <div className="relative flex items-center gap-5">
          <div className="relative">
            <div className="w-16 h-16 bg-black/10 dark:bg-black rounded-2xl flex items-center justify-center text-tg-text border border-tg-border shadow-2xl group-hover:border-blue-500/50 transition-all">
              <Shield size={32} className="text-blue-500" />
            </div>
            <div className="absolute -top-2 -right-2 bg-blue-500 text-white text-[9px] font-black px-2 py-1 rounded-full border-2 border-tg-surface shadow-lg">
              سطح {user.level} {user.rank}
            </div>
          </div>
          <div className="flex-1 space-y-2">
            <div className="flex justify-between items-center">
              <h2 className="font-black text-sm uppercase tracking-widest text-tg-text">وضعیت فعالیت کاربر</h2>
              <span className="text-[9px] font-black text-blue-500 bg-blue-500/10 px-2 py-1 rounded-lg border border-blue-500/20">{user.rank}</span>
            </div>
            <div className="w-full h-2 bg-black/10 dark:bg-black/40 rounded-full overflow-hidden border border-tg-border p-[1px]">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${(user.points % 1000) / 10}%` }}
                className="h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full shadow-[0_0_8px_rgba(59,130,246,0.5)]"
              />
            </div>
            <div className="flex justify-between">
              <span className="text-[9px] text-slate-500 font-black uppercase tracking-widest">{user.points} کل امتیازات</span>
              <span className="text-[9px] text-slate-500 font-black uppercase tracking-widest">{user.completedMissions} عملیات موفق</span>
            </div>
          </div>
        </div>
      </div>

      {/* Management Shortcuts */}
      {(user.role === 'admin' || user.role === 'manager') && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button onClick={onAddMission} className="p-4 bg-tg-surface rounded-3xl border border-tg-border hover:border-emerald-500/30 transition-all group flex flex-col items-center gap-3 shadow-lg">
             <div className="p-3 bg-emerald-500/10 rounded-2xl text-emerald-500 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                <Target size={20} />
             </div>
             <span className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">تأسیس ماموریت</span>
          </button>
          <button onClick={onAddTask} className="p-4 bg-tg-surface rounded-3xl border border-tg-border hover:border-blue-500/30 transition-all group flex flex-col items-center gap-3 shadow-lg">
             <div className="p-3 bg-blue-500/10 rounded-2xl text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-all">
                <Plus size={20} />
             </div>
             <span className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">انتشار وظیفه</span>
          </button>
          <button onClick={onAddUser} className="p-4 bg-tg-surface rounded-3xl border border-tg-border hover:border-amber-500/30 transition-all group flex flex-col items-center gap-3 shadow-lg">
             <div className="p-3 bg-amber-500/10 rounded-2xl text-amber-500 group-hover:bg-amber-500 group-hover:text-white transition-all">
                <UserPlus size={20} />
             </div>
             <span className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">ثبت افسر</span>
          </button>
          <button onClick={onAddEvent} className="p-4 bg-tg-surface rounded-3xl border border-tg-border hover:border-purple-500/30 transition-all group flex flex-col items-center gap-3 shadow-lg">
             <div className="p-3 bg-purple-500/10 rounded-2xl text-purple-500 group-hover:bg-purple-500 group-hover:text-white transition-all">
                <Calendar size={20} />
             </div>
             <span className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">ثبت رویداد</span>
          </button>
        </div>
      )}

      {/* Mission Progress Analytics Chart - Admin Only */}
      {activeMissions.length > 0 && user.role === 'admin' && (
        <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-6 shadow-xl transition-colors">
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <h3 className="text-sm font-black uppercase tracking-widest text-tg-accent">تحلیل پیشرفت عملیاتی</h3>
              <p className="text-[8px] font-black text-tg-text-muted uppercase tracking-tighter">درصد تکمیل ظرفیت ماموریت‌های فعال</p>
            </div>
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500 border border-blue-500/20">
              <Activity size={16} />
            </div>
          </div>
          
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={missionProgressData} layout="vertical" margin={{ left: 10, right: 30, top: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="opacity-10" horizontal={false} vertical={false} />
                <XAxis type="number" domain={[0, 100]} hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  width={100} 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'var(--tg-text)', fontSize: 9, fontWeight: 900 }} 
                  className="text-tg-text-muted"
                />
                <Tooltip 
                  cursor={{ fill: 'rgba(59,130,246,0.05)' }}
                  contentStyle={{ 
                    backgroundColor: 'var(--tg-surface)', 
                    border: '1px solid var(--tg-border)', 
                    borderRadius: '1rem',
                    fontSize: '10px',
                    fontWeight: '900',
                    color: 'var(--tg-text)'
                  }}
                  itemStyle={{ color: 'var(--tg-accent)' }}
                />
                <Bar 
                  dataKey="progress" 
                  fill="#3b82f6" 
                  radius={[0, 12, 12, 0]} 
                  barSize={20}
                >
                  {missionProgressData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.progress === 100 ? '#10b981' : '#3b82f6'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="space-y-6">
        <div className="flex justify-between items-center px-2">
          <div className="space-y-1">
            <h3 className="text-sm font-black uppercase tracking-widest text-tg-text">ماموریت‌های فعال</h3>
            <p className="text-[8px] font-black text-tg-text-muted uppercase tracking-tighter">آخرین اهداف ابلاغی مرکز فرماندهی</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
            <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest font-bold">به‌روزرسانی لحظه‌ای</span>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {activeMissions.length > 0 ? activeMissions.map((mission) => {
            const missionTasks = userTasks.filter(t => t.missionId === mission.id);
            const completion = getMissionCompletion(mission.id);

            return (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                key={mission.id} 
                className="bg-tg-surface rounded-[2.5rem] border border-tg-border overflow-hidden group hover:border-blue-500/30 transition-all shadow-2xl shadow-black/20"
              >
                <div className="p-6 space-y-6">
                  <div className="flex justify-between items-start">
                    <div className="flex gap-4">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border border-tg-border group-hover:border-opacity-50 transition-all shadow-inner ${
                        mission.type === 'urgent' ? 'bg-red-500/10 text-red-500 border-red-500/20' : 
                        mission.type === 'special' ? 'bg-purple-500/10 text-purple-500 border-purple-500/20' : 
                        'bg-blue-500/10 text-blue-500 border-blue-500/20'
                      }`}>
                        <Target size={28} />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-sm font-black text-tg-text">{mission.title}</h4>
                        <div className="flex items-center gap-2">
                          <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-md ${
                            mission.type === 'urgent' ? 'bg-red-500/10 text-red-500' : 
                            mission.type === 'special' ? 'bg-purple-500/10 text-purple-500' : 
                            'bg-blue-500/10 text-blue-500'
                          }`}>{mission.type === 'urgent' ? 'فوری' : mission.type === 'special' ? 'ویژه' : 'روزانه'}</span>
                          <span className="text-tg-border">•</span>
                          <span className="text-[9px] font-black text-tg-text-muted uppercase tracking-widest">{mission.reward} امتیاز</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right space-y-1">
                      {mission.educationId && (
                        <button 
                          onClick={() => onTabChange('education')}
                          className="p-2.5 bg-emerald-500/10 text-emerald-500 rounded-xl border border-emerald-500/20 hover:bg-emerald-500/20 transition-all mb-2"
                          title="Learn More"
                        >
                          <GraduationCap size={18} />
                        </button>
                      )}
                      <div className="flex flex-col items-end gap-1">
                        <span className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">
                          {Math.round(completion * 100)}% تکمیل شده
                        </span>
                        <div className="w-20 h-1.5 bg-black/10 dark:bg-black/40 rounded-full overflow-hidden border border-tg-border p-[1px]">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${completion * 100}%` }}
                            className={`h-full rounded-full ${
                              completion === 1 ? 'bg-emerald-500' : 'bg-blue-500'
                            }`}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-tg-text-muted font-medium leading-relaxed">{mission.description}</p>

                  <div className="space-y-3">
                    <div className="flex items-center gap-2 px-1">
                      <div className="h-[1px] flex-1 bg-tg-border" />
                      <span className="text-[9px] font-black text-tg-text-muted uppercase tracking-widest">وظایف زیرمجموعه</span>
                      <div className="h-[1px] flex-1 bg-tg-border" />
                    </div>
                    <div className="grid grid-cols-1 gap-2">
                      {missionTasks.map((task) => {
                        const isUserTask = task.assignedTo === user.uid || !task.assignedTo;
                        return (
                          <div 
                            key={task.id} 
                            onClick={() => isUserTask && (task.status === 'pending' || task.status === 'rejected') && setSelectedTask({missionId: mission.id, task})}
                            className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${
                              task.status === 'completed' ? 'bg-emerald-500/5 border-emerald-500/10' : 
                              task.status === 'submitted' ? 'bg-amber-500/5 border-amber-500/10' :
                              task.status === 'rejected' ? 'bg-red-500/5 border-red-500/10 cursor-pointer' :
                              isUserTask ? 'bg-black/5 dark:bg-white/5 border-tg-border hover:border-blue-500/50 cursor-pointer active:scale-[0.98]' : 
                              'bg-black/5 dark:bg-white/5 border-tg-border opacity-50'
                            }`}
                          >
                            <div className="flex items-center gap-4">
                              <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                                task.status === 'completed' ? 'bg-emerald-500/20 text-emerald-500' : 
                                task.status === 'submitted' ? 'bg-amber-500/20 text-amber-500' :
                                task.status === 'rejected' ? 'bg-red-500/20 text-red-500' :
                                task.platform === 'twitter' ? 'bg-blue-500/20 text-blue-500' : 
                                'bg-black/10 dark:bg-slate-800 text-tg-text-muted'
                              }`}>
                                {task.status === 'completed' ? <CheckCircle2 size={16} /> : 
                                 task.status === 'submitted' ? <Clock size={16} /> :
                                 task.status === 'rejected' ? <AlertCircle size={16} /> :
                                 task.platform === 'twitter' ? <Twitter size={16} /> : <Target size={16} />}
                              </div>
                              <div>
                                <p className={`text-[11px] font-black ${
                                  task.status === 'completed' ? 'text-emerald-500' : 
                                  task.status === 'submitted' ? 'text-amber-500' :
                                  task.status === 'rejected' ? 'text-red-500' :
                                  'text-tg-text'
                                }`}>
                                  {task.title}
                                </p>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <span className="text-[8px] font-black text-tg-text-muted uppercase tracking-widest">{task.platform}</span>
                                  {task.status === 'rejected' && task.adminFeedback && (
                                    <>
                                      <span className="text-tg-border">•</span>
                                      <span className="text-[8px] font-black text-red-400">علت رد: {task.adminFeedback}</span>
                                    </>
                                  )}
                                  {task.deadline && task.status !== 'completed' && (
                                    <>
                                      <span className="text-tg-border">•</span>
                                      <span className="text-[8px] font-black text-amber-500 uppercase tracking-widest flex items-center gap-1">
                                        <Clock size={10} />
                                        {task.deadline.includes('T') ? new Date(task.deadline).toLocaleString('fa-IR', { hour: '2-digit', minute: '2-digit' }) : task.deadline}
                                      </span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              {task.status === 'completed' ? (
                                <span className="text-[8px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-md border border-emerald-500/20 uppercase tracking-widest">تکمیل شده</span>
                              ) : task.status === 'submitted' ? (
                                <span className="text-[8px] font-black text-amber-500 bg-amber-500/10 px-2 py-1 rounded-md border border-amber-500/20 uppercase tracking-widest">در انتظار تایید</span>
                              ) : task.status === 'rejected' ? (
                                <span className="text-[8px] font-black text-red-500 bg-red-500/10 px-2 py-1 rounded-md border border-red-500/20 uppercase tracking-widest">تلاش مجدد</span>
                              ) : (
                                <>
                                  <div className="flex items-center gap-1">
                                    <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest">{task.points}</span>
                                    <span className="text-[7px] text-tg-text-muted font-black">امتیاز</span>
                                  </div>
                                  {isUserTask && <ChevronLeft size={14} className="text-tg-text-muted" />}
                                </>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          }) : (
          <div className="bg-tg-surface p-12 rounded-[2.5rem] border border-dashed border-tg-border text-center space-y-4 transition-colors">
                <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mx-auto text-slate-600">
                  <Archive size={32} />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-black text-slate-400 uppercase">ماموریت فعالی یافت نشد</p>
                  <p className="text-[10px] text-slate-600 font-bold uppercase tracking-tighter">تمام عملیات‌ها با موفقیت به پایان رسیده‌اند</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {archivedMissions.length > 0 && (
          <div className="space-y-6 pt-4">
            <button 
              onClick={() => setShowArchived(!showArchived)}
              className="flex justify-between items-center w-full px-2 group"
            >
              <div className="space-y-1 text-right">
                <h3 className="text-sm font-black uppercase tracking-widest text-slate-500 group-hover:text-slate-400 transition-colors">بایگانی عملیات‌ها</h3>
                <p className="text-[8px] font-black text-slate-600 uppercase tracking-tighter">ماموریت‌های پایان یافته و بایگانی شده ({archivedMissions.length})</p>
              </div>
              <Archive size={16} className={`text-slate-600 transition-all ${showArchived ? 'rotate-180 text-blue-500' : ''}`} />
            </button>

            {showArchived && (
              <div className="grid grid-cols-1 gap-4">
                {archivedMissions.map((mission) => {
                  const missionTasks = userTasks.filter(t => t.missionId === mission.id);
                  const completion = getMissionCompletion(mission.id);
                  return (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 0.6, scale: 1 }}
                      whileHover={{ opacity: 1 }}
                      key={mission.id} 
                      className="bg-[#171e28]/50 rounded-[2.5rem] border border-white/5 overflow-hidden shadow-xl"
                    >
                      <div className="p-6 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-slate-500">
                            <CheckCircle2 size={20} />
                          </div>
                          <div>
                            <h4 className={`text-xs font-black ${mission.isArchived ? 'text-slate-500 line-through' : 'text-slate-300'}`}>{mission.title}</h4>
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-1">تکمیل شده در {new Date(mission.createdAt).toLocaleDateString('fa-IR')}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-[8px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-md border border-emerald-500/20 uppercase tracking-widest">موفقیت‌آمیز</span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    );
};

const MessengerScreen = ({ chats, setChats, user, setToast }: { chats: Chat[], setChats: React.Dispatch<React.SetStateAction<Chat[]>>, user: UserProfile, setToast: (t: any) => void }) => {
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [messengerTab, setMessengerTab] = useState<'all' | 'channels' | 'info'>('all');
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [newChannel, setNewChannel] = useState({ name: '', description: '', avatar: '📢' });

  const [showBroadcast, setShowBroadcast] = useState(false);
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [targetChannels, setTargetChannels] = useState<string[]>(['all']);

  const handleBroadcast = async () => {
    if (!broadcastMessage) return;
    
    let targetIds = targetChannels.includes('all') 
      ? filteredChats.map(c => c.id) 
      : targetChannels;

    const newMsg: Message = { 
      id: Date.now().toString(), 
      text: broadcastMessage, 
      sender: user.name, 
      time: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) 
    };

    const updatedChats = chats.map(c => 
      targetIds.includes(c.id) 
        ? { ...c, messages: [...c.messages, newMsg], lastMsg: broadcastMessage, time: 'الان' } 
        : c
    );
    
    setChats(updatedChats);
    setBroadcastMessage('');
    setShowBroadcast(false);
    setToast({ message: 'پیام با موفقیت به تمامی کانال‌های هدف ابلاغ شد', type: 'success' });

    await fetch('/api/data/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: 'messenger.chats', value: updatedChats })
    });
  };

  const activeChat = chats.find(c => c.id === activeChatId);
  
  const filteredChats = chats.filter(c => 
    c.id.startsWith('ch-') || 
    ['شمسا', 'متنا', 'نصرا', 'رسانه‌محله'].some(name => c.name.includes(name))
  );

  const handleCreateChannel = async () => {
    if (!newChannel.name) return;
    const channel: Chat = {
      id: `ch-${Date.now()}`,
      name: newChannel.name,
      description: newChannel.description,
      avatar: newChannel.avatar,
      lastMsg: 'کانال ایجاد شد',
      time: 'الان',
      unread: 0,
      color: 'bg-emerald-600',
      type: 'channel',
      messages: [],
      subscribers: 0
    };
    const updatedChats = [...chats, channel];
    setChats(updatedChats);
    setShowCreateChannel(false);
    setNewChannel({ name: '', description: '', avatar: '📢' });

    await fetch('/api/data/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: 'messenger.chats', value: updatedChats })
    });
  };

  const handleSendMessage = async () => {
    if (!message || !activeChatId) return;
    
    // Only admin or Nahiye level managers can send in operational channels
    const isNahiyeAdmin = user.role === 'admin' || user.unitLevel === 'nahiye';
    if (activeChat?.type === 'channel' && !isNahiyeAdmin) return;

    const newMsg: Message = { 
      id: Date.now().toString(), 
      text: message, 
      sender: user.name, 
      time: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) 
    };

    const updatedChats = chats.map(c => 
      c.id === activeChatId ? { ...c, messages: [...c.messages, newMsg], lastMsg: message, time: 'الان' } : c
    );
    
    setChats(updatedChats);
    const sentMessage = message;
    setMessage('');

    await fetch('/api/data/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: 'messenger.chats', value: updatedChats })
    });
  };

  if (activeChat) {
    return (
      <div className="flex flex-col h-full bg-tg-bg relative z-50 transition-colors overflow-hidden">
        {/* Chat Header */}
        <div className="px-5 py-4 bg-tg-surface border-b border-tg-border flex items-center justify-between transition-colors">
          <div className="flex items-center gap-3">
            <button onClick={() => setActiveChatId(null)} className="w-10 h-10 flex items-center justify-center bg-black/5 dark:bg-white/5 hover:bg-tg-border rounded-2xl text-tg-accent transition-all active:scale-90 border border-tg-border">
              <ArrowRight size={20} />
            </button>
            <div className="flex items-center gap-3">
              <div className={`w-11 h-11 rounded-2xl flex items-center justify-center text-white font-black text-xs shadow-xl overflow-hidden border border-tg-border ${activeChat.color}`}>
                {activeChat.avatar.length > 2 ? <img src={activeChat.avatar} className="w-full h-full object-cover" /> : activeChat.avatar}
              </div>
              <div className="space-y-0.5">
                <h3 className="font-black text-sm text-tg-text">{activeChat.name}</h3>
                <p className="text-[8px] font-black text-emerald-500 uppercase tracking-[0.1em]">
                  {activeChat.type === 'channel' ? `${activeChat.subscribers} دنبال‌کننده ستاد` : 'کانال ارتباطی متصل • آنلاین'}
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button className="p-2.5 bg-black/5 dark:bg-white/5 text-tg-text-muted hover:text-tg-accent rounded-xl border border-tg-border transition-colors">
              <MoreVertical size={20} />
            </button>
          </div>
        </div>

        {activeChat.type === 'channel' && activeChat.description && (
          <div className="bg-tg-surface/50 p-4 border-b border-tg-border transition-colors">
            <div className="flex items-center gap-2 mb-1.5 opacity-60">
              <Info size={12} className="text-tg-accent" />
              <p className="text-[8px] font-black text-tg-accent uppercase tracking-widest">توضیحات ماموریت عملیاتی</p>
            </div>
            <p className="text-[10px] text-tg-text font-medium leading-relaxed pr-6">{activeChat.description}</p>
          </div>
        )}

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 no-scrollbar bg-tg-bg transition-colors">
          <div className="max-w-3xl mx-auto w-full flex flex-col space-y-4">
            {activeChat.messages.map((m: Message) => (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                key={m.id} 
                className={`max-w-[85%] p-4 rounded-3xl text-[11px] font-medium leading-relaxed shadow-sm relative group/msg transition-all ${
                  m.sender === user.name 
                  ? 'bg-tg-accent self-end rounded-tr-none text-white' 
                  : 'bg-tg-surface self-start rounded-tl-none text-tg-text border border-tg-border'
                }`}
              >
              {activeChat.type !== 'channel' && m.sender !== user.name && (
                <span className="text-[8px] font-black text-blue-400 block mb-1 uppercase tracking-widest">{m.sender}</span>
              )}
              <p>{m.text}</p>
              <div className="flex justify-between items-center mt-1.5 gap-1 opacity-60">
                <button 
                  onClick={async (e) => {
                    e.stopPropagation();
                    const updatedChats = chats.map(c => 
                      c.id === activeChatId ? {
                        ...c,
                        messages: c.messages.map(msg => msg.id === m.id ? { ...msg, isMarked: !msg.isMarked } : msg)
                      } : c
                    );
                    setChats(updatedChats);
                    await fetch('/api/data/update', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ path: 'messenger.chats', value: updatedChats })
                    });
                  }}
                  className={`p-1 rounded-lg transition-all ${m.isMarked ? 'text-amber-400 opacity-100' : 'text-tg-text-muted opacity-0 group-hover/msg:opacity-100'}`}
                >
                  <Bookmark size={10} fill={m.isMarked ? 'currentColor' : 'none'} />
                </button>
                <div className="flex items-center gap-1">
                  <span className="text-[7px] font-black">{m.time}</span>
                  {m.sender === user.name && <CheckCheck size={10} className="text-white" />}
                </div>
              </div>
            </motion.div>
          ))}
          </div>
        </div>

        {/* Input Area */}
        {(activeChat.type !== 'channel' || user.role === 'admin' || user.role === 'manager') ? (
          <div className="p-4 bg-tg-surface border-t border-tg-border flex gap-3 items-center sticky bottom-0 transition-colors">
            <button className="w-12 h-12 flex items-center justify-center bg-black/5 dark:bg-white/5 text-tg-text-muted rounded-2xl hover:bg-tg-border transition-all border border-tg-border">
              <Plus size={20} />
            </button>
            <div className="flex-1 bg-black/5 dark:bg-white/5 rounded-2xl flex items-center px-4 py-1 border border-tg-border focus-within:border-tg-accent/50 transition-all">
              <input
                type="text"
                value={message}
                onChange={e => setMessage(e.target.value)}
                onKeyPress={e => e.key === 'Enter' && handleSendMessage()}
                placeholder="پیام خود را بنویسید..."
                className="flex-1 bg-transparent border-none outline-none text-xs py-3 text-tg-text placeholder:text-tg-text-muted"
              />
              <button className="text-tg-text-muted hover:text-tg-accent transition-colors"><Smile size={20} /></button>
            </div>
            <button 
              onClick={handleSendMessage} 
              disabled={!message.trim()} 
              className="w-12 h-12 bg-tg-accent text-white rounded-2xl flex items-center justify-center active:scale-90 transition-all disabled:opacity-30 shadow-lg shadow-tg-accent/20"
            >
              <Send size={20} className="rtl:rotate-180" />
            </button>
          </div>
        ) : (
          <div className="p-6 bg-tg-surface border-t border-tg-border text-center transition-colors">
            <p className="text-[10px] font-black text-tg-text-muted uppercase tracking-[0.2em]">فقط مدیران مجاز به ارسال پیام در این کانال عملیاتی هستند</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-tg-bg pb-24 transition-colors">
      <div className="p-6 space-y-4">
        <div className="flex justify-between items-center px-1">
          <div className="space-y-1">
            <h2 className="text-lg font-black text-tg-text">مدیریت پیام و اطلاع‌رسانی</h2>
            <p className="text-[7px] font-bold text-tg-text-muted uppercase tracking-[0.2em]">ستاد ابلاغ و عملیات رسانه‌ای</p>
          </div>
          <div className="flex gap-2">
            {(user.role === 'admin' || user.role === 'manager' || user.unitLevel === 'nahiye') && (
              <button 
                onClick={() => setShowBroadcast(true)}
                className="flex items-center gap-2 px-3 py-2 bg-tg-accent text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg shadow-tg-accent/20 active:scale-95 transition-all"
              >
                <Megaphone size={14} />
                ابلاغ همگانی
              </button>
            )}
            <div className="w-10 h-10 bg-tg-accent/10 text-tg-accent rounded-xl flex items-center justify-center border border-tg-accent/20">
              <Signal size={20} />
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-5 py-2">
           <div className="space-y-4">
                {filteredChats.map((chat, idx) => (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: idx * 0.05 }}
                    key={chat.id} 
                    onClick={() => setActiveChatId(chat.id)}
                    className="flex flex-col gap-3 p-5 bg-tg-surface rounded-[2rem] border border-tg-border cursor-pointer transition-all group hover:border-tg-accent/40 shadow-xl active:scale-[0.98]"
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white font-black text-xl shadow-xl overflow-hidden border border-tg-border group-hover:border-tg-accent/30 transition-all ${chat.color}`}>
                        {chat.avatar.length > 2 ? <img src={chat.avatar} className="w-full h-full object-cover" /> : chat.avatar}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <h3 className="font-black text-sm truncate group-hover:text-tg-accent transition-colors text-tg-text">{chat.name}</h3>
                          <span className="text-[7px] font-black text-tg-text-muted uppercase tracking-widest">{chat.time}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`w-1.5 h-1.5 rounded-full ${chat.unread > 0 ? 'bg-tg-accent animate-pulse' : 'bg-emerald-500'}`} />
                          <p className="text-[9px] text-tg-text-muted font-black uppercase tracking-tight">
                            {chat.subscribers.toLocaleString('fa-IR')} مخاطب سازماندهی شده
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="h-px bg-gradient-to-r from-transparent via-tg-border to-transparent w-full" />
                    <p className="text-[10px] text-tg-text-muted font-medium leading-relaxed line-clamp-1 px-1">
                       {chat.lastMsg}
                    </p>
                  </motion.div>
                ))}
              </div>

        {(user.role === 'admin' || user.role === 'manager' || user.unitLevel === 'nahiye') && (
           <div className="bg-tg-accent/5 rounded-3xl p-6 border border-tg-accent/10 text-center mt-4">
             <Info size={24} className="mx-auto text-tg-accent mb-3" />
             <p className="text-[10px] font-black text-tg-text uppercase mb-2">اطلاعیه سطح واحد</p>
             <p className="text-[10px] text-tg-text-muted leading-relaxed font-medium">شما به عنوان مدیر، مجاز به ارسال پیام و ابلاغیه در تمامی کانال‌های عملیاتی فوق هستید.</p>
           </div>
        )}
      </div>

      <BottomSheet isOpen={showBroadcast} onClose={() => setShowBroadcast(false)} title="ابلاغ پیام همگانی (برودکست)">
        <div className="space-y-6 p-1">
          <div className="bg-tg-accent/5 p-4 rounded-2xl border border-tg-accent/10">
            <div className="flex items-center gap-2 text-tg-accent mb-2">
              <ShieldAlert size={16} />
              <p className="text-[10px] font-black uppercase">هشدار ابلاغ استراتژیک</p>
            </div>
            <p className="text-[10px] text-tg-text-muted leading-relaxed font-medium">پیام شما به صورت آنی برای تمامی مخاطبان کانال‌های انتخاب شده ابلاغ خواهد شد. لطفاً در انتخاب محتوا دقت فرمایید.</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[9px] font-black text-tg-text-muted uppercase px-1">انتخاب کانال‌های هدف</label>
              <div className="flex flex-wrap gap-2">
                <button 
                  onClick={() => setTargetChannels(['all'])}
                  className={`px-3 py-1.5 rounded-lg text-[9px] font-black border transition-all ${targetChannels.includes('all') ? 'bg-tg-accent text-white border-tg-accent' : 'bg-black/5 dark:bg-white/5 text-tg-text-muted border-tg-border'}`}
                >
                  همه کانال‌ها
                </button>
                {filteredChats.map(c => (
                  <button 
                    key={c.id}
                    onClick={() => {
                      if (targetChannels.includes('all')) {
                        setTargetChannels([c.id]);
                      } else {
                        const newTargets = targetChannels.includes(c.id) 
                          ? targetChannels.filter(id => id !== c.id) 
                          : [...targetChannels, c.id];
                        setTargetChannels(newTargets.length === 0 ? ['all'] : newTargets);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-lg text-[9px] font-black border transition-all ${!targetChannels.includes('all') && targetChannels.includes(c.id) ? 'bg-tg-accent text-white border-tg-accent' : 'bg-black/5 dark:bg-white/5 text-tg-text-muted border-tg-border'}`}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[9px] font-black text-tg-text-muted uppercase px-1">متن ابلاغیه</label>
              <textarea 
                value={broadcastMessage}
                onChange={e => setBroadcastMessage(e.target.value)}
                placeholder="متن پیام خود را اینجا بنویسید..."
                className="tg-input bg-black/5 dark:bg-white/5 border-tg-border focus:border-tg-accent/50 min-h-[120px] py-4 text-xs font-medium leading-relaxed"
              />
            </div>
          </div>

          <button 
            onClick={handleBroadcast}
            disabled={!broadcastMessage.trim()}
            className="w-full py-4 bg-tg-accent text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl shadow-tg-accent/20 active:scale-95 transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-3"
          >
            <Send size={18} />
            انتشار و ابلاغ سراسری پیام
          </button>
        </div>
      </BottomSheet>

      <BottomSheet isOpen={showCreateChannel} onClose={() => setShowCreateChannel(false)} title="ایجاد کانال جدید">
        <div className="space-y-6 p-1">
          <div className="flex flex-col items-center gap-3">
            <div 
              onClick={() => {
                const url = prompt('لینک تصویر پروفایل کانال:');
                if (url) setNewChannel({...newChannel, avatar: url});
              }}
              className="w-20 h-20 bg-black/20 rounded-2xl flex items-center justify-center text-3xl cursor-pointer overflow-hidden border-2 border-dashed border-white/10 hover:border-blue-500/50 transition-all group"
            >
              {newChannel.avatar.length > 2 ? <img src={newChannel.avatar} className="w-full h-full object-cover" /> : (
                <div className="flex flex-col items-center gap-1.5 text-slate-500 group-hover:text-blue-500 transition-colors">
                  <Camera size={24} />
                  <span className="text-[7px] font-black uppercase tracking-widest">آواتار</span>
                </div>
              )}
            </div>
          </div>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[8px] font-black text-slate-500 uppercase px-2">نام کانال</label>
              <input 
                value={newChannel.name}
                onChange={e => setNewChannel({...newChannel, name: e.target.value})}
                placeholder="مثلا: اخبار قرارگاه"
                className="tg-input bg-black/20 border-white/5 focus:border-blue-500/50 py-3 text-xs"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[8px] font-black text-slate-500 uppercase px-2">توضیحات کانال</label>
              <textarea 
                value={newChannel.description}
                onChange={e => setNewChannel({...newChannel, description: e.target.value})}
                placeholder="توضیحات کوتاهی در مورد فعالیت کانال بنویسید..."
                className="tg-input bg-black/20 border-white/5 focus:border-blue-500/50 min-h-[100px] py-3 text-xs"
              />
            </div>
          </div>
          <button 
            onClick={handleCreateChannel}
            className="w-full py-4 bg-blue-500 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all"
          >
            تاسیس و راه‌اندازی کانال
          </button>
        </div>
      </BottomSheet>
    </div>
  );
};

const MonitorScreen = ({ reports, setReports, user, setToast, trackedAccounts, setTrackedAccounts }: { reports: Report[], setReports: React.Dispatch<React.SetStateAction<Report[]>>, user: UserProfile, setToast: (t: {message: string, type: 'success' | 'error'} | null) => void, trackedAccounts: TrackedAccount[], setTrackedAccounts: (a: TrackedAccount[]) => void }) => {
  const [formData, setFormData] = useState({ title: '', url: '', description: '', category: 'individual' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);
  const [monitorTab, setMonitorTab] = useState<'reports' | 'accounts'>('reports');
  const [showAccountForm, setShowAccountForm] = useState(false);
  const [newAccData, setNewAccData] = useState({ name: '', handle: '', platform: 'twitter' as any, category: 'enemy' as any });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.description) {
      setToast({ message: 'لطفاً تمامی فیلدهای اجباری را تکمیل کنید', type: 'error' });
      return;
    }

    if (!isConfirming) {
      setIsConfirming(true);
      return;
    }

    setIsSubmitting(true);
    
    const newReport: Report = {
      id: Date.now().toString(),
      ...formData,
      timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      status: 'pending',
      author: user.name,
      authorId: user.uid
    };

    const updatedReports = [newReport, ...reports];
    setReports(updatedReports);
    
    try {
      await fetch('/api/data/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: 'operations.reports', value: updatedReports })
      });
      setIsSubmitting(false);
      setFormData({ title: '', url: '', description: '', category: 'individual' });
      setShowForm(false);
      setIsConfirming(false);
      setToast({ message: 'گزارش شما با موفقیت ثبت شد و در صف بررسی قرار گرفت', type: 'success' });
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
      setToast({ message: 'خطا در ثبت گزارش. لطفاً دوباره تلاش کنید', type: 'error' });
    }
  };

  const handleSaveAccount = async () => {
    if (newAccData.name && newAccData.handle) {
      const newAcc: TrackedAccount = {
        id: `acc-${Date.now()}`,
        ...newAccData,
        lastActivity: new Date().toISOString(),
        status: 'active'
      };
      const updated = [...trackedAccounts, newAcc];
      setTrackedAccounts(updated);
      try {
        await fetch('/api/data/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ path: 'tracking.accounts', value: updated })
        });
        setToast({ message: 'حساب جدید با موفقیت به لیست رصد اضافه شد', type: 'success' });
        setShowAccountForm(false);
        setNewAccData({ name: '', handle: '', platform: 'twitter', category: 'enemy' });
      } catch (err) {
        setToast({ message: 'خطا در ذخیره‌سازی اطلاعات', type: 'error' });
      }
    } else {
      setToast({ message: 'لطفاً تمامی فیلدها را تکمیل کنید', type: 'error' });
    }
  };

  return (
    <div className="p-6 space-y-8 pb-32 bg-app-bg min-h-screen transition-colors">
      <div className="flex justify-between items-center px-1">
        <div className="space-y-1">
          <h2 className="text-xl font-black text-tg-text">واحد رصد و پایش</h2>
          <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">مرکز ثبت گزارشات انفرادی و پایش</p>
        </div>
        <div className="flex gap-2">
          {monitorTab === 'accounts' && (user.role === 'admin' || user.role === 'manager') && (
            <button 
              onClick={() => setShowAccountForm(!showAccountForm)}
              className={`p-3.5 rounded-2xl shadow-xl active:scale-95 transition-all flex items-center gap-2 ${
                showAccountForm ? 'bg-red-500 text-white shadow-red-500/20' : 'bg-blue-500 text-white shadow-blue-500/20'
              }`}
            >
              {showAccountForm ? <Plus className="rotate-45" size={18} /> : <UserPlus size={18} />}
              <span className="text-[10px] font-black uppercase tracking-widest">
                {showAccountForm ? 'انصراف' : 'افزودن حساب'}
              </span>
            </button>
          )}
          {monitorTab === 'reports' && !showForm && (
            <button 
              onClick={() => setShowForm(true)}
              className="p-3.5 bg-blue-500 text-white rounded-2xl shadow-xl shadow-blue-500/20 active:scale-95 transition-all flex items-center gap-2"
            >
              <Plus size={20} />
              <span className="text-[10px] font-black uppercase tracking-widest">ثبت گزارش</span>
            </button>
          )}
        </div>
      </div>

      <div className="flex bg-black/5 dark:bg-black/20 p-1 rounded-2xl border border-tg-border">
        <button onClick={() => setMonitorTab('reports')} className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${monitorTab === 'reports' ? 'bg-blue-500 text-white shadow-lg' : 'text-tg-text-muted hover:text-tg-text'}`}>گزارشات عملیاتی</button>
        <button onClick={() => setMonitorTab('accounts')} className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${monitorTab === 'accounts' ? 'bg-blue-500 text-white shadow-lg' : 'text-tg-text-muted hover:text-tg-text'}`}>حساب‌های تحت نظر</button>
      </div>

      <div className="space-y-6">
        {monitorTab === 'reports' ? (
          <>
            <AnimatePresence>
              {showForm && (
                <motion.form 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  onSubmit={handleSubmit} 
                  className="space-y-5 overflow-hidden bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border shadow-2xl shadow-blue-500/5"
                >
                  {isConfirming ? (
                    <div className="space-y-6 animate-in fade-in zoom-in-95 duration-300">
                      <div className="p-4 bg-blue-500/5 rounded-2xl border border-blue-500/10 space-y-4">
                        <div className="flex items-center gap-3 text-blue-500">
                          <ShieldCheck size={20} />
                          <h4 className="text-xs font-black uppercase tracking-widest">تایید نهایی اطلاعات</h4>
                        </div>
                        <div className="space-y-3">
                          <div>
                            <p className="text-[8px] font-black text-tg-text-muted uppercase">عنوان گزارش</p>
                            <p className="text-[10px] font-bold text-tg-text mt-0.5">{formData.title}</p>
                          </div>
                          <div>
                            <p className="text-[8px] font-black text-tg-text-muted uppercase">نوع گزارش</p>
                            <p className="text-[10px] font-bold text-tg-text mt-0.5">
                              {formData.category === 'individual' ? 'گزارش انفرادی' : formData.category === 'public' ? 'گزارش مردمی' : 'تهدید امنیتی'}
                            </p>
                          </div>
                          {formData.url && (
                            <div>
                              <p className="text-[8px] font-black text-tg-text-muted uppercase">لینک مرتبط</p>
                              <p className="text-[10px] font-bold text-blue-400 mt-0.5 truncate">{formData.url}</p>
                            </div>
                          )}
                          <div>
                            <p className="text-[8px] font-black text-tg-text-muted uppercase">شرح گزارش</p>
                            <p className="text-[10px] font-bold text-tg-text-muted mt-0.5 leading-relaxed">{formData.description}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex gap-3">
                        <button 
                          type="button" 
                          onClick={() => setIsConfirming(false)}
                          className="flex-1 bg-black/5 dark:bg-white/5 hover:bg-tg-border text-tg-text-muted py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all"
                        >
                          ویرایش مجدد
                        </button>
                        <button 
                          disabled={isSubmitting}
                          type="submit" 
                          className="flex-[2] bg-emerald-500 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
                        >
                          {isSubmitting ? 'در حال ارسال...' : <><Check size={18} /><span>تایید و ارسال نهایی</span></>}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-2">
                        <label className="text-[9px] font-black text-tg-text-muted uppercase px-2">عنوان گزارش</label>
                        <input
                          required
                          type="text"
                          value={formData.title}
                          onChange={e => setFormData({...formData, title: e.target.value})}
                          placeholder="عنوان گزارش خود را وارد کنید..."
                          className="tg-input bg-black/5 dark:bg-black/20 border-tg-border focus:border-blue-500/50 text-tg-text"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[9px] font-black text-tg-text-muted uppercase px-2">لینک مرتبط (اختیاری)</label>
                        <input
                          type="url"
                          value={formData.url}
                          onChange={e => setFormData({...formData, url: e.target.value})}
                          placeholder="https://..."
                          className="tg-input bg-black/5 dark:bg-black/20 border-tg-border focus:border-blue-500/50 ltr text-tg-text"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[9px] font-black text-tg-text-muted uppercase px-2">نوع گزارش</label>
                        <select
                          value={formData.category}
                          onChange={e => setFormData({...formData, category: e.target.value})}
                          className="tg-input bg-black/5 dark:bg-black/20 border-tg-border focus:border-blue-500/50 text-tg-text"
                        >
                          <option value="individual">گزارش انفرادی (Individual)</option>
                          <option value="public">گزارش مردمی (Public Intel)</option>
                          <option value="security">تهدید امنیتی (Security)</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[9px] font-black text-tg-text-muted uppercase px-2">شرح گزارش</label>
                        <textarea
                          required
                          rows={4}
                          value={formData.description}
                          onChange={e => setFormData({...formData, description: e.target.value})}
                          placeholder="جزئیات گزارش را اینجا بنویسید..."
                          className="tg-input bg-black/5 dark:bg-black/20 border-tg-border focus:border-blue-500/50 resize-none leading-relaxed text-tg-text"
                        />
                      </div>
                      
                      <div className="flex gap-3 pt-2">
                        <button 
                          type="button" 
                          onClick={() => setShowForm(false)}
                          className="flex-1 bg-black/5 dark:bg-white/5 hover:bg-tg-border text-tg-text-muted py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all"
                        >
                          انصراف
                        </button>
                        <button 
                          type="submit" 
                          className="flex-[2] bg-blue-500 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-blue-500/20 flex items-center justify-center gap-2 active:scale-95 transition-all"
                        >
                          <Send size={18} className="rtl:rotate-180" />
                          <span>بررسی و ثبت گزارش</span>
                        </button>
                      </div>
                    </>
                  )}
                </motion.form>
              )}
            </AnimatePresence>

            <div className="space-y-4">
              <div className="flex justify-between items-center px-1">
                <h3 className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">آخرین گزارشات ثبت شده</h3>
                <Activity size={14} className="text-tg-text-muted" />
              </div>
              {reports.length > 0 ? (
                <div className="grid grid-cols-1 gap-4">
                  {reports.map((report, idx) => (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      key={report.id} 
                      className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border group hover:border-blue-500/30 transition-all shadow-2xl shadow-black/20"
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full shadow-lg ${
                            report.category === 'individual' ? 'bg-blue-500' :
                            report.category === 'public' ? 'bg-orange-500' : 'bg-red-500'
                          }`} />
                          <h4 className="font-black text-sm group-hover:text-blue-500 transition-colors text-tg-text">{report.title}</h4>
                        </div>
                        <span className="text-[9px] font-black text-tg-text-muted uppercase tracking-widest">{report.timestamp}</span>
                      </div>
                      <p className="text-xs text-tg-text-muted font-medium leading-relaxed mb-5 line-clamp-2">
                        {report.description}
                      </p>
                      <div className="flex justify-between items-center pt-4 border-t border-tg-border">
                        <span className="text-[8px] font-black bg-black/5 dark:bg-white/5 px-3 py-1.5 rounded-xl text-tg-text-muted uppercase tracking-widest border border-tg-border">
                          {report.category === 'individual' ? 'انفرادی' :
                          report.category === 'public' ? 'مردمی' : 'امنیتی'}
                        </span>
                        <div className="flex items-center gap-2 text-[9px] text-emerald-500 font-black uppercase tracking-widest">
                          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                          <span>در حال بررسی</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-20 bg-tg-surface rounded-[3rem] border border-tg-border border-dashed">
                  <AlertCircle size={48} className="mx-auto mb-4 text-tg-text-muted opacity-20" />
                  <p className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">گزارشی یافت نشد</p>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="space-y-6">
            <AnimatePresence>
              {showAccountForm && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border shadow-2xl transition-colors"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-tg-text-muted uppercase px-2">نام نمایشی حساب</label>
                      <input 
                        placeholder="مثلاً: شبکه خبری العربیه" 
                        className="tg-input bg-black/5 dark:bg-black/20 border-tg-border text-tg-text" 
                        value={newAccData.name} 
                        onChange={e => setNewAccData({...newAccData, name: e.target.value})} 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-tg-text-muted uppercase px-2">شناسه / هندل (@)</label>
                      <input 
                        placeholder="@username" 
                        className="tg-input bg-black/5 dark:bg-black/20 border-tg-border ltr text-right text-tg-text" 
                        value={newAccData.handle} 
                        onChange={e => setNewAccData({...newAccData, handle: e.target.value})} 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-tg-text-muted uppercase px-2">پلتفرم فعالیت</label>
                      <select 
                        className="tg-input bg-black/5 dark:bg-black/20 border-tg-border pt-2 text-tg-text" 
                        value={newAccData.platform} 
                        onChange={e => setNewAccData({...newAccData, platform: e.target.value as any})}
                      >
                        <option value="twitter">توییتر (Twitter/X)</option>
                        <option value="instagram">اینستاگرام (Instagram)</option>
                        <option value="bale">پیام‌رسان بله (Bale)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-tg-text-muted uppercase px-2">دسته بندی هدف</label>
                      <select 
                        className="tg-input bg-black/5 dark:bg-black/20 border-tg-border pt-2 text-tg-text" 
                        value={newAccData.category} 
                        onChange={e => setNewAccData({...newAccData, category: e.target.value as any})}
                      >
                        <option value="enemy">معاند / هدف (Enemy)</option>
                        <option value="friendly">خودی / همسو (Friendly)</option>
                        <option value="neutral">خنثی / خاکستری (Neutral)</option>
                      </select>
                    </div>
                  </div>
                  <button 
                    onClick={handleSaveAccount}
                    className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 size={18} />
                    <span>تایید و افزودن به پایگاه داده رصد</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-tg-surface p-5 rounded-[2rem] border border-tg-border space-y-2 shadow-sm transition-colors">
                <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-widest">کل حساب‌ها</p>
                <p className="text-2xl font-black text-tg-text">{trackedAccounts.length}</p>
              </div>
              <div className="bg-tg-surface p-5 rounded-[2rem] border border-tg-border space-y-2 shadow-sm transition-colors">
                <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-widest">حساب‌های معاند</p>
                <p className="text-2xl font-black text-red-500">{trackedAccounts.filter(a => a.category === 'enemy').length}</p>
              </div>
            </div>

            <div className="bg-tg-surface rounded-[2.5rem] border border-tg-border overflow-hidden shadow-xl transition-colors">
              <div className="p-6 border-b border-tg-border flex justify-between items-center bg-black/5 dark:bg-white/5 transition-colors">
                <h3 className="text-xs font-black uppercase tracking-widest text-tg-text">پایگاه داده حساب‌های تحت نظر</h3>
                <Filter size={16} className="text-tg-text-muted" />
              </div>
              <div className="overflow-x-auto no-scrollbar">
                <table className="w-full text-right">
                  <thead>
                    <tr className="bg-black/10 dark:bg-black/20 text-[8px] font-black uppercase tracking-widest text-tg-text-muted transition-colors">
                      <th className="px-6 py-4">شناسه / هندل</th>
                      <th className="px-6 py-4 text-center">پلتفرم</th>
                      <th className="px-6 py-4">دسته</th>
                      <th className="px-6 py-4">آخرین فعالیت</th>
                      <th className="px-6 py-4">وضعیت</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-tg-border">
                    {trackedAccounts.map((acc) => (
                      <tr key={acc.id} className="hover:bg-black/5 dark:hover:bg-white/5 transition-colors group">
                        <td className="px-6 py-5">
                          <p className="text-[11px] font-black group-hover:text-blue-500 transition-colors text-tg-text">{acc.name}</p>
                          <p className="text-[9px] text-tg-text-muted font-bold ltr text-right">{acc.handle}</p>
                        </td>
                        <td className="px-6 py-5 text-center">
                          <div className={`w-8 h-8 rounded-lg mx-auto flex items-center justify-center ${
                            acc.platform === 'twitter' ? 'bg-blue-500/10 text-blue-500' :
                            acc.platform === 'bale' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-pink-500/10 text-pink-500'
                          }`}>
                            {acc.platform === 'twitter' && <Twitter size={14} />}
                            {acc.platform === 'bale' && <MessageSquare size={14} />}
                            {acc.platform === 'instagram' && <Instagram size={14} />}
                          </div>
                        </td>
                        <td className="px-6 py-5">
                          <span className={`text-[8px] font-black px-2 py-0.5 rounded-lg uppercase ${
                            acc.category === 'enemy' ? 'bg-red-500/10 text-red-500' :
                            acc.category === 'friendly' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-500/10 text-slate-500'
                          }`}>
                            {acc.category === 'enemy' ? 'معاند' : acc.category === 'friendly' ? 'همسو' : 'خنثی'}
                          </span>
                        </td>
                        <td className="px-6 py-5">
                          <span className="text-[9px] font-bold text-tg-text-muted opacity-60">{new Date(acc.lastActivity).toLocaleDateString('fa-IR')}</span>
                        </td>
                        <td className="px-6 py-5">
                          <div className="flex items-center gap-2">
                             <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                             <span className="text-[9px] font-black text-emerald-500 uppercase">فعال</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const LibraryScreen = ({ items, setItems, onShare }: { items: ContentItem[], setItems: React.Dispatch<React.SetStateAction<ContentItem[]>>, onShare: (i: ContentItem) => void }) => {
  const togglePublished = (id: string) => {
    setItems(prev => prev.map(item => item.id === id ? { ...item, isPublished: !item.isPublished } : item));
  };

  return (
    <div className="flex flex-col min-h-screen bg-tg-bg transition-colors">
      <div className="sticky top-0 z-20 bg-tg-bg/80 backdrop-blur-xl border-b border-tg-border px-6 py-4 flex justify-between items-center transition-colors">
        <div className="space-y-0.5">
          <h2 className="text-sm font-black text-tg-text">بانک محتوا (واحد انتشار)</h2>
          <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">مخزن محتوا و مرکز انتشار</p>
        </div>
        <span className="bg-tg-accent/10 text-tg-accent px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border border-tg-accent/20">
          {items.length} محتوا
        </span>
      </div>

      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 gap-6">
          {items.length > 0 ? items.map(item => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              key={item.id} 
              className="bg-tg-surface rounded-[2.5rem] border border-tg-border overflow-hidden group hover:border-tg-accent/30 transition-all shadow-2xl shadow-black/20"
            >
              {item.imageUrl && (
                <div className="relative aspect-video overflow-hidden">
                  <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-t from-tg-surface via-transparent to-transparent opacity-60" />
                  <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md border border-white/10 text-white text-[8px] px-3 py-1.5 rounded-xl font-black uppercase tracking-widest">
                    {item.type}
                  </div>
                </div>
              )}
              <div className="p-6 space-y-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-black/5 dark:bg-white/5 flex items-center justify-center border border-tg-border group-hover:border-tg-accent/50 transition-all">
                      {item.type === 'tweet' && <Twitter size={20} className="text-blue-400" />}
                      {item.type === 'poster' && <ImageIcon size={20} className="text-purple-400" />}
                      {item.type === 'story' && <Video size={20} className="text-pink-400" />}
                      {item.type === 'video' && <Video size={20} className="text-red-400" />}
                    </div>
                    <div>
                      <h3 className="font-black text-sm">{item.title}</h3>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <Download size={10} className="text-slate-500" />
                        <span className="text-[10px] text-slate-500 font-black">{item.downloadCount} دانلود</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <p className="text-xs text-slate-400 leading-relaxed font-medium">
                  {item.content}
                </p>

                <div className="flex flex-wrap gap-2">
                  {item.hashtags.map((tag, i) => (
                    <span key={i} className="text-[9px] font-black text-blue-500 bg-blue-500/5 px-2 py-1 rounded-lg border border-blue-500/10">
                      #{tag}
                    </span>
                  ))}
                </div>
                
                <div className="flex gap-3 pt-2">
                  <button 
                    onClick={() => onShare(item)}
                    className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all"
                  >
                    <Share2 size={16} />
                    <span>اشتراک</span>
                  </button>
                  <button className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all">
                    <Download size={16} />
                    <span>دانلود</span>
                  </button>
                  <button 
                    onClick={() => togglePublished(item.id)}
                    className={`flex-1 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all ${
                      item.isPublished 
                      ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' 
                      : 'bg-blue-500 text-white shadow-lg shadow-blue-500/20'
                    }`}
                  >
                    {item.isPublished ? <CheckCircle2 size={16} /> : <Plus size={16} />}
                    <span>{item.isPublished ? 'منتشر شده' : 'انتشار'}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )) : (
            <div className="bg-tg-surface p-16 rounded-[3rem] border border-tg-border text-center space-y-6 shadow-sm">
              <div className="w-24 h-24 bg-black/5 dark:bg-white/5 rounded-[2rem] flex items-center justify-center mx-auto text-tg-text-muted border border-tg-border">
                <AlertCircle size={48} />
              </div>
              <div className="space-y-2">
                <h4 className="text-base font-black">محتوایی یافت نشد</h4>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const PublishingScreen = ({ content, user }: { content: GordanContent[], user: UserProfile }) => {
  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar bg-tg-bg transition-colors">
      <div className="space-y-1 px-1">
        <h3 className="text-sm font-black text-tg-text">مدیریت انتشار محتوا</h3>
        <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">صف انتظار و زمان‌بندی انتشار در شبکه‌های اجتماعی</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {content.length > 0 ? (
          content.map((item, idx) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              key={item.id} 
              className="bg-tg-surface rounded-[2rem] border border-tg-border overflow-hidden shadow-sm group hover:border-blue-500/30 transition-all"
            >
              <div className="p-5 space-y-4">
                <div className="flex justify-between items-start">
                  <div className="flex gap-3">
                    <div className="w-12 h-12 bg-black/5 dark:bg-white/5 rounded-2xl flex items-center justify-center text-blue-500 border border-tg-border">
                      {item.type === 'video' ? <Video size={24} /> : <ImageIcon size={24} />}
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-tg-text">{item.title}</h4>
                      <p className="text-[10px] text-tg-text-muted font-bold uppercase tracking-tighter">آماده انتشار</p>
                    </div>
                  </div>
                  <span className="text-[8px] font-black px-2.5 py-1 bg-emerald-500/10 text-emerald-500 rounded-xl uppercase tracking-widest">
                    تایید شده
                  </span>
                </div>

                <div className="p-3 bg-black/5 dark:bg-white/5 rounded-2xl border border-tg-border">
                  <p className="text-[10px] leading-relaxed text-tg-text-muted line-clamp-3">{item.content}</p>
                </div>

                <div className="flex gap-2">
                  <button className="flex-1 flex items-center justify-center gap-2 py-3 bg-blue-500 text-white rounded-xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all">
                    <Send size={14} />
                    بله
                  </button>
                  <button className="flex-1 flex items-center justify-center gap-2 py-3 bg-gradient-to-tr from-amber-500 to-fuchsia-500 text-white rounded-xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all">
                    <Instagram size={14} />
                    اینستاگرام
                  </button>
                  <button className="flex-1 flex items-center justify-center gap-2 py-3 bg-tg-text text-tg-bg rounded-xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all">
                    <Twitter size={14} />
                    توییتر
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="py-20 text-center opacity-30">
            <Share2 size={48} className="mx-auto mb-4" />
            <p className="text-xs font-black text-tg-text">محتوایی برای انتشار موجود نیست</p>
          </div>
        )}
      </div>
    </div>
  );
};

const StudioScreen = ({ integrations, setToast, user, gordanContent, onShare }: { integrations: any, setToast: (t: any) => void, user: UserProfile, gordanContent: GordanContent[], onShare: (i: any) => void }) => {
  const [topic, setTopic] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'create' | 'publishing' | 'analytics'>('create');
  const [contentType, setContentType] = useState<'tweet' | 'poster' | 'video'>('tweet');

  const handleGenerate = async () => {
    if (!topic) return;
    setLoading(true);
    // AI Disabled as per Commander's Directive
    setTimeout(() => {
      const newResult = { 
        text: `پیش‌نویس محتوا برای موضوع: ${topic}\n\nدر بازه زمانی معاصر، تبیین دقیق این موضوع از اهمیت راهبردی برخوردار است. بر اساس داده‌های موجود در پایگاه مرکزی، تمرکز بر نقاط قوت بومی و استفاده از لحن اقناعی توصیه می‌شود.`, 
        hashtags: [topic.replace(/\s/g, '_'), 'واحد_تبیین'],
        type: contentType,
        timestamp: 'الان'
      };
      setResults(prev => [...prev, newResult]);
      setLoading(false);
    }, 2000);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] bg-tg-bg transition-colors">
      {/* Sub-tabs */}
      <div className="flex bg-tg-surface border-b border-tg-border sticky top-0 z-10">
        <button 
          onClick={() => setActiveSubTab('create')}
          className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 ${
            activeSubTab === 'create' ? 'border-tg-accent text-tg-accent' : 'border-transparent text-tg-text-muted'
          }`}
        >
          واحد تولید محتوا
        </button>
        <button 
          onClick={() => setActiveSubTab('publishing')}
          className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 ${
            activeSubTab === 'publishing' ? 'border-tg-accent text-tg-accent' : 'border-transparent text-tg-text-muted'
          }`}
        >
          ابلاغیه‌ها
        </button>
        <button 
          onClick={() => setActiveSubTab('analytics')}
          className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 ${
            activeSubTab === 'analytics' ? 'border-tg-accent text-tg-accent' : 'border-transparent text-tg-text-muted'
          }`}
        >
          پایش و بهره‌برداری
        </button>
      </div>

      {activeSubTab === 'create' ? (
        <div className="flex flex-col h-full bg-tg-bg">
          <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
            <div className="bubble bubble-in">
              سلام! واحد تولید محتوا (استودیو) در خدمت شماست. نوع محتوا را انتخاب کنید و موضوع را بفرستید تا سامانه برای شما پیش‌نویس آماده کند.
            </div>

            {results.length === 0 && !loading && (
              <div className="bg-tg-surface p-4 rounded-2xl border border-tg-border space-y-3">
                <h4 className="text-xs font-black text-tg-accent flex items-center gap-2">
                  <Info size={14} />
                  نکات آموزشی تولید محتوا
                </h4>
                <ul className="space-y-2">
                  <li className="text-[10px] text-tg-text-muted flex items-start gap-2">
                    <div className="w-1 h-1 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                    <span>از کلمات کلیدی مرتبط با موضوع تبیین استفاده کنید.</span>
                  </li>
                  <li className="text-[10px] text-tg-text-muted flex items-start gap-2">
                    <div className="w-1 h-1 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                    <span>لحن محتوا باید محترمانه، مستدل و اقناع‌کننده باشد.</span>
                  </li>
                  <li className="text-[10px] text-tg-text-muted flex items-start gap-2">
                    <div className="w-1 h-1 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                    <span>هشتگ‌های پربازدید و مرتبط را فراموش نکنید.</span>
                  </li>
                </ul>
              </div>
            )}

            <div className="flex gap-2 mb-2">
              {[
                { id: 'tweet', label: 'توییت', icon: Twitter },
                { id: 'poster', label: 'پوستر', icon: ImageIcon },
              ].map(type => (
                <button
                  key={type.id}
                  onClick={() => setContentType(type.id as any)}
                  className={`flex-1 flex flex-col items-center gap-1 p-2 rounded-xl border transition-all ${
                    contentType === type.id 
                    ? 'bg-blue-50 border-blue-200 text-tg-accent dark:bg-blue-900/20 dark:border-blue-800' 
                    : 'bg-tg-surface border-tg-border text-tg-text-muted'
                  }`}
                >
                  <type.icon size={16} />
                  <span className="text-[10px] font-bold">{type.label}</span>
                </button>
              ))}
            </div>

            {results.map((res, idx) => (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                key={idx}
                className="bubble bubble-out space-y-2"
              >
                <div className="flex items-center gap-2 mb-1 opacity-60">
                  {res.type === 'tweet' ? <Twitter size={12} /> : <ImageIcon size={12} />}
                  <span className="text-[10px] font-bold">سناریو پیشنهادی {res.type === 'tweet' ? 'توییتر' : 'پوستر'}</span>
                </div>
                <p className="leading-relaxed whitespace-pre-line text-xs">{res.text}</p>
                <div className="flex flex-wrap gap-1">
                  {res.hashtags.map((tag: string, i: number) => (
                    <span key={i} className="text-[10px] text-tg-accent font-medium">#{tag}</span>
                  ))}
                </div>
                <div className="flex justify-end gap-2 pt-1">
                  <button className="p-1 hover:bg-black/5 rounded text-tg-accent" title="کپی متن"><Copy size={14} /></button>
                  <button 
                    onClick={() => {
                      const newItem: ContentItem = {
                        id: Date.now().toString(),
                        type: res.type as any,
                        title: `محتوای تولیدی ${res.type}`,
                        content: res.text,
                        hashtags: res.hashtags,
                        isPublished: false,
                        downloadCount: 0
                      };
                      // In a real app we'd update state here
                      alert('به بانک محتوا اضافه شد');
                    }}
                    className="p-1 hover:bg-black/5 rounded text-emerald-500" 
                    title="ذخیره در بانک محتوا"
                  >
                    <Bookmark size={14} />
                  </button>
                  <button 
                    onClick={() => onShare({ title: `محتوای تولیدی ${res.type}`, content: res.text, hashtags: res.hashtags } as any)}
                    className="p-1 hover:bg-black/5 rounded text-tg-accent active:scale-90 transition-all" 
                    title="اشتراک‌گذاری"
                  >
                    <Share2 size={14} />
                  </button>
                </div>
              </motion.div>
            ))}

            {loading && (
              <div className="bubble bubble-in animate-pulse flex items-center gap-2">
                <Zap size={14} className="text-tg-accent animate-bounce" />
                <span>در حال استخراج و تدوین محتوا از پایگاه داده...</span>
              </div>
            )}
          </div>

          <div className="p-3 bg-tg-surface border-t border-tg-border flex gap-2 items-center">
            <input
              type="text"
              value={topic}
              onChange={e => setTopic(e.target.value)}
              onKeyPress={e => e.key === 'Enter' && handleGenerate()}
              placeholder={`موضوع ${contentType === 'tweet' ? 'توییت' : 'پوستر'}...`}
              className="flex-1 bg-transparent border-none outline-none text-sm text-tg-text"
            />
            <button 
              onClick={handleGenerate}
              disabled={loading || !topic}
              className="text-tg-accent p-2 active:scale-90 transition-all disabled:opacity-30"
            >
              <Send size={24} className="rotate-180" />
            </button>
          </div>
        </div>
      ) : activeSubTab === 'publishing' ? (
        <PublishingScreen content={gordanContent} user={user} />
      ) : (
        <div className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar bg-tg-bg">
          <div className="grid grid-cols-2 gap-4">
            <StatCard icon={Activity} label="ضریب نفوذ" value="۸۴٪" color="text-blue-500" />
            <StatCard icon={CheckCircle2} label="محتوای منتشر شده" value="۱,۴۲۰" color="text-emerald-500" />
            <StatCard icon={MessageSquare} label="گزارش‌های رصد" value="۳۴۲" color="text-orange-500" />
            <StatCard icon={Eye} label="مجموع بازدید" value="۲.۴M" color="text-purple-500" />
          </div>

          <div className="bg-tg-surface rounded-2xl border border-tg-border p-4 space-y-4 shadow-sm transition-colors">
            <h3 className="font-bold text-sm flex items-center gap-2 text-tg-text">
              <BarChart3 size={18} className="text-tg-accent" />
              روند بهره‌برداری پروژه
            </h3>
            <div className="h-32 flex items-end gap-2 px-2">
              {[40, 70, 45, 90, 65, 80, 95].map((h, i) => (
                <div key={i} className="flex-1 bg-black/5 dark:bg-white/5 rounded-t-lg relative group">
                  <motion.div 
                    initial={{ height: 0 }}
                    animate={{ height: `${h}%` }}
                    className="absolute bottom-0 left-0 right-0 bg-tg-accent rounded-t-lg shadow-[0_0_15px_rgba(59,130,246,0.3)]"
                  />
                </div>
              ))}
            </div>
            <div className="flex justify-between text-[10px] text-tg-text-muted font-bold">
              <span>شنبه</span>
              <span>دوشنبه</span>
              <span>چهارشنبه</span>
              <span>جمعه</span>
            </div>
          </div>

          <div className="bg-tg-surface rounded-2xl border border-tg-border p-4 shadow-sm transition-colors">
            <h3 className="font-bold text-sm mb-3 text-tg-text">ترندهای تحت کنترل</h3>
            <div className="space-y-2">
              {['#ایران_قوی', '#پیشرفت_هسته‌ای', '#مقاومت_سایبری'].map((tag, i) => (
                <div key={i} className="flex justify-between items-center p-3 bg-black/5 dark:bg-white/5 rounded-xl border border-tg-border transition-colors">
                  <span className="text-xs font-bold text-tg-accent">{tag}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-emerald-500 font-black">۸۵٪ مثبت</span>
                    <div className="w-12 h-1 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div className="w-[85%] h-full bg-emerald-500" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const TrackingScreen = ({ accounts, observations, user }: { accounts: TrackedAccount[], observations: Observation[], user: UserProfile }) => {
  const [showReportForm, setShowReportForm] = useState(false);
  const [reportData, setReportData] = useState({
    platform: 'instagram' as 'instagram' | 'bale' | 'twitter' | 'other',
    handle: '',
    fakeContentTitle: '',
    screenshots: ['', '', '']
  });
  const [activeTab, setActiveTab] = useState<'accounts' | 'reports'>('accounts');

  const handleSubmit = () => {
    console.log('Observation reported:', reportData);
    setShowReportForm(false);
    setReportData({ platform: 'instagram', handle: '', fakeContentTitle: '', screenshots: ['', '', ''] });
  };

  return (
    <div className="p-4 space-y-6 pb-24">
      <div className="flex justify-between items-center px-2">
        <h2 className="text-xl font-black">واحد رصد و پایش</h2>
        <button 
          onClick={() => setShowReportForm(true)}
          className="p-3 bg-tg-accent text-white rounded-2xl shadow-xl active:scale-95 transition-all flex items-center gap-2"
        >
          <Plus size={20} />
          <span className="text-xs font-black">ثبت گزارش رصد</span>
        </button>
      </div>

      <div className="flex bg-black/5 dark:bg-white/5 p-1 rounded-2xl border border-tg-border">
        <button 
          onClick={() => setActiveTab('accounts')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-black transition-all ${activeTab === 'accounts' ? 'bg-tg-surface shadow-sm border border-tg-border' : 'text-tg-text-muted'}`}
        >
          حساب‌های تحت نظر
        </button>
        <button 
          onClick={() => setActiveTab('reports')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-black transition-all ${activeTab === 'reports' ? 'bg-tg-surface shadow-sm border border-tg-border' : 'text-tg-text-muted'}`}
        >
          گزارش‌های مردمی
        </button>
      </div>

      {activeTab === 'accounts' ? (
        <div className="space-y-4">
          {accounts.map(acc => (
            <div key={acc.id} className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex items-center gap-4 transition-colors shadow-sm">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                acc.platform === 'twitter' ? 'bg-blue-50 text-blue-500' : 
                acc.platform === 'instagram' ? 'bg-pink-50 text-pink-500' : 'bg-sky-50 text-sky-500'
              }`}>
                {acc.platform === 'twitter' ? <Twitter size={24} /> : acc.platform === 'instagram' ? <Instagram size={24} /> : <MessageSquare size={24} />}
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-black">{acc.name}</h3>
                <p className="text-[10px] text-slate-500 font-bold" dir="ltr">{acc.handle}</p>
              </div>
              <div className="text-right">
                <span className={`text-[8px] font-black px-2 py-0.5 rounded-full ${
                  acc.category === 'enemy' ? 'bg-red-100 text-red-600' : 
                  acc.category === 'friendly' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-600'
                }`}>
                  {acc.category === 'enemy' ? 'معاند' : acc.category === 'friendly' ? 'همسو' : 'خنثی'}
                </span>
                <p className="text-[8px] text-slate-400 mt-1">فعالیت: {new Date(acc.lastActivity).toLocaleDateString('fa-IR')}</p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {observations.map(obs => (
            <div key={obs.id} className="bg-tg-surface p-4 rounded-3xl border border-tg-border space-y-3 transition-colors shadow-sm">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-pink-50 dark:bg-pink-900/20 text-pink-500 flex items-center justify-center">
                    <Instagram size={20} />
                  </div>
                  <div>
                    <h3 className="text-xs font-black">{obs.fakeContentTitle}</h3>
                    <p className="text-[10px] text-slate-500 font-bold" dir="ltr">{obs.instagramPage}</p>
                  </div>
                </div>
                <span className={`text-[8px] font-black px-2 py-0.5 rounded-full ${
                  obs.status === 'pending' ? 'bg-amber-100 text-amber-600' : 
                  obs.status === 'reviewed' ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'
                }`}>
                  {obs.status === 'pending' ? 'در حال بررسی' : obs.status === 'reviewed' ? 'تایید شده' : 'رد شده'}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {obs.screenshots.map((s, i) => (
                  <div key={i} className="aspect-square rounded-xl bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <img src={s || `https://picsum.photos/seed/${obs.id}-${i}/200/200`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <BottomSheet isOpen={showReportForm} onClose={() => setShowReportForm(false)} title="ثبت گزارش رصد جدید">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase px-1">پلتفرم مورد نظر</label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { id: 'instagram', icon: Instagram, label: 'اینستاگرام' },
                  { id: 'bale', icon: MessageSquare, label: 'بله' },
                  { id: 'twitter', icon: Twitter, label: 'توییتر' },
                  { id: 'other', icon: Shield, label: 'سایر' }
                ].map(p => (
                  <button 
                    key={p.id}
                    onClick={() => setReportData({...reportData, platform: p.id as any})}
                    className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl border-2 transition-all ${
                      reportData.platform === p.id 
                      ? 'border-[#2481cc] bg-blue-50 dark:bg-blue-900/20 text-[#2481cc]' 
                      : 'border-slate-100 dark:border-slate-800 text-slate-400'
                    }`}
                  >
                    <p.icon size={20} />
                    <span className="text-[8px] font-black">{p.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase px-1">آدرس صفحه / آیدی (Handle)</label>
              <input 
                value={reportData.handle}
                onChange={e => setReportData({...reportData, handle: e.target.value})}
                placeholder="@username or link"
                className="tg-input ltr"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase px-1">عنوان محتوای معاند/جعلی</label>
              <input 
                value={reportData.fakeContentTitle}
                onChange={e => setReportData({...reportData, fakeContentTitle: e.target.value})}
                placeholder="مثلا: شایعه پراکنی در مورد..."
                className="tg-input"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase px-1">بارگذاری مستندات (۳ اسکرین‌شات)</label>
              <div className="grid grid-cols-3 gap-3">
                {[0, 1, 2].map(i => (
                  <button key={i} className="aspect-square rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center gap-1 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <Camera size={20} className="text-slate-400" />
                    <span className="text-[8px] font-black text-slate-400">تصویر {i+1}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
          <button 
            onClick={handleSubmit}
            className="w-full py-4 bg-tg-accent text-white rounded-2xl font-black text-sm shadow-lg shadow-tg-accent/20 active:scale-95 transition-all"
          >
            ارسال گزارش به مرکز پایش
          </button>
        </div>
      </BottomSheet>
    </div>
  );
};

const EducationScreen = ({ items }: { items: EducationItem[] }) => {
  const [selectedCourse, setSelectedCourse] = useState<EducationItem | null>(null);
  const [activeSession, setActiveSession] = useState<EducationSession | null>(null);

  if (selectedCourse) {
    return (
      <div className="flex flex-col min-h-screen bg-tg-bg transition-colors">
        <div className="sticky top-0 z-20 bg-tg-surface/80 backdrop-blur-xl border-b border-tg-border px-6 py-4 flex items-center gap-4 transition-colors">
          <button onClick={() => { setSelectedCourse(null); setActiveSession(null); }} className="p-2 text-blue-500 hover:bg-blue-500/10 rounded-xl transition-all">
            <ArrowRight size={24} />
          </button>
          <div className="space-y-0.5">
            <h3 className="font-black text-sm">{selectedCourse.title}</h3>
            <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">برنامه آموزشی و دکترین</p>
          </div>
        </div>

        <div className="flex-1 p-6 space-y-8 max-w-4xl mx-auto w-full">
          {activeSession ? (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="bg-tg-surface p-6 rounded-[2.5rem] border border-tg-border space-y-6 shadow-2xl transition-colors">
                <div className="flex justify-between items-center">
                  <h4 className="text-sm font-black text-blue-500">{activeSession.title}</h4>
                  <span className="text-[8px] font-black px-2 py-1 bg-blue-500/10 text-blue-500 rounded-lg uppercase tracking-widest border border-blue-500/20">
                    {activeSession.type}
                  </span>
                </div>

                <div className="rounded-2xl overflow-hidden border border-tg-border bg-black/5 dark:bg-black/20 max-h-[60vh] flex items-center justify-center transition-all">
                  {activeSession.type === 'video' && (
                    <video src={activeSession.content} controls className="w-full max-h-full" />
                  )}
                  {activeSession.type === 'audio' && (
                    <div className="p-8 flex flex-col items-center gap-6 w-full">
                      <div className="w-20 h-20 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-500 border border-blue-500/20 transition-all">
                        <Volume2 size={40} />
                      </div>
                      <audio src={activeSession.content} controls className="w-full" />
                    </div>
                  )}
                  {activeSession.type === 'text' && (
                    <div className="p-6 prose prose-slate dark:prose-invert max-w-none overflow-y-auto w-full transition-all">
                      <p className="text-xs leading-relaxed font-medium text-tg-text-muted">{activeSession.content}</p>
                    </div>
                  )}
                  {activeSession.type === 'html' && (
                    <iframe srcDoc={activeSession.content} className="w-full h-[500px] border-0 bg-white rounded-xl" />
                  )}
                </div>
              </div>
              <button 
                onClick={() => setActiveSession(null)}
                className="w-full py-4 bg-black/5 dark:bg-white/5 border border-tg-border hover:bg-tg-border text-tg-text-muted rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all"
              >
                بازگشت به برنامه
              </button>
            </motion.div>
          ) : (
            <div className="space-y-8">
              <motion.div 
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative aspect-video rounded-[3rem] overflow-hidden border border-tg-border shadow-2xl max-w-2xl mx-auto transition-colors"
              >
                <img src={selectedCourse.coverImage} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-app-bg via-transparent to-transparent transition-colors" />
                <div className="absolute bottom-6 left-6 right-6">
                  <p className="text-xs text-tg-text font-medium leading-relaxed line-clamp-2">{selectedCourse.description}</p>
                </div>
              </motion.div>
              
              <div className="space-y-4">
                <div className="flex items-center gap-2 px-2">
                  <List size={16} className="text-blue-500" />
                  <h4 className="text-[10px] font-black text-tg-text-muted uppercase tracking-widest">برنامه آموزشی</h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {selectedCourse.sessions?.map((session, idx) => (
                    <motion.button 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      key={session.id}
                      onClick={() => setActiveSession(session)}
                      className="w-full bg-tg-surface p-5 rounded-3xl border border-tg-border flex items-center gap-4 hover:border-blue-500/30 transition-all group shadow-sm"
                    >
                      <div className="w-10 h-10 bg-black/5 dark:bg-slate-800 rounded-xl flex items-center justify-center text-tg-text-muted font-black text-xs border border-tg-border group-hover:border-blue-500/50 transition-all">
                        {idx + 1}
                      </div>
                      <div className="flex-1 text-right">
                        <h5 className="text-xs font-black group-hover:text-blue-500 transition-colors text-tg-text">{session.title}</h5>
                        <p className="text-[8px] text-tg-text-muted font-black uppercase tracking-widest mt-0.5">{session.type}</p>
                      </div>
                      <div className="text-tg-text-muted group-hover:text-blue-500 transition-all">
                        {session.type === 'video' ? <Video size={18} /> : session.type === 'audio' ? <Volume2 size={18} /> : <FileText size={18} />}
                      </div>
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 pb-32 bg-app-bg min-h-screen transition-colors">
      <div className="space-y-1 px-1">
        <h2 className="text-xl font-black text-tg-text">واحد آموزش و دکترین</h2>
        <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-tighter">Academy & Doctrine Command</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((item, idx) => (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            key={item.id} 
            className="bg-tg-surface rounded-[2.5rem] border border-tg-border overflow-hidden group hover:border-blue-500/30 transition-all shadow-2xl shadow-black/20"
          >
            <div className="relative aspect-video overflow-hidden">
              <img src={item.coverImage} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-tg-surface via-transparent to-transparent opacity-60" />
              <div className="absolute top-4 right-4 bg-black/60 border border-white/10 text-white text-[8px] px-3 py-1.5 rounded-xl font-black uppercase tracking-widest flex items-center gap-2">
                <BookOpen size={12} />
                {item.sessions?.length || 0} جلسه
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <h3 className="text-base font-black group-hover:text-blue-500 transition-colors text-tg-text">{item.title}</h3>
                <p className="text-xs text-tg-text-muted font-medium mt-2 leading-relaxed line-clamp-2">{item.description}</p>
              </div>
              <button 
                onClick={() => setSelectedCourse(item)}
                className="w-full py-4 bg-blue-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Play size={16} fill="currentColor" />
                شروع آموزش
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const SavedScreen = ({ chats, contentLibrary, onShare }: { chats: Chat[], contentLibrary: ContentItem[], onShare: (i: ContentItem) => void }) => {
  const markedMessages = chats.flatMap(c => (c.messages || []).filter(m => m.isMarked).map(m => ({ ...m, chatName: c.name })));
  const markedContent = contentLibrary.filter(c => c.isMarked);

  if (markedMessages.length === 0 && markedContent.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-120px)] p-10 text-center space-y-4">
        <div className="w-24 h-24 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-500 border border-blue-500/20">
          <Bookmark size={48} />
        </div>
        <h2 className="font-bold text-lg text-tg-text">موردی ذخیره نشده است</h2>
        <p className="text-sm text-tg-text-muted leading-relaxed">
          گزارش‌ها، پیام‌ها و محتواهای نشان شده را می‌توانید اینجا مشاهده کنید.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 pb-32 bg-app-bg min-h-screen transition-colors">
      {markedMessages.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 px-2">
            <MessageSquare size={18} className="text-blue-500" />
            <h3 className="text-sm font-black uppercase tracking-widest text-tg-text">پیام‌های نشان شده</h3>
          </div>
          <div className="space-y-3">
            {markedMessages.map((m, i) => (
              <div key={i} className="bg-tg-surface p-4 rounded-3xl border border-tg-border space-y-2 shadow-sm transition-colors">
                <div className="flex justify-between items-center">
                  <span className="text-[8px] font-black text-blue-500 uppercase tracking-widest">{m.chatName}</span>
                  <span className="text-[8px] text-tg-text-muted font-mono">{m.time}</span>
                </div>
                <p className="text-xs font-medium leading-relaxed text-tg-text">{m.text}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {markedContent.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 px-2">
            <Layout size={18} className="text-emerald-500" />
            <h3 className="text-sm font-black uppercase tracking-widest text-tg-text">محتواهای نشان شده</h3>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {markedContent.map((item, i) => (
              <div key={i} className="bg-tg-surface p-4 rounded-3xl border border-tg-border flex gap-4 shadow-sm transition-colors">
                <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0">
                  <img src={item.imageUrl || `https://picsum.photos/seed/${item.id}/200/200`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex justify-between items-start">
                    <h5 className="text-[11px] font-black text-tg-text">{item.title}</h5>
                    <button 
                      onClick={() => onShare(item)}
                      className="text-tg-text-muted hover:text-blue-500 transition-colors p-1"
                    >
                      <Share2 size={12} />
                    </button>
                  </div>
                  <p className="text-[10px] text-tg-text-muted line-clamp-2">{item.content}</p>
                  <div className="flex gap-1 pt-1">
                    {item.hashtags.slice(0, 2).map((tag, j) => (
                      <span key={j} className="text-[8px] text-blue-500">#{tag}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const NotificationsPanel = ({ isOpen, onClose, notifications, onMarkAllRead }: { isOpen: boolean, onClose: () => void, notifications: any[], onMarkAllRead: () => void }) => (
  <BottomSheet isOpen={isOpen} onClose={onClose} title="اعلان‌های عملیاتی">
    <div className="space-y-1 max-h-[60vh] overflow-y-auto no-scrollbar">
      {notifications.length > 0 ? (
        notifications.map((n, i) => (
          <div key={i} className={`p-4 rounded-[1.5rem] transition-all flex gap-4 items-start border ${
            !n.read ? 'bg-blue-500/5 border-blue-500/10' : 'opacity-60 border-transparent'
          }`}>
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-sm border ${
              n.type === 'urgent' ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-blue-500/10 text-blue-500 border-blue-500/20'
            }`}>
              {n.type === 'urgent' ? <AlertCircle size={24} /> : <Bell size={24} />}
            </div>
            <div className="flex-1 space-y-1.5">
              <div className="flex justify-between items-start gap-2">
                <p className="text-xs font-black leading-tight text-tg-text">{n.title}</p>
                {!n.read && <div className="w-2 h-2 bg-blue-500 rounded-full shrink-0 mt-1" />}
              </div>
              <p className="text-[10px] text-tg-text-muted font-bold uppercase tracking-tighter">{n.time}</p>
            </div>
          </div>
        ))
      ) : (
        <div className="p-12 text-center text-tg-text-muted opacity-50">
          <Bell size={48} className="mx-auto mb-4" />
          <p className="text-sm font-black">اعلانی موجود نیست</p>
        </div>
      )}
    </div>
    <div className="pt-4 mt-2 border-t border-tg-border flex gap-2">
      <button 
        onClick={onMarkAllRead}
        className="flex-1 py-4 bg-blue-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
      >
        تایید همه اعلان‌ها
      </button>
      <button 
        onClick={onClose}
        className="flex-1 py-4 bg-black/5 dark:bg-white/5 border border-tg-border text-tg-text-muted rounded-2xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all"
      >
        بستن
      </button>
    </div>
  </BottomSheet>
);

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    if (saved) return saved === 'dark';
    return true; // Default to dark
  });

  useEffect(() => {
    const theme = darkMode ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [darkMode]);

  const [activeTab, setActiveTab] = useState<'home' | 'missions' | 'messenger' | 'profile' | 'info' | 'saved' | 'security' | 'admin' | 'calendar'>('home');
  const [activeSubTab, setActiveSubTab] = useState<string>('overview');
  const [activeUnit, setActiveUnit] = useState<'main' | 'monitor' | 'studio' | 'tutorial' | 'explore'>('main');

  // Whitelist & Scoring Logic check
  useEffect(() => {
    if (!user) return;
    if (user.points >= 5000 && !user.isWhitelisted) {
      const updatedUsers = users.map(u => 
        u.uid === user.uid ? { ...u, isWhitelisted: true } : u
      );
      setUsers(updatedUsers);
      updateDb('auth.users', updatedUsers);
    }
  }, [user?.points]);
  const [viewingImage, setViewingImage] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [integrations, setIntegrations] = useState({
    bale: { enabled: true, status: 'connected' },
    twitter: { enabled: false, status: 'disconnected' },
    instagram: { enabled: true, status: 'connected' },
    aiGlobal: false
  });
  const [botConfig, setBotConfig] = useState<BotConfig>({
    token: 'BALE_BOT_TOKEN_PLACEHOLDER',
    welcomeMessage: 'سلام کاربر گرامی، به سامانه مدیریت محتوا خوش آمدید.',
    notificationsEnabled: true,
    autoReplyEnabled: false,
    adminChatId: '123456789'
  });
  const [notifications, setNotifications] = useState([
    { id: 1, title: 'ماموریت جدید ابلاغ شد: تبیین دستاوردهای فضایی', time: '۵ دقیقه پیش', type: 'urgent', read: false },
    { id: 2, title: 'گزارش رصد جدید در واحد مانیتورینگ', time: '۱ ساعت پیش', type: 'info', read: false },
    { id: 3, title: 'بروزرسانی دکترین عملیات سایبری', time: '۳ ساعت پیش', type: 'info', read: true },
  ]);
  const [showNotifications, setShowNotifications] = useState(false);
  const unreadNotifications = notifications.filter(n => !n.read).length;

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  const notifyBale = async (text: string, chatId?: string) => {
    try {
      await fetch('/api/notifications/bale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, chatId })
      });
    } catch (err) {
      console.error('Bale notification failed:', err);
    }
  };

  const updateDb = async (path: string, value: any) => {
    try {
      const res = await fetch('/api/data/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path, value })
      });
      if (res.ok) {
        setToast({ message: 'تغییرات با موفقیت ذخیره شد', type: 'success' });
      } else {
        setToast({ message: 'خطا در ذخیره‌سازی اطلاعات', type: 'error' });
      }
    } catch (err) {
      setToast({ message: 'ارتباط با سرور برقرار نشد', type: 'error' });
    }
  };

  const [showAddUser, setShowAddUser] = useState(false);
  const [newUser, setNewUser] = useState({ name: '', phone: '', password: '', role: 'user' as any, unitId: '', departments: [] as BattalionType[] });
  const [showAddMission, setShowAddMission] = useState(false);
  const [newMission, setNewMission] = useState({ 
    title: '', 
    description: '', 
    type: 'daily' as any, 
    difficulty: 'medium' as any,
    category: 'social' as any,
    reward: '',
    educationId: '',
    isArchived: false,
    priority: 'medium' as any,
    sendBaleAlert: true
  });
  const [showAddTask, setShowAddTask] = useState<{ missionId: string } | null>(null);
  const [newTask, setNewTask] = useState({ 
    title: '', 
    platform: 'twitter' as any, 
    points: 50, 
    department: '' as BattalionType | '',
    targetLink: '',
    contentCaption: '',
    contentBody: '',
    steps: [] as string[],
    isNasra: false,
    nasraType: 'webinar' as any,
    nasraUrl: '',
    contentImage: ''
  });

  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [showAddAnnouncement, setShowAddAnnouncement] = useState(false);
  const [newAnnouncement, setNewAnnouncement] = useState({ title: '', content: '', type: 'info' as any, isPublic: true });
  const [missions, setMissions] = useState<Mission[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [contentLibrary, setContentLibrary] = useState<ContentItem[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [chats, setChats] = useState<Chat[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [taskCompletions, setTaskCompletions] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [trackedAccounts, setTrackedAccounts] = useState<TrackedAccount[]>([]);
  const [organizationalUnits, setOrganizationalUnits] = useState<OrganizationalUnit[]>([]);
  const [newUnit, setNewUnit] = useState({ name: '', level: 'howze' as UnitLevel, parentId: '' });
  const [gordanContent, setGordanContent] = useState<GordanContent[]>([]);
  const [observations, setObservations] = useState<Observation[]>([]);
  const [educationItems, setEducationItems] = useState<EducationItem[]>([]);
  const [dailyPlans, setDailyPlans] = useState<CalendarEvent[]>([
    { id: '1', title: 'تمرین عملیات روانی', type: 'training', time: '۰۸:۰۰', date: new Date().toISOString().split('T')[0], description: 'آموزش تکنیک‌های نوین اقناع در فضای مجازی', location: 'قرارگاه مرکزی' },
    { id: '2', title: 'رزمایش پدافند سایبری', type: 'mission', time: '۱۰:۰۰', date: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0], description: 'پاسخ هماهنگ به حملات توزیع شده', location: 'بستر شبکه' }
  ]);
  const [showCalendarTutorial, setShowCalendarTutorial] = useState(false);
  const [showCalendarAddEvent, setShowCalendarAddEvent] = useState<{date: string} | null>(null);
  const [newEvent, setNewEvent] = useState({ title: '', description: '', type: 'operation' as any, time: '10:00' });

  const handleAddEvent = async () => {
    if (!newEvent.title || !showCalendarAddEvent) return;
    
    const event: CalendarEvent = {
      id: Date.now().toString(),
      title: newEvent.title,
      description: newEvent.description,
      type: newEvent.type,
      date: new Date(showCalendarAddEvent.date).toISOString(),
      time: newEvent.time,
    };

    const updatedPlans = [...dailyPlans, event];
    setDailyPlans(updatedPlans);
    setToast({ message: 'رویداد با موفقیت به تقویم اضافه شد', type: 'success' });
    setShowCalendarAddEvent(null);
    setNewEvent({ title: '', description: '', type: 'operation', time: '10:00' });

    try {
      await updateDb('calendar.events', updatedPlans);
    } catch (err) {
      console.error(err);
      setToast({ message: 'خطا در ذخیره رویداد', type: 'error' });
    }
  };

  const handleAddCalendarEvent = handleAddEvent;

  const handleAddMission = async () => {
    if (!newMission.title) return;
    const mission: Mission = {
      ...newMission,
      id: `m-${Date.now()}`,
      isCompleted: false,
      isArchived: false,
      createdAt: new Date().toISOString(),
      educationId: newMission.educationId || undefined
    };
    const updatedMissions = [...missions, mission];
    setMissions(updatedMissions);
    await updateDb('operations.missions', updatedMissions);

    if (mission.sendBaleAlert) {
      const priorityEmoji = mission.priority === 'critical' ? '🚨' : mission.priority === 'high' ? '⚠️' : '📢';
      const typeLabel = mission.type === 'urgent' ? 'فوری' : mission.type === 'special' ? 'ویژه' : 'روزانه';
      notifyBale(`${priorityEmoji} مأموریت ${typeLabel} ابلاغ شد:\n🚀 ${mission.title}\n📝 ${mission.description}\n💎 پاداش: ${mission.reward}`);
    }

    setShowAddMission(false);
    setNewMission({ 
      title: '', 
      description: '', 
      type: 'daily', 
      difficulty: 'medium',
      category: 'social',
      reward: '',
      educationId: '',
      isArchived: false,
      priority: 'medium',
      sendBaleAlert: true
    });
  };

  const handleSendAnnouncement = async () => {
    if (!newAnnouncement.title || !newAnnouncement.content) return;
    const ann: Announcement = {
      ...newAnnouncement,
      id: `a-${Date.now()}`,
      sender: user?.name || 'مدیریت',
      timestamp: new Date().toISOString()
    };
    const updated = [ann, ...announcements];
    setAnnouncements(updated);
    await updateDb('operations.announcements', updated);

    const typeLabel = ann.type === 'critical' ? '🔴 فوری' : ann.type === 'warning' ? '🟡 هشدار' : '🔵 اطلاع‌رسانی';
    notifyBale(`${typeLabel}\n📌 ${ann.title}\n\n${ann.content}`);

    setShowAddAnnouncement(false);
    setNewAnnouncement({ title: '', content: '', type: 'info', isPublic: true });
    setToast({ message: 'اطلاعیه با موفقیت ارسال شد', type: 'success' });
  };

  const handleDeleteMission = async (id: string) => {
    const updatedMissions = missions.filter(m => m.id !== id);
    const updatedTasks = tasks.filter(t => t.missionId !== id);
    setMissions(updatedMissions);
    setTasks(updatedTasks);
    await updateDb('operations.missions', updatedMissions);
    await updateDb('operations.tasks', updatedTasks);
  };

  const handleAddTask = async () => {
    if (!showAddTask || !newTask.title) return;
    const task: Task = {
      id: `t-${Date.now()}`,
      missionId: showAddTask.missionId,
      title: newTask.title,
      status: 'pending' as any,
      points: typeof newTask.points === 'string' ? parseInt(newTask.points) : newTask.points,
      platform: newTask.platform,
      department: newTask.department || undefined,
      deadline: (newTask as any).deadline || '24:00',
      assignedTo: (newTask as any).assignedTo || undefined,
      steps: newTask.steps.length > 0 ? newTask.steps : undefined,
      createdAt: new Date().toISOString(),
      educationId: newTask.educationId || undefined,
      contentCaption: newTask.contentCaption || undefined,
      contentBody: newTask.contentBody || undefined,
      contentImage: newTask.contentImage || undefined,
      isNasra: newTask.isNasra,
      nasraType: newTask.nasraType,
      nasraUrl: newTask.nasraUrl
    };
    const updatedTasks = [...tasks, task];
    setTasks(updatedTasks);
    await updateDb('operations.tasks', updatedTasks);

    if (task.assignedTo) {
      const targetUser = users.find(u => u.uid === task.assignedTo);
      if (targetUser?.baleNotificationsEnabled && targetUser?.baleId) {
        notifyBale(`🎯 مأموریت اختصاصی جدید:\n📌 ${task.title}\n⏳ مهلت زمان: ${(task as any).deadline || '24:00'}\n💎 امتیاز: ${task.points}`, targetUser.baleId);
      }
    }

    setShowAddTask(null);
    setNewTask({ 
      title: '', 
      platform: 'twitter', 
      points: 50, 
      department: '',
      targetLink: '',
      contentCaption: '',
      contentBody: '',
      steps: [],
      isNasra: false,
      nasraType: 'webinar',
      nasraUrl: '',
      contentImage: ''
    });
    setToast({ message: 'وظیفه جدید با موفقیت ابلاغ شد', type: 'success' });
  };

  useEffect(() => {
    // Popup logic now explicitly triggered by user action or manual help, not automatic on entry
    /*
    const hasSeen = localStorage.getItem('hasSeenCalendarTutorial');
    if (!hasSeen && activeTab === 'calendar') {
      setShowCalendarTutorial(true);
      localStorage.setItem('hasSeenCalendarTutorial', 'true');
    }
    */
  }, [activeTab]);

  const mainRef = useRef<HTMLElement>(null);

  useEffect(() => {
    // Force scroll to top on tab/unit change
    const scrollToTop = () => {
      window.scrollTo({ top: 0, behavior: 'instant' });
      if (mainRef.current) {
        mainRef.current.scrollTo(0, 0);
      }
    };
    
    // Initial scroll reset
    scrollToTop();
    
    // Delayed scroll reset to handle rendering race conditions
    const timer = setTimeout(scrollToTop, 50);
    const frame = requestAnimationFrame(scrollToTop);

    return () => {
      clearTimeout(timer);
      cancelAnimationFrame(frame);
    };
  }, [activeTab, activeUnit]);

  const handleShareContent = async (item: ContentItem | { title: string, content?: string, text?: string, hashtags?: string[] }) => {
    const title = item.title;
    const textContent = 'content' in item ? item.content : ('text' in item ? item.text : '');
    const itemHashtags = item.hashtags || [];
    const tags = itemHashtags.map(t => `#${t.replace(/\s+/g, '_')}`).join(' ');
    
    const shareText = `${title}\n\n${textContent}\n\n${tags}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: shareText,
          url: window.location.href
        });
      } catch (err) {
        console.log('Share failed or cancelled');
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareText);
        setToast({ message: 'محتوا در حافظه کپی شد', type: 'success' });
      } catch (err) {
        setToast({ message: 'خطا در کپی محتوا', type: 'error' });
      }
    }
  };

  useEffect(() => {
    const savedUser = localStorage.getItem('cyber_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    const savedTheme = localStorage.getItem('cyber_theme');
    if (savedTheme) {
      setDarkMode(savedTheme === 'dark');
    }
    setAuthLoading(false);
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('cyber_theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  useEffect(() => {
    const fetchData = async () => {
      // Avoid fetching if the tab is not visible to reduce noise and errors
      if (document.hidden) return;

      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

        const res = await fetch('/api/data', { signal: controller.signal });
        clearTimeout(timeoutId);

        if (!res.ok) throw new Error(`Server responded with ${res.status}`);
        const data = await res.json();
        
        if (data.operations) {
          setMissions(data.operations.missions || []);
          setTasks(data.operations.tasks || []);
          setTaskCompletions(data.operations.taskCompletions || []);
          setReports(data.operations.reports || []);
          setOrganizationalUnits(data.operations.organizationalUnits || []);
        }
        if (data.content) {
          setContentLibrary(data.content.library || []);
        }
        if (data.tracking) {
          setTrackedAccounts(data.tracking.accounts || []);
        }
        if (data.publishing) {
          setGordanContent(data.publishing.gordanContent || []);
        }
        if (data.education) {
          setEducationItems(data.education.items || []);
        }
        if (data.observations) {
          setObservations(data.observations || []);
        }
        if (data.messenger) {
          setChats(data.messenger.chats || []);
        }
        if (data.calendar) {
          setDailyPlans(data.calendar.events || []);
        }
        if (data.auth && user && (user.role === 'admin' || user.role === 'manager')) {
          setUsers(data.auth.users || []);
        }
        
        // Fetch logs for admin
        if (user?.role === 'admin') {
          const logsRes = await fetch('/api/system/logs');
          if (logsRes.ok) {
            const logsData = await logsRes.json();
            setLogs(logsData);
          }
        }
      } catch (err: any) {
        // Handle transient network errors silently (common during dev restarts)
        const isNetworkError = err instanceof TypeError || err.name === 'AbortError';
        const msg = err?.message?.toLowerCase() || '';
        
        if (isNetworkError && (
          msg.includes('failed to fetch') || 
          msg.includes('load failed') || 
          msg.includes('networkerror') || 
          msg.includes('aborted')
        )) {
          return;
        }
        
        console.warn('Data sync warning:', err);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5000); // Poll every 5s
    return () => clearInterval(interval);
  }, [user]);

  const handleLogout = () => {
    localStorage.removeItem('cyber_user');
    setUser(null);
  };

  const handleCompleteTask = async (missionId: string, taskId: string, link?: string, screenshot?: string) => {
    if (!user) return;
    
    // 1. Update the task status locally (as an indicator)
    const updatedTasks = tasks.map(t => t.id === taskId ? {
      ...t,
      status: 'submitted' as any,
      completedBy: user.uid,
      completedAt: new Date().toISOString(),
      documentationLink: link,
      documentationScreenshot: screenshot
    } : t);
    setTasks(updatedTasks);

    // 2. Create the completion record for detailed tracking
    const targetTask = tasks.find(t => t.id === taskId);
    const requiresApproval = targetTask?.isNasra || targetTask?.platform === 'other';

    const completion = {
      id: `c-${Date.now()}`,
      taskId,
      userId: user.uid,
      status: requiresApproval ? 'pending' : 'verified',
      proof: screenshot || link || '',
      timestamp: new Date().toISOString()
    };

    try {
      // Use specialized endpoint for performance
      await fetch('/api/task-completions/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(completion)
      });
      
      setTaskCompletions(prev => [...prev, completion]);
      setToast({ message: 'عملیات ثبت شد و در سلسله‌مراتب تایید قرار گرفت', type: 'success' });
      
      // Update the tasks state globally (indicator only, we don't necessarily need to sync full tasks array every time)
      // but to keep consistency for now:
      await fetch('/api/data/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: 'operations.tasks', value: updatedTasks })
      });
    } catch (err) {
      setToast({ message: 'خطا در ثبت عملیات. ارتباط خود را بررسی کنید', type: 'error' });
    }
  };

  const handleProfileUpdate = async (newProfile: UserProfile) => {
    setUser(newProfile);
    localStorage.setItem('cyber_user', JSON.stringify(newProfile));
    
    // Update the local users list
    setUsers(prev => prev.map(u => u.uid === newProfile.uid ? newProfile : u));

    try {
      // Sync to database
      const res = await fetch('/api/data');
      if (!res.ok) throw new Error('Fetch failed');
      const data = await res.json();
      const allUsers = data.auth?.users || [];
      const updatedUsers = allUsers.map((u: any) => u.uid === newProfile.uid ? newProfile : u);

      await fetch('/api/data/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          path: 'auth.users', 
          value: updatedUsers
        })
      });
      setToast({ message: 'تنظیمات پروفایل با موفقیت در دیتابیس بروزرسانی شد', type: 'success' });
    } catch (err) {
      console.error('Profile update failed:', err);
      // Even if server update fails, local state is updated, but let user know
      setToast({ message: 'بروزرسانی دیتابیس با خطا مواجه شد', type: 'error' });
    }
  };

  const renderScreen = () => {
    if (activeTab === 'home') {
      if (user.role === 'admin' || user.role === 'manager') {
        return (
          <AdminDashboard 
            missions={missions} 
            tasks={tasks} 
            users={users} 
            content={contentLibrary} 
            trackedAccounts={trackedAccounts}
            educationItems={educationItems}
            observations={observations}
            reports={reports}
            user={user}
            setToast={setToast}
            setViewingImage={setViewingImage}
            integrations={integrations}
            setIntegrations={setIntegrations}
            botConfig={botConfig}
            setBotConfig={setBotConfig}
            setTasks={setTasks}
            setUsers={setUsers}
            setMissions={setMissions}
            taskCompletions={taskCompletions}
            setTaskCompletions={setTaskCompletions}
            setObservations={setObservations}
            setReports={setReports}
            setTrackedAccounts={setTrackedAccounts}
            setEducationItems={setEducationItems}
            onShare={handleShareContent}
            dailyPlans={dailyPlans}
            setDailyPlans={setDailyPlans}
            onTabChange={setActiveTab}
            onAddMission={() => setShowAddMission(true)}
            onAddTask={() => {
              if (user?.role === 'admin' || user?.role === 'manager' || user?.unitLevel === 'nahiye' || (user?.unitLevel === 'howze' && user?.isTrusted)) {
                setShowAddTask({ missionId: '' });
              } else {
                setToast({ message: 'شما سطح دسترسی لازم برای ابلاغ وظیفه را ندارید', type: 'error' });
              }
            }}
            onAddUser={() => setShowAddUser(true)}
            onAddEvent={(date) => setShowCalendarAddEvent({ date: typeof date === 'string' ? date : new Date().toISOString().split('T')[0] })}
            updateDb={updateDb}
            newEvent={newEvent}
            setNewEvent={setNewEvent}
            showCalendarAddEvent={showCalendarAddEvent}
            setShowCalendarAddEvent={setShowCalendarAddEvent}
            handleAddEvent={handleAddEvent}
            showCalendarTutorial={showCalendarTutorial}
            setShowCalendarTutorial={setShowCalendarTutorial}
            activeSubTab={activeSubTab}
            setActiveSubTab={setActiveSubTab}
            logs={logs}
            setLogs={setLogs}
            organizationalUnits={organizationalUnits}
            setOrganizationalUnits={setOrganizationalUnits}
            newUnit={newUnit}
            setNewUnit={setNewUnit}
            newTask={newTask}
            setNewTask={setNewTask}
            showAddTask={showAddTask}
            setShowAddTask={setShowAddTask}
            newUser={newUser}
            setNewUser={setNewUser}
            showAddUser={showAddUser}
            setShowAddUser={setShowAddUser}
            onSendAnnouncement={() => setShowAddAnnouncement(true)}
            notifyBale={notifyBale}
            announcements={announcements}
            setAnnouncements={setAnnouncements}
            newAnnouncement={newAnnouncement}
            setNewAnnouncement={setNewAnnouncement}
            showAddAnnouncement={showAddAnnouncement}
            setShowAddAnnouncement={setShowAddAnnouncement}
            newMission={newMission}
            setNewMission={setNewMission}
            showAddMission={showAddMission}
            setShowAddMission={setShowAddMission}
            handleAddMission={handleAddMission}
            handleDeleteMission={handleDeleteMission}
            handleAddTask={handleAddTask}
            handleSendAnnouncement={handleSendAnnouncement}
          />
        );
      }
      return (
        <HomeScreen 
          user={user!} 
          missions={missions} 
          tasks={tasks} 
          contentLibrary={contentLibrary} 
          trackedAccounts={trackedAccounts} 
          gordanContent={gordanContent} 
          educationItems={educationItems} 
          observations={observations}
          onTabChange={setActiveTab} 
          onBack={handleBack}
          activeUnit={activeUnit}
          setActiveUnit={setActiveUnit}
          reports={reports}
          setReports={setReports}
          setToast={setToast}
          integrations={integrations}
          onShare={handleShareContent}
          dailyPlans={dailyPlans}
          setTrackedAccounts={setTrackedAccounts}
        />
      );
    }
    if (activeTab === 'saved') return <SavedScreen chats={chats} contentLibrary={contentLibrary} onShare={handleShareContent} />;
    if (activeTab === 'profile') return <ProfileScreen profile={user!} setProfile={handleProfileUpdate} setToast={setToast} darkMode={darkMode} setDarkMode={setDarkMode} notifyBale={notifyBale} />;
    if (activeTab === 'nasra') return <NasraCenterScreen tasks={tasks} onCompleteTask={handleCompleteTask} />;
    if (activeTab === 'info') return <BattalionInfoScreen />;
    if (activeTab === 'security') return <SecurityNoticeScreen />;
    if (activeTab === 'calendar') return (
      <CalendarScreen 
        events={dailyPlans} 
        userRole={user.role} 
        onAddEvent={(date) => setShowCalendarAddEvent({ date })}
        showTutorial={showCalendarTutorial}
        onCloseTutorial={() => setShowCalendarTutorial(false)}
      />
    );
    
    // Admin tab is now unified with Home for admins
    if (activeTab === 'admin' && (user.role === 'admin' || user.role === 'manager')) {
       // Optional: Redirect to home or keep as legacy
       setActiveTab('home');
       return null;
    }

    switch (activeTab) {
      case 'missions': return (
        <MissionControlScreen 
          missions={missions} 
          tasks={tasks} 
          onCompleteTask={handleCompleteTask} 
          user={user} 
          contentBank={contentLibrary} 
          educationItems={educationItems}
          onTabChange={setActiveTab}
          setToast={setToast}
          onShare={handleShareContent}
          dailyPlans={dailyPlans}
          onAddMission={() => setShowAddMission(true)}
          onAddTask={() => setShowAddTask({ missionId: '' })}
          onAddUser={() => setShowAddUser(true)}
          onAddEvent={() => setShowCalendarAddEvent({ date: new Date().toISOString().split('T')[0] })}
          updateDb={updateDb}
        />
      );
      case 'messenger': return <MessengerScreen chats={chats} setChats={setChats} user={user!} setToast={setToast} />;
      default: return (
        <HomeScreen 
          user={user!} 
          missions={missions} 
          tasks={tasks} 
          contentLibrary={contentLibrary} 
          trackedAccounts={trackedAccounts} 
          gordanContent={gordanContent} 
          educationItems={educationItems} 
          observations={observations}
          onTabChange={setActiveTab} 
          onBack={handleBack}
          activeUnit={activeUnit}
          setActiveUnit={setActiveUnit}
          reports={reports}
          setReports={setReports}
          setToast={setToast}
          integrations={integrations}
          onShare={handleShareContent}
          setTrackedAccounts={setTrackedAccounts}
        />
      );
    }
  };

  const getTitle = () => {
    if (activeTab === 'home') {
      switch (activeUnit) {
        case 'monitor': return 'واحد رصد و پایش';
        case 'studio': return 'واحد استودیو تبیین';
        case 'tutorial': return 'واحد آموزش و یادگیری';
        case 'explore': return 'ویترین محتوا';
        default: return 'قرارگاه مرکزی';
      }
    }
    if (activeTab === 'saved') return 'نشان شده‌ها';
    if (activeTab === 'profile') return 'پروفایل افسر';
    if (activeTab === 'nasra') return 'آموزش فضای مجازی (نصرا)';
    if (activeTab === 'info') return 'درباره گردان';
    if (activeTab === 'security') return 'امنیت و حریم خصوصی';
    if (activeTab === 'calendar') return 'تقویم عملیاتی';
    if (activeTab === 'admin') return 'پنل مدیریت عملیات';
    switch (activeTab) {
      case 'missions': return 'مرکز کنترل عملیات';
      case 'messenger': return 'قرارگاه پیام‌رسان';
      default: return 'گردان سایبری';
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-app-bg flex items-center justify-center">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-12 h-12 border-4 border-tg-accent border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    return <LoginScreen onLoginSuccess={setUser} />;
  }

  const handleBack = () => {
    if (activeTab === 'home' && activeUnit !== 'main') {
      setActiveUnit('main');
    } else {
      setActiveTab('home');
    }
  };

  return (
    <div 
      onContextMenu={(e) => e.preventDefault()}
      className="min-h-screen transition-colors duration-200 select-none flex bg-app-bg"
    >
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-72 border-r border-tg-border bg-tg-surface flex-col sticky top-0 h-screen transition-colors">
        <div className="p-6 border-b border-tg-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Shield size={24} className="text-white" />
            </div>
            <div>
              <h1 className="text-sm font-black uppercase tracking-tighter text-tg-text">گردان سایبری</h1>
              <p className="text-[8px] font-bold text-tg-text-muted uppercase tracking-widest">فرماندهی عملیات کل</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto no-scrollbar">
          {[
            { id: 'home', label: 'مرکز فرماندهی', icon: Layout },
            { id: 'missions', label: 'عملیات‌ها', icon: Target },
            { id: 'calendar', label: 'تقویم عملیاتی', icon: Calendar },
            { id: 'messenger', label: 'ارتباطات', icon: MessageSquare },
            { id: 'saved', label: 'نشان شده‌ها', icon: Bookmark },
            { id: 'profile', label: 'پروفایل افسر', icon: Users },
            { id: 'security', label: 'امنیت', icon: Lock },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => { setActiveTab(item.id as any); setActiveUnit('main'); }}
              className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl transition-all group ${
                activeTab === item.id 
                ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/20' 
                : 'text-tg-text-muted hover:bg-white/5 hover:text-tg-text'
              }`}
            >
              <item.icon size={20} className={activeTab === item.id ? 'scale-110' : 'group-hover:scale-110 transition-transform'} />
              <span className="text-xs font-black">{item.label}</span>
              {activeTab === item.id && <ChevronLeft size={16} className="mr-auto" />}
            </button>
          ))}

          {user.role === 'admin' && (
            <div className="pt-4 mt-4 border-t border-white/5 space-y-2">
              <p className="px-4 text-[8px] font-black text-slate-500 uppercase tracking-widest mb-2">فرماندهی کل</p>
              <button
                onClick={() => { setActiveTab('home'); setActiveUnit('main'); }}
                className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl transition-all group ${
                  activeTab === 'home' 
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' 
                  : 'text-slate-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                <LayoutGrid size={20} className={activeTab === 'home' ? 'scale-110' : 'group-hover:scale-110 transition-transform'} />
                <span className="text-xs font-black">میز کار فرماندهی</span>
              </button>
            </div>
          )}
        </nav>

        <div className="p-4 border-t border-tg-border bg-black/5 dark:bg-black/20 space-y-2 transition-colors">
          <button 
            onClick={() => setDarkMode(!darkMode)}
            className="w-full flex items-center justify-between p-3 rounded-2xl bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-all group border border-tg-border"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-tg-bg flex items-center justify-center text-amber-500 shadow-sm">
                {darkMode ? <Sun size={18} /> : <Moon size={18} />}
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-tg-text">{darkMode ? 'حالت روز' : 'حالت شب'}</span>
            </div>
            <div className={`w-10 h-5 rounded-full p-1 transition-colors ${darkMode ? 'bg-blue-500' : 'bg-slate-300 dark:bg-slate-700'}`}>
              <motion.div 
                animate={{ x: darkMode ? 20 : 0 }}
                className="w-3 h-3 bg-white rounded-full shadow-sm"
              />
            </div>
          </button>

          <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/5 border border-white/5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-black shadow-lg">
              {user.name.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-[10px] font-black truncate">{user.name}</h4>
              <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">
                {user.role === 'admin' ? 'مدیر سیستم' : user.role === 'manager' ? 'مدیر واحد' : 'کارشناس محتوا'}
              </p>
            </div>
            <button onClick={handleLogout} className="p-2 text-slate-500 hover:text-red-500 transition-colors">
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col relative min-w-0">
        <NavigationDrawer 
          isOpen={isSidebarOpen} 
          onClose={() => setIsSidebarOpen(false)} 
          onTabChange={(tab) => { setActiveTab(tab); setActiveUnit('main'); }}
          onUnitChange={setActiveUnit}
          onLogout={handleLogout}
          userRole={user?.role || 'user'}
          activeTab={activeTab}
        />
        


        <NotificationsPanel 
          isOpen={showNotifications} 
          onClose={() => setShowNotifications(false)} 
          notifications={notifications}
          onMarkAllRead={markAllAsRead}
        />

        <Header 
          title={getTitle()} 
          onMenuClick={() => setIsSidebarOpen(true)} 
          onNotificationsClick={() => setShowNotifications(true)}
          activeTab={activeTab}
          unreadNotifications={unreadNotifications}
          showBack={activeTab !== 'home' || activeUnit !== 'main'}
          onBack={handleBack}
        />
        
        <AnimatePresence>
          {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
        </AnimatePresence>

        {/* Global Modals */}
        {/* Add Mission Modal */}
        <BottomSheet 
          isOpen={showAddMission} 
          onClose={() => setShowAddMission(false)} 
          title="تأسیس ماموریت جدید"
        >
          <div className="space-y-6 p-2">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">عنوان ماموریت</label>
                <input 
                  placeholder="مثلاً: پاکسازی محتوای مسموم"
                  className="tg-input"
                  value={newMission.title}
                  onChange={e => setNewMission({...newMission, title: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">توضیحات استراتژیک</label>
                <textarea 
                  placeholder="اهداف عملیاتی و پیوست‌های ماموریت..."
                  className="tg-input min-h-[100px] py-4"
                  value={newMission.description}
                  onChange={e => setNewMission({...newMission, description: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">نوع ماموریت</label>
                  <select 
                    className="tg-input"
                    value={newMission.type}
                    onChange={e => setNewMission({...newMission, type: e.target.value as any})}
                  >
                    <option value="daily">روزانه</option>
                    <option value="urgent">فوری</option>
                    <option value="special">ویژه</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">اولویت اعلان</label>
                  <select 
                    className="tg-input"
                    value={newMission.priority}
                    onChange={e => setNewMission({...newMission, priority: e.target.value as any})}
                  >
                    <option value="low">کم</option>
                    <option value="medium">متوسط</option>
                    <option value="high">زیاد</option>
                    <option value="critical">بسیار مهم</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-3 py-2">
                <input 
                  type="checkbox" 
                  id="global-send-bale"
                  className="w-5 h-5 rounded bg-black/20 border-white/5 text-blue-500"
                  checked={newMission.sendBaleAlert}
                  onChange={e => setNewMission({...newMission, sendBaleAlert: e.target.checked})}
                />
                <label htmlFor="global-send-bale" className="text-[11px] font-black text-tg-text uppercase">ارسال اعلان سراسری به بله</label>
              </div>
            </div>

            <button 
              onClick={handleAddMission}
              className="tg-btn-primary w-full py-5"
            >
              ثبت و ابلاغ ماموریت عملیاتی
            </button>
          </div>
        </BottomSheet>

        <ImageViewer 
          src={viewingImage || ''} 
          isOpen={!!viewingImage} 
          onClose={() => setViewingImage(null)} 
        />

        <main ref={mainRef} className="flex-1 overflow-y-auto pb-24 lg:pb-8 no-scrollbar">
          <div className="max-w-screen-xl mx-auto w-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {renderScreen()}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>

        {/* Mobile Bottom Nav */}
        <nav className="lg:hidden fixed bottom-[calc(1rem+env(safe-area-inset-bottom))] left-4 right-4 bg-tg-surface/80 backdrop-blur-2xl border border-tg-border flex justify-around items-center py-2 z-50 px-2 rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.3)] transition-all">
          {[
            { id: 'home', label: 'ویترین', icon: Layout },
            { id: 'missions', label: 'وظایف', icon: Target },
            { id: 'calendar', label: 'تقویم', icon: Calendar },
            { id: 'messenger', label: 'پیام‌ها', icon: MessageSquare },
            { id: 'profile', label: 'پروفایل', icon: Users },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id as any); }}
              className={`flex flex-col items-center gap-1 transition-all relative px-3 py-2 rounded-2xl ${
                activeTab === tab.id ? 'text-tg-accent' : 'text-tg-text-muted'
              }`}
            >
              {activeTab === tab.id && (
                <motion.div 
                  layoutId="navGlow"
                  className="absolute inset-0 bg-tg-accent/10 rounded-2xl shadow-[inset_0_0_10px_rgba(36,129,204,0.1)] -z-10"
                  transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                />
              )}
              <tab.icon size={20} className={activeTab === tab.id ? 'scale-110 drop-shadow-[0_0_8px_rgba(36,129,204,0.5)]' : 'opacity-70'} />
              <span className={`text-[8px] font-black uppercase tracking-tighter ${activeTab === tab.id ? 'scale-105' : ''}`}>{tab.label}</span>
              {activeTab === tab.id && (
                <motion.div 
                  layoutId="activeDot"
                  className="w-1 h-1 bg-tg-accent rounded-full mt-0.5"
                />
              )}
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}
