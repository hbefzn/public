import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generateCyberContent(topic: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `به عنوان یک دستیار هوشمند برای گردان سایبری، برای موضوع زیر محتوای مناسب شبکه های اجتماعی (اینستاگرام، توییتر)، زمان انتشار پیشنهادی و هشتگ های مرتبط تولید کن. خروجی باید به صورت JSON باشد.
    موضوع: ${topic}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          content: { type: Type.STRING, description: "متن پیشنهادی برای محتوا" },
          hashtags: { type: Type.ARRAY, items: { type: Type.STRING }, description: "هشتگ های مرتبط" },
          suggestedTime: { type: Type.STRING, description: "زمان پیشنهادی برای انتشار" }
        },
        required: ["content", "hashtags", "suggestedTime"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}

export async function generateTweets(topic: string, count: number = 10) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `برای موضوع زیر، تعداد ${count} توئیت حرفه‌ای، تاثیرگذار و متنوع (خبری، تحلیلی، انتقادی، حماسی) به زبان فارسی تولید کن. هشتگ‌های مرتبط هم اضافه کن. خروجی به صورت JSON باشد.
    موضوع: ${topic}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING },
            hashtags: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["text", "hashtags"]
        }
      }
    }
  });

  return JSON.parse(response.text || "[]");
}

export async function monitorTrendingNews() {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: "آخرین اخبار لحظه‌ای و موضوعات ترند شده در فضای مجازی ایران را رصد کن و ۳ مورد از مهم‌ترین آن‌ها را که نیاز به واکنش گردان سایبری دارد به صورت خلاصه گزارش بده. خروجی به صورت JSON باشد.",
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            summary: { type: Type.STRING },
            urgency: { type: Type.STRING, enum: ["high", "medium", "low"] },
            suggestedAction: { type: Type.STRING }
          },
          required: ["title", "summary", "urgency", "suggestedAction"]
        }
      }
    }
  });

  return JSON.parse(response.text || "[]");
}

export async function getDailyBrief() {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: "یک گزارش کوتاه روزانه (Daily Brief) شامل ۳ پیشنهاد عملیاتی برای یک گردان سایبری بر اساس روندهای احتمالی روز ارائه بده. خروجی به صورت JSON باشد.",
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING }
          },
          required: ["title", "description"]
        }
      }
    }
  });

  return JSON.parse(response.text || "[]");
}

export async function generateStrategicAnalysis(data: any) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `به عنوان یک استراتژیست ارشد جنگ نرم و امنیت سایبری، داده‌های زیر را تحلیل کن و یک تحلیل استراتژیک جامع شامل وضعیت فعلی، تهدیدات احتمالی و پیشنهادات عملیاتی ارائه بده. خروجی به صورت JSON باشد.
    داده‌های سامانه: ${JSON.stringify(data)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING, description: "خلاصه تحلیل" },
          threatLevel: { type: Type.STRING, enum: ["low", "medium", "high", "critical"] },
          keyInsights: { type: Type.ARRAY, items: { type: Type.STRING } },
          operationalDirectives: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["summary", "threatLevel", "keyInsights", "operationalDirectives"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}
