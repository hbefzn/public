import express from "express";
import { createServer as createViteServer } from "vite";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(__dirname, "data", "db.json");
const USERS_DIR = path.join(__dirname, "data", "users");
const LOGS_DIR = path.join(__dirname, "data", "logs");
const STRUCTURES_PATH = path.join(__dirname, "data", "structures.json");

// Ensure data directories exist
if (!fs.existsSync(path.join(__dirname, "data"))) {
  fs.mkdirSync(path.join(__dirname, "data"));
}

// Bale Notification Helper
const sendBaleNotification = async (text: string, chatId?: string) => {
  const token = process.env.BALE_BOT_TOKEN;
  const defaultChatId = process.env.BALE_DEFAULT_CHAT_ID;
  const targetChatId = chatId || defaultChatId;

  if (!token || !targetChatId) {
    console.warn("Bale Bot Token or Chat ID not configured. Skipping notification.");
    return;
  }

  try {
    const response = await fetch(`https://tapi.bale.ai/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: targetChatId, text })
    });
    if (!response.ok) {
      try {
        const errData = await response.json();
        console.error("Bale API error:", errData);
      } catch (e) {
        console.error("Bale API error (no json):", response.statusText);
      }
    }
  } catch (err) {
    console.error("Failed to send Bale notification:", err);
  }
};

if (!fs.existsSync(USERS_DIR)) {
  fs.mkdirSync(USERS_DIR);
}
if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR);
}

// Logging Helper
const writeLog = (action: string, details: any) => {
  const today = new Date().toISOString().split('T')[0];
  const logFile = path.join(LOGS_DIR, `${today}.json`);
  const logEntry = {
    timestamp: new Date().toISOString(),
    action,
    details
  };

  let logs = [];
  if (fs.existsSync(logFile)) {
    try {
      logs = JSON.parse(fs.readFileSync(logFile, "utf-8"));
    } catch (e) { logs = []; }
  }
  logs.push(logEntry);
  fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));
};

// Initial DB structure (global data)
const initialDb = {
  system: {
    version: "5.0.0",
    lastUpdate: new Date().toISOString(),
    config: {
      maintenance: false,
      signupEnabled: true,
      uploadUrl: "https://your-download-host.com/upload.php",
      storageUrl: "https://your-download-host.com/files/"
    }
  },
  auth: {
    users: [] 
  },
  operations: {
    missions: [
      { 
        id: 'm1', 
        title: 'پویش تبیین دستاوردها', 
        description: 'انتشار محتوای علمی در شبکه‌های اجتماعی برای اطلاع‌رسانی صحیح',
        type: 'daily',
        reward: '۵۰۰ امتیاز',
        isCompleted: false
      }
    ],
    tasks: [],
    reports: [],
    taskCompletions: [],
    organizationalUnits: [
      { id: 'unit-1', name: 'ناحیه مرکزی', level: 'nahiye', createdAt: new Date().toISOString() }
    ]
  },
  calendar: {
    events: []
  },
  content: {
    library: []
  },
  tracking: {
    accounts: []
  },
  publishing: {
    gordanContent: []
  },
  education: {
    items: []
  },
  messenger: {
    chats: [
      {
        id: 'ch-shamsa',
        name: 'کانال شمسا',
        description: 'شبکه مربیان سواد رسانه‌ای انقلاب اسلامی',
        avatar: '📚',
        lastMsg: 'به کانال تخصصی شمسا خوش آمدید',
        time: 'الان',
        unread: 0,
        color: 'bg-blue-600',
        type: 'channel',
        messages: [],
        subscribers: 1250
      },
      {
        id: 'ch-matna',
        name: 'کانال متنا',
        description: 'مرکز تولید و نشر دیجیتال انقلاب اسلامی',
        avatar: '🎨',
        lastMsg: 'آخرین پالت‌های گرافیکی و محتوای چندرسانه‌ای ابلاغ شد',
        time: 'الان',
        unread: 1,
        color: 'bg-purple-600',
        type: 'channel',
        messages: [],
        subscribers: 840
      },
      {
        id: 'ch-nasra',
        name: 'کانال نصرا',
        description: 'نهضت سواد رسانه‌ای انقلاب اسلامی',
        avatar: '⚖️',
        lastMsg: 'گزارش رصد هفتگی فضای مجازی منتشر شد',
        time: 'الان',
        unread: 0,
        color: 'bg-emerald-600',
        type: 'channel',
        messages: [],
        subscribers: 2100
      },
      {
        id: 'ch-media',
        name: 'کانال رسانه‌محله',
        description: 'هم‌افزایی و توانمندسازی رسانه‌ای محلات',
        avatar: '🏘️',
        lastMsg: 'راهنمای راه‌اندازی رسانه‌های محلی بروزرسانی شد',
        time: 'الان',
        unread: 0,
        color: 'bg-amber-600',
        type: 'channel',
        messages: [],
        subscribers: 1560
      }
    ]
  }
};

// Initial Admin User
const initialAdmin = {
  uid: "admin-09199730153",
  phone: "09199730153",
  password: "09199730153",
  role: "admin",
  name: "مدیر ارشد پلتفرم",
  rank: "مدیریت استراتژیک",
  battalion: "shamza",
  unitLevel: "nahiye",
  unitName: "مرکز هماهنگی",
  points: 9999,
  level: 100,
  completedMissions: 0,
  isWhitelisted: true,
  createdAt: new Date().toISOString()
};

const adminFilePath = path.join(USERS_DIR, "admin-09199730153.json");
if (!fs.existsSync(adminFilePath)) {
  fs.writeFileSync(adminFilePath, JSON.stringify(initialAdmin, null, 2));
}

if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify(initialDb, null, 2));
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ limit: '10mb', extended: true }));

  // Helper to read all users
  const readAllUsers = () => {
    const files = fs.readdirSync(USERS_DIR).filter(f => f.endsWith(".json"));
    return files.map(file => {
      try {
        return JSON.parse(fs.readFileSync(path.join(USERS_DIR, file), "utf-8"));
      } catch (e) {
        return null;
      }
    }).filter(u => u !== null);
  };

  // Helper to read/write DB
  const readDb = () => {
    let globalData;
    try {
      globalData = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
    } catch (e) {
      globalData = { ...initialDb };
    }
    
    // Supplement with users from files
    globalData.auth.users = readAllUsers();

    // Supplement with structures
    if (fs.existsSync(STRUCTURES_PATH)) {
      try {
        globalData.operations.organizationalUnits = JSON.parse(fs.readFileSync(STRUCTURES_PATH, "utf-8"));
      } catch (e) {
        globalData.operations.organizationalUnits = globalData.operations.organizationalUnits || [];
      }
    }

    return globalData;
  };

  const writeDb = (data: any) => {
    const { auth, operations, ...rest } = data;
    const { organizationalUnits, ...otherOps } = operations || {};

    // Save global data (without users and units to keep file small/modular)
    fs.writeFileSync(DB_PATH, JSON.stringify({ ...rest, operations: otherOps, auth: { ...auth, users: [] } }, null, 2));
    
    // Save users individually
    if (auth && auth.users) {
      auth.users.forEach((user: any) => {
        if (user.uid) {
          const userPath = path.join(USERS_DIR, `${user.uid}.json`);
          fs.writeFileSync(userPath, JSON.stringify(user, null, 2));
        }
      });
    }

    // Save structures
    if (organizationalUnits) {
       fs.writeFileSync(STRUCTURES_PATH, JSON.stringify(organizationalUnits, null, 2));
    }
  };

  // API Routes
  app.post("/api/login", (req, res) => {
    const { phone, password, mode, otp } = req.body;
    const db = readDb();
    const user = db.auth.users.find((u: any) => u.phone === phone);
    
    if (!user) {
      writeLog("LOGIN_FAILED_NOT_FOUND", { phone });
      return res.status(401).json({ success: false, message: "کاربر یافت نشد" });
    }

    if (mode === 'bale') {
      // Simulate Bale OTP verification
      if (otp && otp.length === 6) {
        writeLog("LOGIN_BALE_SUCCESS", { phone, uid: user.uid });
        const { password, ...userWithoutPassword } = user;
        return res.json({ success: true, user: userWithoutPassword });
      } else {
        return res.status(401).json({ success: false, message: "کد تایید پیام‌رسان بله معتبر نیست" });
      }
    }

    if (user.password === password) {
      writeLog("LOGIN_SUCCESS", { phone, uid: user.uid });
      const { password, ...userWithoutPassword } = user;
      res.json({ success: true, user: userWithoutPassword });
    } else {
      writeLog("LOGIN_FAILED", { phone });
      res.status(401).json({ success: false, message: "رمز عبور اشتباه است" });
    }
  });

  app.post("/api/signup", (req, res) => {
    const { phone, password, name, battalion, unitLevel, unitName } = req.body;
    const db = readDb();
    
    if (db.auth.users.find((u: any) => u.phone === phone)) {
      writeLog("SIGNUP_FAILED_EXISTS", { phone });
      return res.status(400).json({ success: false, message: "این شماره موبایل قبلاً ثبت شده است" });
    }

    const newUser = {
      uid: `user-${Date.now()}`,
      phone,
      password,
      name,
      role: "user",
      rank: "کارشناس",
      battalion: battalion || "shamza",
      unitLevel: unitLevel || "level1",
      unitName: unitName || "واحد اختصاصی",
      points: 0,
      level: 1,
      completedMissions: 0,
      isWhitelisted: false,
      createdAt: new Date().toISOString()
    };

    db.auth.users.push(newUser);
    writeDb(db);
    writeLog("SIGNUP_SUCCESS", { uid: newUser.uid, phone });

    // Send Bale Notification for new User
    sendBaleNotification(`🚀 کاربر جدید ثبت‌نام کرد:\n👤 نام: ${name}\n📞 شماره: ${phone}\n🏢 یگان: ${battalion || 'نامشخص'}`);

    const { password: _, ...userWithoutPassword } = newUser;
    res.json({ success: true, user: userWithoutPassword });
  });

  // Data Routes
  app.get("/api/data", (req, res) => {
    const db = readDb();
    res.json(db);
  });

  // Specialized endpoints for better performance
  app.get("/api/system/logs", (req, res) => {
    try {
      const db = readDb();
      res.json(db.logs || []);
    } catch (err) {
      res.status(500).json({ success: false });
    }
  });

  app.post("/api/users/add", (req, res) => {
    try {
      const user = req.body;
      if (!user.uid) return res.status(400).json({ success: false, message: "Missing UID" });
      const db = readDb();
      // Ensure departments array exists
      if (!user.departments) user.departments = [];
      const existingIndex = db.auth.users.findIndex((u: any) => u.uid === user.uid);
      if (existingIndex > -1) {
        db.auth.users[existingIndex] = user;
      } else {
        db.auth.users.push(user);
      }
      writeDb(db);
      writeLog("USER_UPSERT", { uid: user.uid, name: user.name, role: user.role, departments: user.departments });
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ success: false });
    }
  });

  app.post("/api/units/update", (req, res) => {
    try {
      const unit = req.body;
      if (!unit.id) return res.status(400).json({ success: false, message: "Missing ID" });
      const db = readDb();
      if (!db.operations.organizationalUnits) db.operations.organizationalUnits = [];
      const existingIndex = db.operations.organizationalUnits.findIndex((u: any) => u.id === unit.id);
      if (existingIndex > -1) {
        db.operations.organizationalUnits[existingIndex] = unit;
      } else {
        db.operations.organizationalUnits.push(unit);
      }
      writeDb(db);
      writeLog("UNIT_UPSERT", { id: unit.id, name: unit.name });
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ success: false });
    }
  });

  app.post("/api/structures/update", (req, res) => {
    try {
      const { action, data } = req.body;
      const db = readDb();
      if (!db.operations.organizationalUnits) db.operations.organizationalUnits = [];
      
      let structures = db.operations.organizationalUnits;

      if (action === 'add') {
        const newUnit = {
          ...data,
          id: Date.now() // Use numeric ID as requested
        };
        structures.push(newUnit);
      } else if (action === 'update') {
        structures = structures.map((s: any) => s.id == data.id ? { ...s, ...data } : s);
      } else if (action === 'delete') {
        structures = structures.filter((s: any) => s.id != data.id);
      }

      db.operations.organizationalUnits = structures;
      writeDb(db);
      writeLog(`STRUCTURE_${action.toUpperCase()}`, { id: data?.id });
      res.json({ success: true, structures });
    } catch (err) {
      res.status(500).json({ success: false });
    }
  });

  app.post("/api/task-completions/add", (req, res) => {
    try {
      const completion = req.body;
      const db = readDb();
      if (!db.operations.taskCompletions) db.operations.taskCompletions = [];
      db.operations.taskCompletions.push(completion);
      writeDb(db);
      writeLog("TASK_COMPLETION", { taskId: completion.taskId, userId: completion.userId });
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ success: false });
    }
  });

  app.post("/api/data/update", (req, res) => {
    const { path: dbPath, value } = req.body;
    const db = readDb();
    
    writeLog("DB_UPDATE", { path: dbPath });

    // Simple path updater (e.g. "operations.missions")
    const parts = dbPath.split(".");
    let current = db;
    try {
      for (let i = 0; i < parts.length - 1; i++) {
        if (!current[parts[i]]) {
          current[parts[i]] = {};
        }
        current = current[parts[i]];
      }
      current[parts[parts.length - 1]] = value;
      
      writeDb(db);
      res.json({ success: true });
    } catch (err) {
      console.error('Update failed:', err);
      res.status(500).json({ success: false, message: "Update failed" });
    }
  });

  app.post("/api/tasks/complete", (req, res) => {
    const { taskId, userId, proofUrl, proofScreenshot } = req.body;
    const db = readDb();
    
    // Find task
    const task = db.operations.tasks.find((t: any) => t.id === taskId);
    if (!task) return res.status(404).json({ success: false, message: "Task not found" });

    const completion = {
      id: `comp-${Date.now()}`,
      taskId,
      userId,
      proofUrl,
      proofScreenshot,
      status: 'pending',
      timestamp: new Date().toISOString()
    };

    if (!db.operations.taskCompletions) db.operations.taskCompletions = [];
    db.operations.taskCompletions.push(completion);
    
    writeDb(db);
    writeLog("TASK_SUBMITTED", { taskId, userId });

    // Send Bale Notification for task submission
    const user = db.auth.users.find((u: any) => u.uid === userId);
    sendBaleNotification(`📝 مأموریت انجام شد:\n🎯 مأموریت: ${task.title}\n👤 توسط: ${user?.name || userId}\n✅ وضعیت: در انتظار تایید`);

    res.json({ success: true, completion });
  });

  app.get("/api/logs", (req, res) => {
    const today = new Date().toISOString().split('T')[0];
    const logFile = path.join(LOGS_DIR, `${today}.json`);
    if (fs.existsSync(logFile)) {
      res.json(JSON.parse(fs.readFileSync(logFile, "utf-8")));
    } else {
      res.json([]);
    }
  });

  // Dedicated Bale Notification Endpoint
  app.post("/api/notifications/bale", async (req, res) => {
    const { text, chatId } = req.body;
    if (!text) return res.status(400).json({ success: false, message: "Text is required" });
    
    await sendBaleNotification(text, chatId);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
