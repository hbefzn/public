<?php
/**
 * یکپارچه‌سازی هوش مصنوعی Gemini در PHP
 */

require_once 'config.php';

class GeminiAI {
    private static $baseUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

    public static function generate($prompt, $schema = null) {
        $apiKey = GEMINI_API_KEY;
        if (!$apiKey) return ["error" => "API Key not found"];

        $url = self::$baseUrl . "?key=" . $apiKey;

        $contents = [
            "contents" => [
                ["parts" => [["text" => $prompt]]]
            ],
            "generationConfig" => [
                "responseMimeType" => "application/json"
            ]
        ];

        if ($schema) {
            $contents["generationConfig"]["responseSchema"] = $schema;
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($contents));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            return ["error" => "AI Service Error: " . $response];
        }

        $data = json_decode($response, true);
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '{}';
        
        return json_decode($text, true);
    }

    public static function generateCyberContent($topic) {
        $prompt = "به عنوان یک دستیار هوشمند برای گردان سایبری، برای موضوع زیر محتوای مناسب شبکه های اجتماعی (اینستاگرام، توییتر)، زمان انتشار پیشنهادی و هشتگ های مرتبط تولید کن. موضوع: {$topic}";
        return self::generate($prompt);
    }

    public static function generateStrategicAnalysis($data) {
        $dataStr = json_encode($data, JSON_UNESCAPED_UNICODE);
        $prompt = "به عنوان یک استراتژیست ارشد جنگ نرم، داده‌های زیر را تحلیل کن و یک تحلیل استراتژیک شامل وضعیت فعلی، تهدیدات و پیشنهادات ارائه بده: {$dataStr}";
        return self::generate($prompt);
    }
}
