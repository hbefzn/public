<?php
/**
 * مدیریت دیتابیس سامانه (JSON Based)
 */

class Database {
    public static function readDb() {
        if (!file_exists(DB_PATH)) {
            return [];
        }
        $data = json_decode(file_get_contents(DB_PATH), true);
        $data['auth']['users'] = self::readAllUsers();
        $data['operations']['organizationalUnits'] = self::readStructures();
        return $data;
    }

    public static function writeDb($data) {
        $users = isset($data['auth']['users']) ? $data['auth']['users'] : [];
        $data['auth']['users'] = []; // خالی کردن آرایه کاربران برای ذخیره در فایل اصلی

        file_put_contents(DB_PATH, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        foreach ($users as $user) {
            if (isset($user['uid'])) {
                file_put_contents(USERS_DIR . "{$user['uid']}.json", json_encode($user, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
        }
    }

    public static function readAllUsers() {
        $users = [];
        $files = glob(USERS_DIR . "*.json");
        foreach ($files as $file) {
            $users[] = json_decode(file_get_contents($file), true);
        }
        return $users;
    }

    public static function readStructures() {
        if (!file_exists(STRUCTURES_PATH)) {
            return [];
        }
        return json_decode(file_get_contents(STRUCTURES_PATH), true) ?: [];
    }

    public static function writeStructures($structures) {
        file_put_contents(STRUCTURES_PATH, json_encode($structures, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    public static function writeLog($action, $details) {
        $today = date('Y-m-d');
        $logFile = LOGS_DIR . "{$today}.json";
        
        $logs = [];
        if (file_exists($logFile)) {
            $logs = json_decode(file_get_contents($logFile), true) ?: [];
        }

        $logs[] = [
            'timestamp' => date('c'),
            'action' => $action,
            'details' => $details
        ];

        file_put_contents($logFile, json_encode($logs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}
