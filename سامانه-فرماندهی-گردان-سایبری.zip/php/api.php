<?php
/**
 * نقطه ورود API سامانه گردان سایبری
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once 'config.php';
require_once 'database.php';
require_once 'gemini.php';

$requestUri = explode('?', $_SERVER['REQUEST_URI'], 2)[0];
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

// شبیه‌سازی مسیرهای API
$endpoint = str_replace('/api/', '', $requestUri);

try {
    switch ($endpoint) {
        case 'login':
            handleLogin($input);
            break;
        case 'signup':
            handleSignup($input);
            break;
        case 'data':
            handleGetData();
            break;
        case 'data/update':
            handleUpdateData($input);
            break;
        case 'structures':
            handleGetStructures();
            break;
        case 'structures/update':
            handleUpdateStructure($input);
            break;
        case 'ai/content':
            handleAiContent($input);
            break;
        case 'notifications/bale':
            handleBaleNotify($input);
            break;
        default:
            http_response_code(404);
            echo json_encode(["success" => false, "message" => "Endpoint not found: $endpoint"]);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}

function handleGetStructures() {
    echo json_encode(Database::readStructures());
}

function handleUpdateStructure($input) {
    $action = $input['action'] ?? 'add'; // add, update, delete
    $data = $input['data'] ?? null;
    
    $structures = Database::readStructures();
    
    if ($action === 'add') {
        $data['id'] = time(); // Numeric unique ID
        $structures[] = $data;
    } elseif ($action === 'update') {
        foreach ($structures as &$s) {
            if ($s['id'] == $data['id']) {
                $s = array_merge($s, $data);
                break;
            }
        }
    } elseif ($action === 'delete') {
        $structures = array_values(array_filter($structures, function($s) use ($data) {
            return $s['id'] != $data['id'];
        }));
    }

    Database::writeStructures($structures);
    echo json_encode(["success" => true, "structures" => $structures]);
}

function handleLogin($input) {
    $phone = $input['phone'] ?? '';
    $password = $input['password'] ?? '';
    
    $users = Database::readAllUsers();
    $foundUser = null;
    foreach ($users as $user) {
        if ($user['phone'] === $phone) {
            $foundUser = $user;
            break;
        }
    }

    if (!$foundUser || $foundUser['password'] !== $password) {
        Database::writeLog("LOGIN_FAILED", ["phone" => $phone]);
        echo json_encode(["success" => false, "message" => "شماره موبایل یا رمز عبور اشتباه است"]);
        return;
    }

    unset($foundUser['password']);
    Database::writeLog("LOGIN_SUCCESS", ["uid" => $foundUser['uid']]);
    echo json_encode(["success" => true, "user" => $foundUser]);
}

function handleSignup($input) {
    $db = Database::readDb();
    foreach ($db['auth']['users'] as $u) {
        if ($u['phone'] === $input['phone']) {
            echo json_encode(["success" => false, "message" => "این شماره قبلاً ثبت شده است"]);
            return;
        }
    }

    $newUser = array_merge($input, [
        'uid' => 'user-' . time(),
        'role' => 'user',
        'points' => 0,
        'level' => 1,
        'createdAt' => date('c')
    ]);

    $db['auth']['users'][] = $newUser;
    Database::writeDb($db);
    
    Database::writeLog("SIGNUP_SUCCESS", ["uid" => $newUser['uid']]);
    sendBaleNotification("🚀 ثبت‌نام کاربر جدید:\nنام: {$newUser['name']}\nتلفن: {$newUser['phone']}");
    
    unset($newUser['password']);
    echo json_encode(["success" => true, "user" => $newUser]);
}

function handleGetData() {
    echo json_encode(Database::readDb());
}

function handleUpdateData($input) {
    $path = $input['path'] ?? '';
    $value = $input['value'] ?? null;
    
    $db = Database::readDb();
    // Logic for updating nested key (simplified)
    $parts = explode('.', $path);
    $temp = &$db;
    foreach ($parts as $part) {
        if (!isset($temp[$part])) $temp[$part] = [];
        $temp = &$temp[$part];
    }
    $temp = $value;

    Database::writeDb($db);
    echo json_encode(["success" => true]);
}

function handleAiContent($input) {
    $topic = $input['topic'] ?? '';
    $result = GeminiAI::generateCyberContent($topic);
    echo json_encode($result);
}

function handleBaleNotify($input) {
    $text = $input['text'] ?? '';
    sendBaleNotification($text);
    echo json_encode(["success" => true]);
}
