<?php
/**
 * پیکربندی اصلی سامانه گردان سایبری
 * بارگذاری متغیرهای محیطی از فایل .env
 */

function loadEnv($path) {
    if (!file_exists($path)) {
        return;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value, " \"'");
        putenv(sprintf('%s=%s', $name, $value));
        $_ENV[$name] = $value;
    }
}

loadEnv(__DIR__ . '/../.env');

define('GEMINI_API_KEY', getenv('GEMINI_API_KEY'));
define('BALE_BOT_TOKEN', getenv('BALE_BOT_TOKEN'));
define('BALE_DEFAULT_CHAT_ID', getenv('BALE_DEFAULT_CHAT_ID'));

define('DB_PATH', __DIR__ . '/../data/db.json');
define('USERS_DIR', __DIR__ . '/../data/users/');
define('LOGS_DIR', __DIR__ . '/../data/logs/');
define('STRUCTURES_PATH', __DIR__ . '/../data/structures.json');

// ایجاد پوشه‌های لازم در صورت عدم وجود
if (!is_dir(USERS_DIR)) mkdir(USERS_DIR, 0777, true);
if (!is_dir(LOGS_DIR)) mkdir(LOGS_DIR, 0777, true);

/**
 * ارسال پیام به بله
 */
function sendBaleNotification($text, $chatId = null) {
    $token = BALE_BOT_TOKEN;
    $targetChatId = $chatId ?: BALE_DEFAULT_CHAT_ID;

    if (!$token || !$targetChatId) return false;

    $url = "https://tapi.bale.ai/bot{$token}/sendMessage";
    $data = [
        'chat_id' => $targetChatId,
        'text' => $text
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}
