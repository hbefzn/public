/**
 * Iran Store App Logic (Vanilla JS)
 * Handles products, cart, and UI interactions
 */

let products = [];
let cart = JSON.parse(localStorage.getItem('cart') || '[]');

async function init() {
    try {
        const response = await fetch('api.php');
        const data = await response.json();
        products = data.products || [];
        renderProducts();
        updateCartUI();
    } catch (e) {
        console.error('Error loading data:', e);
    }
}

function renderProducts() {
    const list = document.getElementById('product-list');
    list.innerHTML = products.map(p => `
        <div class="product-card" onclick="addToCart('${p.id}')">
            <img src="${p.image}" class="product-img">
            <h3 style="font-size: 0.9rem; margin: 10px 0;">${p.title}</h3>
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <span style="color: var(--brand-accent); font-weight: 900; font-size: 0.8rem;">
                    ${p.price.toLocaleString('fa-IR')} تومان
                </span>
                <span style="font-size: 0.7rem; color: #fbbf24;">★ ${p.rating}</span>
            </div>
        </div>
    `).join('');
}

function addToCart(id) {
    const product = products.find(p => p.id === id);
    if (!product) return;
    
    const existing = cart.find(item => item.id === id);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ ...product, quantity: 1 });
    }
    
    saveCart();
    updateCartUI();
    openCart();
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    saveCart();
    updateCartUI();
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function updateCartUI() {
    const count = document.getElementById('cart-count');
    const items = document.getElementById('cart-items');
    const total = document.getElementById('cart-total');
    
    const totalCount = cart.reduce((acc, item) => acc + item.quantity, 0);
    count.innerText = totalCount;
    count.style.display = totalCount > 0 ? 'flex' : 'none';
    
    items.innerHTML = cart.map(item => `
        <div style="display: flex; gap: 10px; align-items: center; background: var(--brand-bg); p: 10px; border-radius: 15px; padding: 10px;">
            <img src="${item.image}" style="width: 50px; height: 50px; border-radius: 10px; object-fit: cover;">
            <div style="flex: 1;">
                <div style="font-size: 0.7rem; font-weight: bold;">${item.title}</div>
                <div style="font-size: 0.7rem; color: var(--brand-accent);">${item.quantity} عدد</div>
            </div>
            <button onclick="removeFromCart('${item.id}')" style="background: none; border: none; color: #f43f5e; cursor: pointer;">×</button>
        </div>
    `).join('');
    
    const totalPrice = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    total.innerText = totalPrice.toLocaleString('fa-IR') + ' تومان';
}

function openCart() {
    document.getElementById('cart-drawer').classList.add('open');
    document.getElementById('overlay').classList.add('active');
}

function closeCart() {
    document.getElementById('cart-drawer').classList.remove('open');
    document.getElementById('overlay').classList.remove('active');
}

// Event Listeners
document.getElementById('open-cart').onclick = openCart;
document.getElementById('close-cart').onclick = closeCart;
document.getElementById('overlay').onclick = closeCart;

// Start the app
init();
