import { useState, useEffect, FormEvent } from 'react';
import { 
  ShoppingBag, 
  Home, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  LayoutDashboard,
  Search,
  User,
  Settings,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  CreditCard,
  Smartphone,
  Info,
  BookOpen,
  Image as ImageIcon,
  Star,
  Clock,
  Menu,
  X,
  PlusCircle,
  ShieldCheck,
  Package,
  Heart
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

declare global {
  interface Window {
    ethereum?: any;
  }
}

// --- Types ---
interface Product {
  id: string;
  title: string;
  price: number;
  description: string;
  image: string;
  images?: string[];
  category: string;
  rating: number;
  reviews: number;
}

interface CartItem extends Product {
  quantity: number;
}

interface Banner {
  id: string;
  image: string;
  title: string;
  subtitle: string;
}

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  date: string;
}

interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  avatar: string;
  isAdmin: boolean;
}

type View = 'home' | 'product-detail' | 'cart' | 'checkout' | 'admin' | 'account' | 'about' | 'blog' | 'blog-post' | 'search' | 'success';

export default function App() {
  // --- State ---
  const [view, setView] = useState<View>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [cart, setCart] = useState<CartItem[]>(() => {
    if (typeof window === 'undefined') return [];
    const saved = localStorage.getItem('cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [user, setUser] = useState<UserProfile>({
    id: 'u1',
    name: 'کاربر مهمان',
    phone: '',
    email: '',
    avatar: 'https://ui-avatars.com/api/?name=Guest&background=2dd4bf&color=fff',
    isAdmin: true
  });

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const response = await fetch('/api/data');
        const data = await response.json();
        setProducts(data.products || []);
        setBanners(data.banners || []);
        setBlogs(data.blogs || []);
      } catch (error) {
        console.error('Failed to fetch data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const saveToBackend = async (newProducts: Product[], newBanners: Banner[], newBlogs: BlogPost[]) => {
    try {
      await fetch('/api/data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ products: newProducts, banners: newBanners, blogs: newBlogs })
      });
    } catch (error) {
      console.error('Failed to save data:', error);
    }
  };
  const [cartOpen, setCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [walletLoading, setWalletLoading] = useState(false);

  const connectWallet = async (isDemo = false) => {
    if (isDemo) {
      setWalletLoading(true);
      await new Promise(r => setTimeout(r, 800));
      const mockAddr = '0x71C765...d897';
      setWalletAddress(mockAddr);
      setWalletLoading(false);
      return mockAddr;
    }

    if (typeof window.ethereum !== 'undefined') {
      setWalletLoading(true);
      try {
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        if (accounts && accounts[0]) {
          setWalletAddress(accounts[0]);
          setWalletLoading(false);
          return accounts[0];
        }
      } catch (err: any) {
        setWalletLoading(false);
        // We avoid console.error here to prevent triggering system error alerts
        // in environments where MetaMask might be blocked by iframe policies.
        if (err.code === 4001) {
          console.debug('User rejected wallet request');
        } else {
          console.debug('Wallet interaction limited', err.message);
        }
      }
    } else {
      console.debug('MetaMask not detected in this context');
    }
    return null;
  };

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [view, selectedProduct]);

  // --- Actions ---
  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const addProduct = (newProduct: Product) => {
    const updated = [newProduct, ...products];
    setProducts(updated);
    saveToBackend(updated, banners, blogs);
  };

  const updateProduct = (updatedProduct: Product) => {
    const updated = products.map(p => p.id === updatedProduct.id ? updatedProduct : p);
    setProducts(updated);
    saveToBackend(updated, banners, blogs);
  };

  const deleteProduct = (id: string) => {
    const updated = products.filter(p => p.id !== id);
    setProducts(updated);
    saveToBackend(updated, banners, blogs);
  };

  const deleteBanner = (id: string) => {
    const updated = banners.filter(b => b.id !== id);
    setBanners(updated);
    saveToBackend(products, updated, blogs);
  };

  const deleteBlog = (id: string) => {
    const updated = blogs.filter(b => b.id !== id);
    setBlogs(updated);
    saveToBackend(products, banners, updated);
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR') + ' تومان';
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // --- Components ---

  const Navbar = () => (
    <nav className="sticky top-0 z-50 px-4 md:px-10 py-3 rtl">
      <div className="max-w-5xl mx-auto bg-brand-surface/80 backdrop-blur-2xl border border-brand-border/50 rounded-2xl px-4 py-2 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-6">
          <div onClick={() => setView('home')} className="flex items-center gap-2 cursor-pointer group">
            <div className="w-9 h-9 bg-white/5 rounded-xl flex items-center justify-center text-brand-accent shadow-md group-hover:scale-105 transition-transform">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-md font-black text-brand-text-primary tracking-tighter">ایران استور</span>
              <span className="text-[7px] font-bold text-brand-accent uppercase tracking-widest leading-none">Iran Store Pro</span>
            </div>
          </div>
          <div className="hidden lg:flex items-center gap-6">
            {[
              { n: 'فروشگاه', v: 'home' },
              { n: 'وبلاگ', v: 'blog' },
              { n: 'درباره ما', v: 'about' }
            ].map((item) => (
              <button key={item.n} onClick={() => setView(item.v as any)} className={`font-black text-xs transition-all relative group border-none bg-transparent cursor-pointer ${view === item.v ? 'text-brand-accent' : 'text-brand-text-secondary hover:text-brand-accent'}`}>
                {item.n}
                {view === item.v && <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-brand-accent rounded-full" />}
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setView('search')}
            className="w-9 h-9 rounded-xl bg-brand-bg flex items-center justify-center text-brand-text-secondary hover:text-brand-accent transition-all border border-brand-border cursor-pointer"
          >
            <Search className="w-5 h-5" />
          </button>
          
          <button 
            onClick={() => setView('account')}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all border-none cursor-pointer ${view === 'account' ? 'bg-brand-accent text-brand-bg shadow-md' : 'bg-brand-surface text-brand-text-secondary hover:text-brand-accent border border-brand-border'}`}
          >
            <User className="w-5 h-5" />
            <span className="text-xs font-black hidden sm:block">حساب</span>
          </button>
          <button 
            onClick={() => setCartOpen(true)}
            className="flex items-center gap-3 px-4 py-3 bg-brand-bg border border-brand-border text-brand-text-primary font-black rounded-2xl hover:border-brand-accent transition-all relative border-none cursor-pointer"
          >
            <ShoppingBag className="w-6 h-6 text-brand-accent" />
            <span className="text-sm font-black hidden sm:block">سبد</span>
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 w-6 h-6 bg-rose-500 text-xs font-black rounded-full flex items-center justify-center text-white ring-2 ring-brand-surface animate-pulse">
                {cart.reduce((a, b) => a + b.quantity, 0)}
              </span>
            )}
          </button>
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden w-12 h-12 rounded-2xl bg-brand-surface border border-brand-border flex items-center justify-center text-brand-text-secondary border-none cursor-pointer hover:text-brand-accent transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-[85px] left-4 right-4 bg-brand-surface/90 backdrop-blur-3xl border border-brand-border p-8 rounded-[2.5rem] flex flex-col gap-6 lg:hidden z-[100] shadow-2xl rtl"
          >
            {[
              { n: 'فروشگاه ایران', v: 'home' },
              { n: 'بلاگ تکنولوژی', v: 'blog' },
              { n: 'درباره ما', v: 'about' },
              { n: 'پنل مدیریت', v: 'admin', c: 'text-brand-accent' }
            ].map(item => (
              <button key={item.n} onClick={() => {setView(item.v as any); setMobileMenuOpen(false);}} className={`text-right text-xl font-black transition-colors border-none bg-transparent cursor-pointer ${item.c || 'text-brand-text-primary hover:text-brand-accent'}`}>{item.n}</button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );

  const HomeView = () => (
    <div className="flex flex-col gap-4 pb-20 rtl">
      {/* Search Header (Mobile-like) */}
      <div className="lg:hidden px-4 pt-2 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-brand-accent/20 flex items-center justify-center text-brand-accent font-black text-xs">IR</div>
          <span className="font-bold text-xs text-brand-text-primary">ایران استور</span>
        </div>
        <button onClick={() => setView('search')} className="p-2 rounded-xl bg-brand-surface border border-brand-border text-brand-text-secondary">
          <Search className="w-4 h-4" />
        </button>
      </div>

      {/* Snapp-style Wallet / Status Card */}
      <section className="px-4 md:px-12 pt-1">
        <div className="bg-gradient-to-br from-brand-accent/15 to-brand-surface border border-brand-accent/20 rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between shadow-lg backdrop-blur-md gap-4 overflow-hidden relative group">
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-14 h-14 bg-brand-bg/40 backdrop-blur-xl rounded-xl flex items-center justify-center text-2xl shadow-inner border border-white/5">
              💳
            </div>
            <div className="flex flex-col">
              <span className="text-[9px] font-bold text-brand-accent uppercase tracking-widest">اعتبار حساب</span>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-black text-brand-text-primary">۵۰۰,۰۰۰</span>
                <span className="text-[10px] font-bold text-brand-accent">تومان</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2 relative z-10 w-full md:w-auto">
            <button className="flex-1 px-5 py-2.5 bg-brand-accent text-brand-bg font-bold rounded-xl text-xs hover:brightness-110 active:scale-95 transition-all border-none cursor-pointer">شارژ سریع</button>
            <button className="flex-1 px-5 py-2.5 bg-brand-surface border border-brand-border text-brand-text-primary font-bold rounded-xl text-xs hover:bg-brand-bg/50 transition-all border-none cursor-pointer">تراکنش‌ها</button>
          </div>
        </div>
      </section>

      {/* Flash Sale Countdown */}
      <section className="px-4 md:px-12 pt-2">
        <div className="bg-rose-500/5 border border-rose-500/10 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-rose-500/10 text-rose-500 rounded-xl flex items-center justify-center shadow-lg shadow-rose-500/5">
              <Clock className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <h3 className="text-sm font-black text-brand-text-primary">فروش شگفت‌انگیز</h3>
              <p className="text-[9px] font-bold text-brand-text-secondary opacity-60">تخفیف‌های ویژه روزانه</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {[
              {v: '۱۲', l: 'ساعت'},
              {v: '۴۵', l: 'دقیقه'},
              {v: '۰۸', l: 'ثانیه'}
            ].map(t => (
              <div key={t.l} className="flex flex-col items-center">
                <div className="w-10 h-10 bg-brand-surface border border-brand-border rounded-lg flex items-center justify-center text-sm font-black text-rose-500">
                  {t.v}
                </div>
                <span className="text-[7px] font-bold text-brand-text-secondary mt-1">{t.l}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* circular categories */}
      <section className="px-4 md:px-12 grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-3 py-2">
        {[
          { name: 'موبایل', icon: Smartphone, color: 'bg-blue-500/10 text-blue-400' },
          { name: 'لپ‌تاپ', icon: Package, color: 'bg-emerald-500/10 text-emerald-400' },
          { name: 'صوتی', icon: Heart, color: 'bg-rose-500/10 text-rose-400' },
          { name: 'ساعت', icon: Clock, color: 'bg-amber-500/10 text-amber-400' },
          { name: 'گیمینگ', icon: ShieldCheck, color: 'bg-violet-500/10 text-violet-400' },
          { name: 'امنیت', icon: ShieldCheck, color: 'bg-sky-500/10 text-sky-400' },
          { name: 'خانه هوشمند', icon: Home, color: 'bg-orange-500/10 text-orange-400' },
          { name: 'تجهیزات', icon: Settings, color: 'bg-slate-500/10 text-slate-400' }
        ].map((item, i) => (
          <button key={i} className="flex flex-col items-center gap-1.5 group cursor-pointer border-none bg-transparent active:scale-95 transition-all">
            <div className={`w-12 h-12 rounded-2xl ${item.color} flex items-center justify-center border border-white/5 shadow-md group-hover:scale-110 transition-transform`}>
              <item.icon className="w-5 h-5" />
            </div>
            <span className="text-[9px] font-bold text-brand-text-secondary group-hover:text-brand-accent">{item.name}</span>
          </button>
        ))}
      </section>

      {/* Main Banner */}
      <section className="px-4 md:px-12">
        <div className="relative w-full aspect-[21/7] rounded-3xl overflow-hidden group shadow-lg border border-brand-border/50">
          <img 
            src={banners[0].image} 
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105 opacity-80" 
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-brand-bg/80 via-transparent to-transparent flex flex-col justify-center p-6 md:p-10 gap-3">
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <span className="px-2 py-0.5 bg-brand-accent text-brand-bg font-bold rounded-full text-[8px] uppercase tracking-widest inline-block">پیشنهاد ویژه</span>
              <h2 className="text-xl md:text-3xl font-black text-brand-text-primary leading-tight mt-1">{banners[0].title}</h2>
              <p className="text-brand-text-secondary text-[10px] md:text-sm max-w-xs mt-1">{banners[0].subtitle}</p>
            </motion.div>
            <button className="w-fit px-5 py-2 bg-brand-accent text-brand-bg font-bold rounded-xl hover:brightness-110 transition-all active:scale-95 text-xs border-none cursor-pointer mt-2">مشاهده</button>
          </div>
        </div>
      </section>

      {/* Featured Grid */}
      <section className="px-4 md:px-12 pt-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-black text-brand-text-primary flex items-center gap-2">
            <Star className="w-4 h-4 text-yellow-500" />
            محصولات منتخب
          </h2>
          <button onClick={() => setView('search')} className="text-brand-accent font-bold text-[10px] hover:underline border-none bg-transparent cursor-pointer">نمایش همه</button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.slice(0, 8).map((product) => (
            <motion.div
              key={product.id}
              layoutId={product.id}
              whileHover={{ y: -4 }}
              onClick={() => { setSelectedProduct(product); setView('product-detail'); }}
              className="bg-brand-surface border border-brand-border rounded-2xl p-3 flex flex-col gap-3 group cursor-pointer hover:border-brand-accent/50 transition-all relative overflow-hidden"
            >
              <div className="aspect-square bg-brand-bg rounded-xl overflow-hidden relative border border-white/5">
                <img src={product.image} className="w-full h-full object-cover group-hover:scale-110 transition-all duration-700" referrerPolicy="no-referrer" />
                <div className="absolute top-2 right-2 bg-brand-accent/80 backdrop-blur-md px-2 py-0.5 rounded-full text-[8px] font-bold text-brand-bg">
                  {product.category}
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <h3 className="font-bold text-xs text-brand-text-primary line-clamp-1 group-hover:text-brand-accent transition-colors">{product.title}</h3>
                <div className="flex items-center justify-between mt-1">
                  <span className="font-black text-xs text-brand-accent">{formatPrice(product.price)}</span>
                  <div className="flex items-center gap-0.5 text-yellow-500 text-[9px] font-bold">
                    <Star className="w-2.5 h-2.5 fill-current" />
                    {product.rating}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );

  const CheckoutView = () => {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({ name: '', phone: '', address: '', method: 'card' });

    if (cart.length === 0 && step < 4) return <div className="p-10 text-center text-brand-text-secondary font-black">سبد خرید شما خالی است</div>;

    const nextStep = () => setStep(s => s + 1);

    return (
      <div className="max-w-4xl mx-auto px-4 py-8 rtl">
        <div className="flex items-center justify-center gap-4 mb-8">
          {[1, 2, 3].map(i => (
            <div key={i} className={`flex items-center gap-2 ${step >= i ? 'text-brand-accent' : 'text-brand-text-secondary opacity-30'}`}>
              <div className={`w-8 h-8 rounded-full border flex items-center justify-center font-black text-xs ${step === i ? 'bg-brand-accent text-brand-bg' : 'border-current'}`}>{i}</div>
              <span className="text-[10px] font-black hidden sm:block">{i === 1 ? 'سبد' : i === 2 ? 'ارسال' : 'پرداخت'}</span>
              {i < 3 && <div className="w-4 h-px bg-current opacity-20" />}
            </div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col gap-4">
              <div className="bg-brand-surface border border-brand-border rounded-2xl p-6 flex flex-col gap-3">
                <h2 className="text-lg font-black text-brand-text-primary">بررسی سفارش</h2>
                {cart.map(item => (
                  <div key={item.id} className="flex items-center justify-between py-2 border-b border-brand-border last:border-0">
                    <div className="flex items-center gap-3">
                      <img src={item.image} className="w-12 h-12 rounded-lg object-cover" />
                      <div>
                        <h4 className="font-bold text-brand-text-primary text-xs">{item.title}</h4>
                        <span className="text-[10px] text-brand-text-secondary">{item.quantity} عدد</span>
                      </div>
                    </div>
                    <span className="font-black text-brand-accent text-sm">{formatPrice(item.price * item.quantity)}</span>
                  </div>
                ))}
                <div className="flex items-center justify-between pt-4">
                  <span className="text-sm font-black text-brand-text-secondary">جمع کل :</span>
                  <span className="text-xl font-black text-brand-accent">{formatPrice(cartTotal)}</span>
                </div>
              </div>
              <button onClick={nextStep} className="w-full py-4 bg-brand-accent text-brand-bg font-black rounded-xl text-lg hover:brightness-110 transition-all border-none cursor-pointer">ادامه فرآیند خرید</button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col gap-4">
              <div className="bg-brand-surface border border-brand-border rounded-2xl p-6 flex flex-col gap-4">
                <h2 className="text-lg font-black text-brand-text-primary">مشخصات تحویل‌گیرنده</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-black text-brand-text-secondary uppercase">نام کامل</label>
                    <input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="bg-brand-bg border border-brand-border p-3 rounded-lg outline-none text-xs text-brand-text-primary" placeholder="علی عباسی" />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-black text-brand-text-secondary uppercase">تلفن تماس</label>
                    <input value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="bg-brand-bg border border-brand-border p-3 rounded-lg outline-none text-xs text-brand-text-primary" placeholder="۰۹۱۲۰۰۰۰۰۰۰" />
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-black text-brand-text-secondary uppercase">آدرس دقیق</label>
                  <textarea rows={2} value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} className="bg-brand-bg border border-brand-border p-3 rounded-lg outline-none text-xs text-brand-text-primary resize-none" placeholder="استان، شهر، خیابان..." />
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setStep(1)} className="flex-1 py-4 bg-brand-surface border border-brand-border text-brand-text-primary font-black rounded-xl border-none cursor-pointer">بازگشت</button>
                <button onClick={nextStep} className="flex-[2] py-4 bg-brand-accent text-brand-bg font-black rounded-xl text-lg hover:brightness-110 transition-all border-none cursor-pointer">ثبت و انتخاب پرداخت</button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col gap-4">
              <div className="bg-brand-surface border border-brand-border rounded-2xl p-6 flex flex-col gap-4">
                <h2 className="text-lg font-black text-brand-text-primary">شیوه پرداخت</h2>
                <div className="grid grid-cols-1 gap-3">
                  {[
                    { id: 'card', name: 'کارت بانکی', desc: 'انتقال به درگاه امن', icon: CreditCard },
                    { id: 'wallet', name: 'کیف پول', desc: 'موجودی حساب شما', icon: ShoppingBag },
                    { id: 'crypto', name: 'ارز دیجیتال', desc: walletAddress ? `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}` : 'اتصال به کیف پول امن', icon: ShieldCheck }
                  ].map(m => (
                    <button 
                      key={m.id} 
                      disabled={walletLoading}
                      onClick={async () => {
                        if (m.id === 'crypto' && !walletAddress) {
                          const addr = await connectWallet();
                          if (!addr) {
                            // High-fidelity fallback for sandbox/iframe environments
                            const demoMode = confirm('در این محیط دسترسی به افزونه‌های مرورگر محدود است. آیا مایلید از حالت شبیه‌سازی امن (Safe Demo) برای تکمیل خرید استفاده کنید؟');
                            if (demoMode) {
                              const demoAddr = await connectWallet(true);
                              if (demoAddr) setFormData({...formData, method: m.id});
                            }
                          } else {
                            setFormData({...formData, method: m.id});
                          }
                        } else {
                          setFormData({...formData, method: m.id});
                        }
                      }} 
                      className={`flex items-center gap-4 p-4 rounded-xl border transition-all text-right border-none cursor-pointer relative overflow-hidden ${formData.method === m.id ? 'border-brand-accent bg-brand-accent/5 ring-2 ring-brand-accent/10' : 'border-brand-border bg-brand-bg/50 hover:border-brand-accent/50'} ${walletLoading && m.id === 'crypto' ? 'opacity-50' : ''}`}
                    >
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${formData.method === m.id ? 'bg-brand-accent text-brand-bg' : 'bg-brand-surface text-brand-text-secondary'}`}>
                        {walletLoading && m.id === 'crypto' ? (
                          <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <m.icon className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex flex-col opacity-80">
                        <span className="font-black text-xs text-brand-text-primary">{m.name}</span>
                        <span className="text-[10px] text-brand-text-secondary">{m.desc}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              <div className="bg-brand-accent/10 border border-brand-accent/20 p-5 rounded-2xl flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-[10px] text-brand-text-secondary font-black">مبلغ نهایی</span>
                  <span className="text-xl font-black text-brand-accent">{formatPrice(cartTotal)}</span>
                </div>
                <button onClick={() => { setCart([]); setView('success'); }} className="px-6 py-3 bg-brand-accent text-brand-bg font-black rounded-xl text-md hover:brightness-110 transition-all border-none cursor-pointer">تایید و پرداخت</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  const SuccessView = () => (
    <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex flex-col items-center justify-center py-20 gap-8 text-center rtl">
      <div className="w-20 h-20 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center shadow-lg border border-emerald-500/30">
        <CheckCircle2 className="w-12 h-12" />
      </div>
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-black text-brand-text-primary">سفارش شما ثبت شد!</h1>
        <p className="text-brand-text-secondary max-w-sm text-sm opacity-70">کد رهگیری: <span className="text-brand-accent font-black">IR-7729</span>. بزودی با شما تماس می‌گیریم.</p>
      </div>
      <button onClick={() => setView('home')} className="px-10 py-3 bg-brand-accent text-brand-bg font-black rounded-xl hover:brightness-110 transition-all border-none cursor-pointer">بازگشت به فروشگاه</button>
    </motion.div>
  );

  const ProductDetailView = () => {
    if (!selectedProduct) return null;
    const [activeImg, setActiveImg] = useState(selectedProduct.image);
    const [tab, setTab] = useState('desc'); // 'desc' | 'specs' | 'reviews'
    
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="px-4 md:px-10 py-6 rtl flex flex-col lg:flex-row gap-6 max-w-5xl mx-auto"
      >
        <div className="flex-1 flex flex-col gap-3">
          <div className="aspect-square rounded-2xl overflow-hidden bg-brand-surface border border-brand-border relative group shadow-sm">
            <img src={activeImg} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
            <button onClick={() => setView('home')} className="absolute top-4 right-4 w-10 h-10 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center text-white border-none cursor-pointer hover:bg-white/20 transition-all z-10">
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {[selectedProduct.image, ...(selectedProduct.images || [])].filter((v, i, a) => a.indexOf(v) === i).map((img, idx) => (
              <button key={idx} onClick={() => setActiveImg(img)} className={`w-14 h-14 rounded-lg overflow-hidden border transition-all border-none cursor-pointer ${activeImg === img ? 'border-brand-accent ring-2 ring-brand-accent/20' : 'border-brand-border opacity-50'}`}>
                <img src={img} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex flex-col gap-4 flex-1">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-brand-accent/10 text-brand-accent text-[8px] font-bold rounded-full uppercase tracking-widest">{selectedProduct.category}</span>
              <div className="flex items-center gap-0.5 text-yellow-500 bg-yellow-500/10 px-2 py-0.5 rounded-full text-[10px] font-bold">
                <Star className="w-3 h-3 fill-current" />
                {selectedProduct.rating}
              </div>
            </div>
            <h1 className="text-xl md:text-2xl font-black text-brand-text-primary leading-tight">{selectedProduct.title}</h1>
          </div>
          
          <div className="flex border-b border-brand-border gap-6 overflow-x-auto pb-px">
            {['desc', 'specs', 'reviews'].map(t => (
              <button key={t} onClick={() => setTab(t)} className={`pb-2 text-[10px] font-bold transition-all border-none bg-transparent cursor-pointer relative ${tab === t ? 'text-brand-accent' : 'text-brand-text-secondary opacity-50 hover:opacity-100'}`}>
                {t === 'desc' ? 'توضیحات' : t === 'specs' ? 'مشخصات' : 'نظرات'}
                {tab === t && <motion.div layoutId="detail-tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-accent rounded-full" />}
              </button>
            ))}
          </div>

          <div className="min-h-[120px] py-3">
            <AnimatePresence mode="wait">
              {tab === 'desc' && (
                <motion.p key="desc" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} className="text-brand-text-secondary text-xs font-medium leading-[1.8]">
                  {selectedProduct.description}
                </motion.p>
              )}
              {tab === 'specs' && (
                <motion.div key="specs" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} className="grid grid-cols-1 gap-2">
                  {[
                    { k: 'گارانتی', v: '۲۴ ماه طلایی' },
                    { k: 'خدمات', v: 'پشتیبانی ۱۰ ساله' },
                    { k: 'بدنه', v: 'آلومینیوم' }
                  ].map(s => (
                    <div key={s.k} className="flex items-center justify-between border-b border-brand-border/30 pb-1.5">
                      <span className="text-brand-text-secondary font-bold text-[10px]">{s.k}</span>
                      <span className="text-brand-text-primary font-black text-xs">{s.v}</span>
                    </div>
                  ))}
                </motion.div>
              )}
              {tab === 'reviews' && (
                <motion.div key="reviews" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} className="flex flex-col gap-2">
                  {[
                    { u: 'امیرحسین', r: 'فوق العاده است.', s: 5 },
                    { u: 'سارا', r: 'کیفیت عالی.', s: 4 }
                  ].map((r, i) => (
                    <div key={i} className="bg-brand-surface/30 p-3 rounded-xl border border-brand-border">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-[10px] text-brand-text-primary">{r.u}</span>
                        <div className="flex gap-0.5 text-yellow-500">
                          {Array.from({length: 5}).map((_, j) => <Star key={j} className={`w-2 h-2 ${j < r.s ? 'fill-current' : 'opacity-20'}`} />)}
                        </div>
                      </div>
                      <p className="text-[9px] text-brand-text-secondary leading-relaxed">{r.r}</p>
                    </div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="p-4 rounded-2xl bg-brand-surface border border-brand-border flex items-center justify-between shadow-sm sticky bottom-3 z-20">
            <div className="flex flex-col">
              <span className="text-[7px] font-bold text-brand-text-secondary/50 uppercase">قیمت کل</span>
              <span className="text-lg font-black text-brand-accent">{formatPrice(selectedProduct.price)}</span>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => { addToCart(selectedProduct); setView('checkout'); }} 
                className="px-6 py-2 bg-brand-accent text-brand-bg font-bold rounded-lg text-xs hover:brightness-110 active:scale-95 transition-all border-none cursor-pointer"
              >
                خرید آنلاین
              </button>
              <button className="w-10 h-10 flex items-center justify-center bg-brand-bg border border-brand-border text-rose-500 rounded-lg hover:bg-rose-500/10 transition-all border-none cursor-pointer">
                <Heart className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  const CartSheet = () => (
    <AnimatePresence>
      {cartOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            onClick={() => setCartOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100]"
          />
          <motion.div 
            initial={{ y: '100%' }} 
            animate={{ y: 0 }} 
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 max-w-2xl mx-auto h-[85vh] bg-brand-surface border-t border-brand-border rounded-t-[3rem] shadow-2xl z-[101] p-8 flex flex-col gap-6 rtl shadow-[0_-20px_60px_rgba(0,0,0,0.5)]"
          >
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-2xl font-black text-brand-text-primary flex items-center gap-3">
                <ShoppingBag className="w-8 h-8 text-brand-accent" />
                سبد خرید شما
              </h2>
              <button onClick={() => setCartOpen(false)} className="w-10 h-10 rounded-full hover:bg-brand-bg transition-all flex items-center justify-center text-brand-text-secondary border-none bg-transparent cursor-pointer">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto px-1 flex flex-col gap-4">
              {cart.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center gap-6 opacity-30">
                  <ShoppingBag className="w-24 h-24" />
                  <p className="text-xl font-bold">سبد خرید شما فعلاً خالی است</p>
                  <button 
                    onClick={() => {setCartOpen(false); setView('home');}}
                    className="px-8 py-3 bg-brand-accent/10 border border-brand-accent text-brand-accent rounded-xl font-black border-none cursor-pointer"
                  >
                    بزن بریم خرید
                  </button>
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.id} className="bg-brand-bg/50 border border-brand-border p-4 rounded-3xl flex items-center gap-4 group">
                    <div className="w-20 h-20 rounded-2xl overflow-hidden bg-brand-surface flex-shrink-0">
                      <img src={item.image} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-brand-text-primary truncate">{item.title}</h4>
                      <p className="text-xs text-brand-text-secondary mt-1">{formatPrice(item.price)}</p>
                      <div className="flex items-center gap-4 mt-2">
                        <div className="flex items-center bg-brand-surface border border-brand-border rounded-lg px-2">
                          <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:text-brand-accent text-brand-text-secondary transition-colors cursor-pointer border-none bg-transparent">
                            <Plus className="w-4 h-4" />
                          </button>
                          <span className="w-8 text-center text-sm font-black text-brand-text-primary">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:text-brand-accent text-brand-text-secondary transition-colors cursor-pointer border-none bg-transparent">
                            <PlusCircle className="w-4 h-4 rotate-45" />
                          </button>
                        </div>
                      </div>
                    </div>
                    <button onClick={() => removeFromCart(item.id)} className="w-10 h-10 bg-rose-500/10 text-rose-500 rounded-xl flex items-center justify-center hover:bg-rose-500 hover:text-white transition-all border-none cursor-pointer">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="bg-brand-surface shadow-2xl p-6 rounded-[2rem] border border-brand-border mt-auto">
              <div className="flex justify-between items-center mb-6">
                <div className="flex flex-col">
                  <span className="text-brand-text-secondary text-sm">مبلغ قابل پرداخت</span>
                  <span className="text-2xl font-black text-brand-accent">{formatPrice(cartTotal)}</span>
                </div>
                <button 
                  disabled={cart.length === 0}
                  onClick={() => { setCartOpen(false); setView('checkout'); }}
                  className="px-10 py-4 bg-brand-text-primary text-brand-bg font-black rounded-2xl text-lg hover:bg-brand-accent transition-all active:scale-95 disabled:opacity-30 border-none cursor-pointer shadow-[0_10px_20px_rgba(45,212,191,0.2)]"
                >
                  ثبت نهایی سفارش
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );

  const AccountView = () => {
    const [phone, setPhone] = useState(user.phone);
    const [editing, setEditing] = useState(false);

    const handleSave = () => {
      setUser(prev => ({ ...prev, phone }));
      setEditing(false);
    };

    return (
      <div className="max-w-4xl mx-auto px-4 py-12 rtl flex flex-col gap-10">
        <header className="flex flex-col items-center gap-6 bg-gradient-to-br from-brand-accent/10 to-transparent p-10 rounded-[3rem] border border-brand-accent/20 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4">
            <Settings className="w-6 h-6 text-brand-accent opacity-30 cursor-pointer" />
          </div>
          <div className="relative group">
            <div className="w-32 h-32 rounded-full border-4 border-brand-accent overflow-hidden shadow-2xl transition-transform group-hover:scale-105">
              <img src={user.avatar} className="w-full h-full object-cover" />
            </div>
            <button className="absolute bottom-1 right-1 bg-brand-accent w-10 h-10 rounded-full flex items-center justify-center text-brand-bg shadow-xl border-none cursor-pointer hover:scale-110 transition-all">
              <ImageIcon className="w-6 h-6" />
            </button>
          </div>
          <div className="text-center">
            <h1 className="text-3xl font-black text-brand-text-primary">{user.name}</h1>
            <p className="text-brand-text-secondary font-black opacity-50 mt-1">عضو طلایی ایران استور</p>
          </div>
        </header>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'سفارشات جاری', val: '۳', icon: ShoppingBag, color: 'text-blue-400' },
            { label: 'کیف پول', val: '۵۰۰ ت', icon: CreditCard, color: 'text-emerald-400' },
            { label: 'علاقه‌مندی', val: '۱۲', icon: Heart, color: 'text-rose-400' },
            { label: 'امتیاز من', val: '۴۵۰', icon: Star, color: 'text-amber-400' }
          ].map((stat, i) => (
            <div key={i} className="bg-brand-surface border border-brand-border p-6 rounded-3xl flex flex-col items-center gap-2 hover:bg-brand-accent/5 transition-all">
              <stat.icon className={`w-8 h-8 ${stat.color}`} />
              <span className="text-xl font-black text-brand-text-primary">{stat.val}</span>
              <span className="text-[10px] font-bold text-brand-text-secondary uppercase tracking-widest">{stat.label}</span>
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-6">
          <h2 className="text-2xl font-black text-brand-text-primary">اطلاعات حساب کاربر</h2>
          <div className="bg-brand-surface border border-brand-border rounded-[2.5rem] p-8 flex flex-col gap-6">
            <div className="flex flex-col md:flex-row items-center justify-between border-b border-brand-border pb-6 last:border-0 last:pb-0 gap-6">
              <div className="flex items-center gap-4 w-full">
                <div className="w-12 h-12 bg-brand-accent/10 rounded-2xl flex items-center justify-center text-brand-accent"><Smartphone className="w-6 h-6" /></div>
                <div className="flex flex-col w-full">
                  <span className="text-xs text-brand-text-secondary font-bold">شماره موبایل ایران</span>
                  {editing ? (
                    <input value={phone} onChange={e => setPhone(e.target.value)} className="bg-brand-bg p-4 rounded-xl border border-brand-border outline-none focus:border-brand-accent text-brand-text-primary font-black w-full" />
                  ) : (
                    <span className="font-black text-xl text-brand-text-primary">{user.phone}</span>
                  )}
                </div>
              </div>
              <button onClick={() => { if(editing) handleSave(); else setEditing(true); }} className="w-full md:w-auto px-10 py-4 bg-brand-accent/10 text-brand-accent font-black rounded-xl hover:bg-brand-accent hover:text-brand-bg transition-all border-none cursor-pointer">
                {editing ? 'ذخیره' : 'ویرایش شماره'}
              </button>
            </div>
          </div>
        </div>

        {user.isAdmin && (
           <div className="flex flex-col gap-4">
             <button onClick={() => setView('admin')} className="w-full py-6 bg-gradient-to-r from-brand-accent to-brand-text-primary text-brand-bg font-black rounded-[2rem] text-xl flex items-center justify-center gap-4 hover:brightness-110 active:scale-95 transition-all shadow-2xl border-none cursor-pointer uppercase tracking-tighter">
               <LayoutDashboard className="w-8 h-8" />
               ورود به پنل مدیریت پیشرفته
             </button>
           </div>
        )}
      </div>
    );
  };

  const AdminView = () => {
    const [tab, setTab] = useState<'products' | 'banners' | 'blogs'>('products');
    const [newP, setNewP] = useState({ title: '', price: '', category: 'الکترونیک' });

    const handleAdd = (e: FormEvent) => {
      e.preventDefault();
      if (!newP.title || !newP.price) return;
      addProduct({
        id: Math.random().toString(),
        title: newP.title,
        price: Number(newP.price),
        category: newP.category,
        description: 'محصول جدید اضافه شده توسط مدیر سیستم.',
        image: `https://picsum.photos/seed/${Math.random()}/600/600`,
        rating: 5.0,
        reviews: 0
      });
      setNewP({ title: '', price: '', category: 'الکترونیک' });
      alert('محصول با موفقیت اضافه شد!');
    };
    
    return (
      <div className="px-4 md:px-12 py-10 rtl flex flex-col gap-10">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <h1 className="text-4xl font-black text-brand-text-primary flex items-center gap-4">
            <div className="w-12 h-12 bg-brand-accent rounded-2xl flex items-center justify-center text-brand-bg shadow-lg">
              <LayoutDashboard className="w-7 h-7" />
            </div>
            مدیریت فروشگاه ایران
          </h1>
          <div className="flex items-center bg-brand-surface p-1 rounded-2xl border border-brand-border">
            {['products', 'banners', 'blogs'].map((t) => (
              <button 
                key={t}
                onClick={() => setTab(t as any)}
                className={`px-6 py-3 rounded-xl text-sm font-black transition-all border-none cursor-pointer ${tab === t ? 'bg-brand-accent text-brand-bg shadow-xl' : 'text-brand-text-secondary hover:text-brand-accent'}`}
              >
                {t === 'products' ? 'محصولات' : t === 'banners' ? 'بنرها' : 'مقالات'}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'فروش امروز', val: '۱۲.۵ م', icon: CreditCard, color: 'text-emerald-500' },
            { label: 'سفارشات جدید', val: '۴۸', icon: ShoppingBag, color: 'text-blue-500' },
            { label: 'کاربران آنلاین', val: '۱۲۴', icon: User, color: 'text-amber-500' },
            { label: 'بازدید کل', val: '۱۵.۲ ک', icon: Star, color: 'text-rose-500' }
          ].map((stat, i) => (
            <div key={i} className="bg-brand-surface border border-brand-border p-6 rounded-[2rem] flex flex-col gap-2 hover:border-brand-accent transition-all">
              <div className="flex items-center justify-between">
                <stat.icon className={`w-8 h-8 ${stat.color}`} />
                <span className="text-xs font-black text-brand-text-secondary opacity-50">امروز</span>
              </div>
              <span className="text-2xl font-black text-brand-text-primary mt-2">{stat.val}</span>
              <span className="text-[10px] font-bold text-brand-text-secondary uppercase">{stat.label}</span>
            </div>
          ))}
        </div>

        <section className="bg-brand-surface border border-brand-border rounded-[3rem] p-10 shadow-2xl min-h-[500px]">
          {tab === 'products' && (
             <form onSubmit={handleAdd} className="flex flex-col gap-8">
               <div className="flex items-center justify-between border-b border-brand-border pb-6">
                 <h2 className="text-xl font-bold flex items-center gap-3">
                   <PlusCircle className="w-6 h-6 text-brand-accent" />
                   ایجاد محصول جدید
                 </h2>
               </div>
               <div className="grid md:grid-cols-3 gap-6">
                 <div className="flex flex-col gap-2">
                   <label className="text-[10px] font-black uppercase text-brand-text-secondary">نام محصول</label>
                   <input 
                    value={newP.title}
                    onChange={(e) => setNewP({...newP, title: e.target.value})}
                    className="bg-brand-bg border border-brand-border p-4 rounded-xl outline-none text-brand-text-primary" 
                    placeholder="مثلاً: گوشی موبایل" 
                   />
                 </div>
                 <div className="flex flex-col gap-2">
                   <label className="text-[10px] font-black uppercase text-brand-text-secondary">قیمت (تومان)</label>
                   <input 
                    value={newP.price}
                    onChange={(e) => setNewP({...newP, price: e.target.value})}
                    className="bg-brand-bg border border-brand-border p-4 rounded-xl outline-none text-brand-text-primary" 
                    placeholder="۲,۰۰۰,۰۰۰" 
                   />
                 </div>
                 <div className="flex flex-col gap-2">
                   <label className="text-[10px] font-black uppercase text-brand-text-secondary">دسته بندی</label>
                   <select 
                    value={newP.category}
                    onChange={(e) => setNewP({...newP, category: e.target.value})}
                    className="bg-brand-bg border border-brand-border p-4 rounded-xl outline-none text-brand-text-secondary"
                   >
                     <option>ماشین</option>
                     <option>الکترونیک</option>
                     <option>موبایل</option>
                   </select>
                 </div>
               </div>
               <button type="submit" className="py-4 bg-brand-accent text-brand-bg font-black rounded-2xl hover:brightness-110 active:scale-95 transition-all border-none cursor-pointer">تایید و انتشار محصول</button>
             </form>
          )}
          
          {tab === 'banners' && (
            <div className="flex flex-col gap-8">
               <div className="flex items-center justify-between border-b border-brand-border pb-6">
                 <h2 className="text-xl font-bold flex items-center gap-3">
                   <ImageIcon className="w-6 h-6 text-brand-accent" />
                   مدیریت بنرهای اسلایدر
                 </h2>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {banners.map(b => (
                   <div key={b.id} className="relative aspect-video rounded-3xl overflow-hidden border border-brand-border group">
                     <img src={b.image} className="w-full h-full object-cover opacity-50 transition-all group-hover:opacity-100" referrerPolicy="no-referrer" />
                     <div className="absolute inset-0 flex flex-col justify-end p-6 bg-gradient-to-t from-brand-bg to-transparent">
                       <h4 className="font-black text-xl">{b.title}</h4>
                       <button className="absolute top-4 right-4 text-rose-500 bg-brand-bg/80 p-2 rounded-xl hover:bg-rose-500 hover:text-white transition-all border-none cursor-pointer">
                         <Trash2 className="w-5 h-5" />
                       </button>
                     </div>
                   </div>
                 ))}
                 <div className="aspect-video rounded-3xl border-2 border-dashed border-brand-border flex items-center justify-center hover:border-brand-accent transition-all cursor-pointer group">
                   <div className="flex flex-col items-center gap-2 text-brand-text-secondary group-hover:text-brand-accent">
                     <Plus className="w-10 h-10" />
                     <span className="font-bold">افزودن بنر جدید</span>
                   </div>
                 </div>
               </div>
            </div>
          )}
        </section>
      </div>
    );
  };

  const BlogView = () => (
    <div className="px-4 md:px-12 py-12 rtl flex flex-col gap-12">
      <div className="flex flex-col items-center gap-4 text-center">
        <span className="px-6 py-2 bg-brand-accent/10 text-brand-accent rounded-full text-xs font-black uppercase tracking-widest">مجله خبری</span>
        <h1 className="text-5xl font-black text-brand-text-primary">ایران پدیا</h1>
        <p className="text-brand-text-secondary max-w-xl text-lg">آخرین اخبار دنیای تکنولوژی، راهنمای خرید و نقد و بررسی محصولات دیجیتال را در اینجا بخوانید.</p>
      </div>
      
      <div className="grid md:grid-cols-3 gap-8">
        {blogs.map(post => (
          <div key={post.id} className="bg-brand-surface border border-brand-border rounded-[2.5rem] overflow-hidden group hover:border-brand-accent transition-all">
            <div className="aspect-video relative overflow-hidden">
              <img src={post.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" referrerPolicy="no-referrer" />
              <div className="absolute top-4 right-4 bg-brand-accent text-brand-bg px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">تکنولوژی</div>
            </div>
            <div className="p-8 flex flex-col gap-4">
              <div className="flex items-center gap-4 text-xs font-bold text-brand-text-secondary opacity-50">
                <Clock className="w-4 h-4" />
                {post.date}
              </div>
              <h3 className="text-2xl font-black text-brand-text-primary group-hover:text-brand-accent transition-colors">{post.title}</h3>
              <p className="text-brand-text-secondary leading-relaxed line-clamp-3">{post.excerpt}</p>
              <button className="w-fit p-0 bg-transparent border-none text-brand-accent font-black text-sm flex items-center gap-2 hover:gap-4 transition-all cursor-pointer">
                ادامه مطالعه مقاله
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const SearchView = () => (
    <div className="px-4 md:px-12 py-10 rtl flex flex-col gap-8 min-h-[70vh]">
      <div className="flex flex-col gap-4">
        <h2 className="text-3xl font-black text-brand-text-primary">جستجوی هوشمند</h2>
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-brand-accent" />
          <input 
            autoFocus
            type="text" 
            placeholder="نام کالا یا دسته‌بندی را بنویسید..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-brand-surface border border-brand-border rounded-2xl pr-12 pl-4 py-4 text-lg focus:border-brand-accent outline-none text-brand-text-primary"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {products.filter(p => !searchQuery || p.title.includes(searchQuery)).map(product => (
          <div 
            key={product.id} 
            onClick={() => { setSelectedProduct(product); setView('product-detail'); }}
            className="bg-brand-surface border border-brand-border rounded-2xl p-2 cursor-pointer hover:border-brand-accent transition-all group"
          >
            <div className="aspect-square rounded-xl overflow-hidden mb-2 bg-brand-bg">
              <img src={product.image} className="w-full h-full object-cover group-hover:scale-110 transition-all" referrerPolicy="no-referrer" />
            </div>
            <h4 className="text-xs font-bold text-brand-text-primary line-clamp-1">{product.title}</h4>
            <span className="text-[10px] text-brand-accent block mt-1">{formatPrice(product.price)}</span>
          </div>
        ))}
      </div>
    </div>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-brand-bg flex items-center justify-center rtl">
        <div className="flex flex-col items-center gap-6">
          <div className="w-16 h-16 border-4 border-brand-accent border-t-transparent rounded-full animate-spin shadow-[0_0_20px_rgba(45,212,191,0.3)]" />
          <span className="text-brand-text-secondary font-black text-sm tracking-widest animate-pulse">در حال دریافت اطلاعات فروشگاه...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-bg flex flex-col selection:bg-brand-accent selection:text-brand-bg font-sans bg-[radial-gradient(circle_at_top_right,_rgba(45,212,191,0.05),_transparent_40%),_radial-gradient(circle_at_bottom_left,_rgba(45,212,191,0.05),_transparent_40%)]">
      {/* PWA Meta Tags (Injected via Helmet/Standard React usually, here just as markers) */}
      <Navbar />
      
      <main className="flex-1 overflow-x-hidden">
        <AnimatePresence mode="wait">
          {view === 'home' && (
            <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <HomeView />
            </motion.div>
          )}
          {view === 'product-detail' && (
            <motion.div key="product" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}>
              <ProductDetailView />
            </motion.div>
          )}
          {view === 'account' && (
            <motion.div key="account" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <AccountView />
            </motion.div>
          )}
          {view === 'admin' && (
            <motion.div key="admin" initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ opacity: 0 }}>
              <AdminView />
            </motion.div>
          )}
          {view === 'search' && (
            <motion.div key="search" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <SearchView />
            </motion.div>
          )}
          {view === 'checkout' && (
            <motion.div key="checkout" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <CheckoutView />
            </motion.div>
          )}
          {view === 'success' && (
            <motion.div key="success" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <SuccessView />
            </motion.div>
          )}
          {view === 'blog' && (
            <motion.div key="blog" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <BlogView />
            </motion.div>
          )}
          {view === 'about' && (
            <motion.div key="about" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="max-w-4xl mx-auto px-4 py-24 rtl text-center flex flex-col gap-8">
                <h1 className="text-6xl font-black text-brand-text-primary">درباره فروشگاه ایران</h1>
                <p className="text-brand-text-secondary text-xl leading-relaxed">فروشگاه ایران با هدف ارائه بهترین و باکیفیت‌ترین محصولات دیجیتال با قیمتی رقابتی در سال ۱۴۰۳ تاسیس گردید. ما مفتخریم که با تیمی متخصص، تجربه‌ای متفاوت از خرید آنلاین را برای شما رقم بزنیم.</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                   {[
                     { label: 'مشتری راضی', val: '۱۰,۰۰۰+' },
                     { label: 'محصول فعال', val: '۱,۵۰۰+' },
                     { label: 'ارسال ماهانه', val: '۵,۰۰۰+' },
                     { label: 'سال سابقه', val: '۱۰+' },
                   ].map(st => (
                     <div key={st.label} className="bg-brand-surface border border-brand-border p-6 rounded-3xl">
                       <span className="text-3xl font-black text-brand-accent tracking-tighter">{st.val}</span>
                       <p className="text-[10px] uppercase font-black text-brand-text-secondary mt-1">{st.label}</p>
                     </div>
                   ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <CartSheet />

      <footer className="bg-brand-surface border-t border-brand-border pt-12 pb-8 px-4 md:px-12 rtl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-brand-accent/20 rounded-2xl flex items-center justify-center text-brand-accent shadow-lg text-2xl font-black">IR</div>
              <h4 className="text-2xl font-black text-brand-text-primary">ایران استور</h4>
            </div>
            <p className="text-brand-text-secondary text-sm leading-7">مرکز تخصصی فروش محصولات دیجیتال در کشور با پشتیبانی ۲۴ ساعته و ارسال فوق سریع.</p>
            <div className="flex gap-4">
              <button className="w-10 h-10 rounded-xl bg-brand-bg border border-brand-border flex items-center justify-center text-brand-text-secondary hover:text-brand-accent transition-all cursor-pointer border-none bg-transparent"><Smartphone className="w-5 h-5" /></button>
              <button className="w-10 h-10 rounded-xl bg-brand-bg border border-brand-border flex items-center justify-center text-brand-text-secondary hover:text-brand-accent transition-all cursor-pointer border-none bg-transparent"><Smartphone className="w-5 h-5" /></button>
            </div>
          </div>
          <div className="flex flex-col gap-6">
            <h5 className="text-lg font-black text-brand-text-primary">دسترسی سریع</h5>
            <ul className="flex flex-col gap-4 text-sm font-bold text-brand-text-secondary list-none p-0">
              <li className="hover:text-brand-accent transition-all cursor-pointer" onClick={() => setView('home')}>صفحه اصلی</li>
              <li className="hover:text-brand-accent transition-all cursor-pointer" onClick={() => setView('blog')}>وبلاگ اخبار</li>
              <li className="hover:text-brand-accent transition-all cursor-pointer" onClick={() => setView('about')}>راهنمای خرید</li>
              <li className="hover:text-brand-accent transition-all cursor-pointer">سوالات متداول</li>
            </ul>
          </div>
          <div className="flex flex-col gap-6">
            <h5 className="text-lg font-black text-brand-text-primary">ارتباط با ما</h5>
            <div className="flex flex-col gap-4 text-sm font-bold text-brand-text-secondary">
              <p className="flex items-center gap-3"><Smartphone className="w-5 h-5 text-brand-accent opacity-50" /> ۰۲۱ - ۴۴۰۰۰۰۰۰</p>
              <p className="flex items-center gap-3"><Smartphone className="w-5 h-5 text-brand-accent opacity-50" /> info@iranstore.com</p>
              <p className="leading-relaxed opacity-60">تهران، سعادت آباد، برج تجارت ایران، طبقه ۱۰</p>
            </div>
          </div>
          <div className="flex flex-col gap-6">
            <h5 className="text-lg font-black text-brand-text-primary">نماد اعتماد</h5>
            <div className="flex gap-4">
              <div className="w-24 h-24 bg-white rounded-3xl p-3 flex items-center justify-center shadow-lg relative group overflow-hidden">
                <img src="https://trustseal.enamad.ir/Content/Images/Logo.png" className="w-full opacity-30 group-hover:opacity-100 transition-opacity" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 border-2 border-brand-accent/0 group-hover:border-brand-accent transition-all rounded-3xl" />
              </div>
              <div className="w-24 h-24 bg-white rounded-3xl p-3 flex items-center justify-center shadow-lg relative group overflow-hidden">
                <ShieldCheck className="w-12 h-12 text-brand-bg opacity-20" />
                <div className="absolute inset-0 border-2 border-brand-accent/0 group-hover:border-brand-accent transition-all rounded-3xl" />
              </div>
            </div>
          </div>
        </div>
        <div className="pt-8 border-t border-brand-border flex flex-col md:flex-row justify-between items-center gap-6 text-brand-text-secondary text-[10px] font-black tracking-widest uppercase">
          <p>© ۲۰۲۶ تمامی حقوق برای فروشگاه ایران محفوظ است</p>
          <div className="flex gap-8">
            <span className="hover:text-brand-accent cursor-pointer transition-colors">شرایط و قوانین</span>
            <span className="hover:text-brand-accent cursor-pointer transition-colors">حریم خصوصی</span>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-[70] bg-brand-surface/95 backdrop-blur-xl border-t border-brand-border flex justify-around p-2 lg:hidden rtl shadow-lg">
        <button onClick={() => setView('home')} className={`flex flex-col items-center gap-0.5 transition-colors border-none bg-transparent cursor-pointer ${view === 'home' ? 'text-brand-accent' : 'text-brand-text-secondary'}`}>
          <Home className="w-5 h-5" />
          <span className="text-[9px] font-bold">خانه</span>
        </button>
        <button onClick={() => setView('search')} className={`flex flex-col items-center gap-0.5 transition-colors border-none bg-transparent cursor-pointer ${view === 'search' ? 'text-brand-accent' : 'text-brand-text-secondary'}`}>
          <Search className="w-5 h-5" />
          <span className="text-[9px] font-bold">جستجو</span>
        </button>
        <button className="flex flex-col items-center gap-0.5 transition-colors border-none bg-transparent cursor-pointer text-brand-text-secondary">
          <Info className="w-5 h-5" />
          <span className="text-[9px] font-bold">پشتیبانی</span>
        </button>
        <button onClick={() => setCartOpen(true)} className={`flex flex-col items-center gap-0.5 transition-colors border-none bg-transparent cursor-pointer text-brand-text-secondary`}>
          <div className="relative">
            <ShoppingBag className="w-5 h-5" />
            {cart.length > 0 && <span className="absolute -top-1 -left-1 bg-brand-accent text-brand-bg text-[7px] w-2.5 h-2.5 rounded-full flex items-center justify-center font-black">{cart.length}</span>}
          </div>
          <span className="text-[9px] font-bold">سبد</span>
        </button>
        <button onClick={() => setView('account')} className={`flex flex-col items-center gap-0.5 transition-colors border-none bg-transparent cursor-pointer ${view === 'account' ? 'text-brand-accent' : 'text-brand-text-secondary'}`}>
          <User className="w-5 h-5" />
          <span className="text-[9px] font-bold">من</span>
        </button>
      </nav>
    </div>
  );
}
