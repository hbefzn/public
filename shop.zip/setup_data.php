<?php
$dataFile = __DIR__ . '/data.json';
if (!file_exists($dataFile)) {
    file_put_contents($dataFile, json_encode([
        "products" => [
            ["id" => "1", "title" => "لپ‌تاپ ایسوس ROG", "price" => 85000000, "image" => "https://picsum.photos/seed/p1/400/400", "category" => "لپ‌تاپ", "rating" => 4.8, "description" => "قدرتمند برای گیمینگ"],
            ["id" => "2", "title" => "گوشی سامسونگ S24", "price" => 65000000, "image" => "https://picsum.photos/seed/p2/400/400", "category" => "موبایل", "rating" => 4.9, "description" => "پرچمدار جدید"]
        ],
        "banners" => [
            ["id" => "b1", "image" => "https://picsum.photos/seed/b1/1200/400", "title" => "جشنواره ویژه نوروز", "subtitle" => "تا ۴۰ درصد تخفیف دیجیتال"]
        ]
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}
?>
