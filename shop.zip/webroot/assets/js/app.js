/**
 * Iran Store App Logic (Vanilla JS)
 * Fully functional with routing, admin, and checkout
 */

let products = [];
let banners = [];
let blogs = [];
let cart = JSON.parse(localStorage.getItem('cart') || '[]');
let currentStep = 1;

let orders = [];

async function init() {
    try {
        const response = await fetch('api.php');
        const data = await response.json();
        products = data.products || [];
        banners = data.banners || [];
        blogs = data.blogs || [];
        orders = data.orders || [];
        renderBanners();
        renderProducts();
        renderBlogs();
        updateCartUI();
    } catch (e) {
        console.error('Error loading data:', e);
    }
}

function renderBanners() {
    const bannerEl = document.getElementById('hero-banner');
    if (!banners || banners.length === 0) {
        bannerEl.innerHTML = '';
        return;
    }
    bannerEl.innerHTML = `
        <div style="position: relative; border-radius: 30px; overflow: hidden; height: 350px;">
            <img src="${banners[0].image}" style="width: 100%; height: 100%; object-fit: cover; opacity: 0.6;">
            <div style="position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: center; padding: 50px;">
                <h1 style="font-size: 2.5rem; font-weight: 900;">${banners[0].title}</h1>
                <p style="color: var(--brand-text-secondary);">${banners[0].subtitle}</p>
                <button class="btn-accent" style="width: fit-content; margin-top: 20px;">مشاهده جشنواره</button>
            </div>
        </div>
    `;
}

// Navigation / Routing
function showView(viewId) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
    const target = document.getElementById(viewId + '-view');
    if (target) {
        target.classList.add('active');
        window.scrollTo(0, 0);
        if (viewId === 'admin') renderAdminLists();
    }
}

// Admin Tab Logic
function setAdminTab(tab) {
    document.querySelectorAll('.admin-tab').forEach(el => el.style.display = 'none');
    document.getElementById('admin-' + tab + '-tab').style.display = 'block';
}

function renderAdminLists() {
    const pList = document.getElementById('admin-product-list');
    pList.innerHTML = products.map(p => `
        <div style="display:flex; justify-content:space-between; align-items:center; background:var(--brand-bg); padding:10px; border-radius:10px;">
            <span style="font-size:0.8rem;">${p.title}</span>
            <button onclick="handleAdminDeleteProduct('${p.id}')" style="background:none; border:none; color:#f43f5e; cursor:pointer;">حذف</button>
        </div>
    `).join('');

    const bList = document.getElementById('admin-banner-list');
    bList.innerHTML = banners.map(b => `
        <div style="display:flex; justify-content:space-between; align-items:center; background:var(--brand-bg); padding:10px; border-radius:10px;">
            <span style="font-size:0.8rem;">${b.title}</span>
            <button onclick="handleAdminDeleteBanner('${b.id}')" style="background:none; border:none; color:#f43f5e; cursor:pointer;">حذف</button>
        </div>
    `).join('');
}

async function handleAdminAddBanner() {
    const newB = {
        id: 'b' + Date.now(),
        title: document.getElementById('adm-b-title').value,
        subtitle: document.getElementById('adm-b-subtitle').value,
        image: document.getElementById('adm-b-img').value
    };
    banners.push(newB);
    await saveToBackend();
    renderBanners();
    renderAdminLists();
    alert('بنر اضافه شد');
}

async function handleAdminDeleteProduct(id) {
    products = products.filter(p => p.id !== id);
    await saveToBackend();
    renderProducts();
    renderAdminLists();
}

async function handleAdminDeleteBanner(id) {
    banners = banners.filter(b => b.id !== id);
    await saveToBackend();
    renderBanners();
    renderAdminLists();
}

// Search Logic
function handleSearch(query) {
    const results = products.filter(p => p.title.includes(query) || p.category.includes(query));
    renderSearchResults(results);
}

function renderSearchResults(results) {
    const list = document.getElementById('search-results');
    list.innerHTML = results.map(p => createProductCardHTML(p)).join('');
    if (window.lucide) window.lucide.createIcons();
}

// Rendering Helpers
function createProductCardHTML(p) {
    return `
        <div class="product-card" onclick="showProductDetail('${p.id}')">
            <div style="position: relative;">
                <img src="${p.image}" class="product-img">
                <div style="position: absolute; top: 8px; left: 8px; background: var(--brand-accent); color: var(--brand-bg); padding: 4px 8px; border-radius: 8px; font-size: 10px; font-weight: bold;">
                    ${p.category}
                </div>
            </div>
            <h3 style="font-size: 0.95rem; font-weight: bold; margin: 12px 0 8px 0;">${p.title}</h3>
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <span style="color: var(--brand-accent); font-weight: 900; font-size: 0.9rem;">
                    ${p.price.toLocaleString('fa-IR')} <small style="font-size: 0.6rem;">تومان</small>
                </span>
                <div style="display: flex; align-items: center; gap: 4px; color: #fbbf24; font-size: 0.75rem; font-weight: bold;">
                    <i data-lucide="star" style="width: 12px; height: 12px; fill: currentColor;"></i>
                    ${p.rating}
                </div>
            </div>
        </div>
    `;
}

function renderProducts() {
    const list = document.getElementById('product-list');
    list.innerHTML = products.map(p => createProductCardHTML(p)).join('');
    if (window.lucide) window.lucide.createIcons();
}

function renderBlogs() {
    const list = document.getElementById('blog-list');
    list.innerHTML = blogs.map(b => `
        <div class="product-card">
            <img src="${b.image}" class="product-img">
            <h3 style="font-size: 0.9rem; font-weight: bold; margin: 15px 0;">${b.title}</h3>
            <p style="font-size: 0.7rem; color: var(--brand-text-secondary); line-height: 1.8;">${b.excerpt}</p>
        </div>
    `).join('');
}

// Product Detail
function showProductDetail(id) {
    const p = products.find(o => o.id === id);
    if (!p) return;
    
    document.getElementById('product-detail-container').innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 30px; padding: 20px;">
            <img src="${p.image}" style="width: 100%; max-width: 500px; border-radius: 30px; align-self: center;">
            <div class="admin-card">
                <span class="badge">${p.category}</span>
                <h1 style="font-weight: 900; margin: 15px 0;">${p.title}</h1>
                <p style="color: var(--brand-text-secondary); line-height: 2;">${p.description}</p>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 30px;">
                    <div style="font-size: 1.5rem; font-weight: 900; color: var(--brand-accent);">${p.price.toLocaleString('fa-IR')} تومان</div>
                    <button onclick="addToCart('${p.id}')" class="btn-accent">افزودن به سبد خرید</button>
                </div>
            </div>
        </div>
    `;
    showView('product-details');
}

// Cart Management
function addToCart(id) {
    const product = products.find(p => p.id === id);
    const existing = cart.find(item => item.id === id);
    if (existing) { existing.quantity += 1; } 
    else { cart.push({ ...product, quantity: 1 }); }
    saveCart();
    updateCartUI();
    openCart();
}

function updateCartUI() {
    const count = document.getElementById('cart-count');
    const items = document.getElementById('cart-items');
    const total = document.getElementById('cart-total');
    
    const totalCount = cart.reduce((acc, item) => acc + item.quantity, 0);
    count.innerText = totalCount;
    count.style.display = totalCount > 0 ? 'flex' : 'none';
    
    items.innerHTML = cart.length === 0 ? '<p style="text-align:center; opacity:0.5;">سبد خالی است</p>' : cart.map(item => `
        <div class="cart-item" style="margin-bottom:10px;">
            <img src="${item.image}" style="width: 40px; height: 40px; border-radius: 8px;">
            <div style="flex:1;"><div style="font-size:0.7rem;font-weight:bold;">${item.title}</div></div>
            <button onclick="removeFromCart('${item.id}')" style="background:none; border:none; color:#f43f5e; cursor:pointer;">×</button>
        </div>
    `).join('');
    
    const totalPrice = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    total.innerText = totalPrice.toLocaleString('fa-IR') + ' تومان';
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    saveCart();
    updateCartUI();
}

function saveCart() { localStorage.setItem('cart', JSON.stringify(cart)); }
function openCart() { document.getElementById('cart-drawer').classList.add('open'); document.getElementById('overlay').classList.add('active'); }
function closeCart() { document.getElementById('cart-drawer').classList.remove('open'); document.getElementById('overlay').classList.remove('active'); }

// Checkout Logic
function startCheckout() {
    if (cart.length === 0) return alert('سبد خرید شما خالی است');
    closeCart();
    showView('checkout');
    renderCheckoutStep();
}

function nextStep(s) {
    currentStep = s;
    renderCheckoutStep();
}

function renderCheckoutStep() {
    document.querySelectorAll('.checkout-step').forEach(el => el.style.display = 'none');
    document.getElementById('checkout-step-' + currentStep).style.display = 'block';
    
    document.querySelectorAll('.step-circle').forEach((el, i) => {
        if (i+1 <= currentStep) el.classList.add('active');
        else el.classList.remove('active');
    });

    if (currentStep === 1) {
        document.getElementById('checkout-items-list').innerHTML = cart.map(item => `
            <div style="display:flex; justify-content:space-between; margin-bottom:10px; font-size:0.8rem;">
                <span>${item.title} (${item.quantity})</span>
                <span>${(item.price * item.quantity).toLocaleString('fa-IR')}</span>
            </div>
        `).join('');
    }
}

async function completePurchase() {
    const payMethod = document.querySelector('input[name="pay"]:checked').value;
    
    if (payMethod === 'crypto') {
        if (typeof window.ethereum !== 'undefined') {
            try {
                alert('در حال اتصال به MetaMask...');
                await window.ethereum.request({ method: 'eth_requestAccounts' });
                alert('اتصال برقرار شد. لطفا تراکنش را در کیف پول خود تایید کنید.');
            } catch (e) {
                alert('خطا در اتصال به کیف پول: ' + e.message);
                return;
            }
        } else {
            alert('لطفا افزونه MetaMask را نصب کنید.');
            return;
        }
    }

    const newOrder = {
        id: Date.now(),
        items: cart,
        total: cart.reduce((acc, i) => acc + (i.price * i.quantity), 0),
        date: new Date().toLocaleDateString('fa-IR'),
        customer: {
            name: document.getElementById('ch-name') ? document.getElementById('ch-name').value : 'مشتری',
            phone: document.getElementById('ch-phone') ? document.getElementById('ch-phone').value : '-',
            address: document.getElementById('ch-address') ? document.getElementById('ch-address').value : '-'
        }
    };
    orders.push(newOrder);
    await saveToBackend();
    
    cart = [];
    saveCart();
    updateCartUI();
    showView('success');
}

// Admin Functions
async function handleAdminAddProduct() {
    const title = document.getElementById('adm-p-title').value;
    const price = parseInt(document.getElementById('adm-p-price').value);
    const category = document.getElementById('adm-p-cat').value;
    const image = document.getElementById('adm-p-img').value;
    const description = document.getElementById('adm-p-desc').value;

    if (!title || !price) return alert('لطفا فیلدهای ضروری را پر کنید');

    const newP = {
        id: Date.now().toString(),
        title, price, category, image, description,
        rating: 5.0
    };
    products.push(newP);
    await saveToBackend();
    alert('کالا با موفقیت اضافه شد');
    renderProducts();
    renderAdminLists();
}

async function saveToBackend() {
    const payload = { products, banners, blogs, orders };
    try {
        await fetch('api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
    } catch (e) {
        console.error('Save failed:', e);
    }
}

// Listeners
document.getElementById('open-cart').onclick = openCart;
document.getElementById('close-cart').onclick = closeCart;
document.getElementById('overlay').onclick = closeCart;
document.querySelector('#cart-drawer .btn-accent').onclick = startCheckout;

init();
