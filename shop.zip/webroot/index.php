<?php
// دریافت داده‌های اولیه در صورت نیاز (Server Side Rendering)
$dataFile = __DIR__ . '/data.json';
$dataRaw = @file_get_contents($dataFile);
$data = $dataRaw ? json_decode($dataRaw, true) : null;

if (!$data) {
    $data = [
        "products" => [],
        "banners" => [],
        "blogs" => []
    ];
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ایران استور | فروشگاه تخصصی دیجیتال</title>
    
    <!-- Local Assets -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- توجه: فونت وزیر را باید در پوشه assets/fonts قرار دهید -->
    <style>
        /* New Views and UI Components */
        .view-section { display: none; margin-top: 20px; animation: fadeIn 0.3s ease; }
        .view-section.active { display: block; }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        /* Admin & Forms */
        .admin-card { background: var(--brand-surface); border: 1px solid var(--brand-border); border-radius: 20px; padding: 25px; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: bold; color: var(--brand-text-secondary); margin-bottom: 5px; }
        .form-control { width: 100%; background: var(--brand-bg); border: 1px solid var(--brand-border); padding: 12px; border-radius: 10px; color: white; outline: none; transition: 0.2s; }
        .form-control:focus { border-color: var(--brand-accent); }

        /* Checkout Steps */
        .step-indicator { display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 30px; }
        .step-circle { width: 30px; height: 30px; border-radius: 50%; border: 2px solid var(--brand-border); display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; transition: 0.3s; }
        .step-circle.active { background: var(--brand-accent); border-color: var(--brand-accent); color: var(--brand-bg); }
        .step-line { flex: 1; height: 2px; background: var(--brand-border); max-width: 50px; }

        /* Utility */
        .hidden-mobile { display: inline; }
        @media (max-width: 640px) { .hidden-mobile { display: none; } }
    </style>
</head>
<body>

    <!-- Header / Nav -->
    <nav class="sticky-nav">
        <div class="container">
            <div class="nav-card">
                <div onclick="showView('home')" class="logo-section" style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <div style="background: var(--brand-accent); color: var(--brand-bg); width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-weight: 900;">IR</div>
                    <div>
                        <div style="font-weight: 900; font-size: 1.2rem;">ایران استور</div>
                        <div style="font-size: 0.6rem; color: var(--brand-accent); font-weight: bold; margin-top: -5px;">IRAN STORE PRO</div>
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px;" class="hidden-mobile">
                    <button onclick="showView('home')" style="background: none; border: none; color: white; cursor: pointer; font-weight: bold; font-size: 0.8rem;">فروشگاه</button>
                    <button onclick="showView('blog')" style="background: none; border: none; color: white; cursor: pointer; font-weight: bold; font-size: 0.8rem;">وبلاگ</button>
                    <button onclick="showView('about')" style="background: none; border: none; color: white; cursor: pointer; font-weight: bold; font-size: 0.8rem;">درباره ما</button>
                    <button onclick="showView('admin')" style="background: none; border: none; color: var(--brand-accent); cursor: pointer; font-weight: bold; font-size: 0.8rem;">مدیریت</button>
                </div>

                <div class="nav-actions" style="display: flex; gap: 15px;">
                    <button onclick="showView('search')" style="background: var(--brand-bg); border: 1px solid var(--brand-border); color: white; width: 40px; height: 40px; border-radius: 12px; display: flex; align-items: center; justify-content: center; cursor: pointer;">
                        <i data-lucide="search" style="width: 20px; height: 20px;"></i>
                    </button>
                    <button id="open-cart" class="btn-accent" style="display: flex; align-items: center; gap: 8px; position: relative;">
                        <i data-lucide="shopping-bag" style="width: 20px; height: 20px;"></i>
                        <span class="hidden-mobile">سبد خرید</span>
                        <span id="cart-count" style="background: #f43f5e; color: white; border-radius: 50%; width: 22px; height: 22px; font-size: 11px; display: none; align-items: center; justify-content: center; position: absolute; top: -11px; right: -11px; border: 2px solid var(--brand-surface);">0</span>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="container">
        
        <!-- Home View -->
        <div id="home-view" class="view-section active">
            <section id="hero-banner" style="margin-top: 20px;">
                <?php if(!empty($data['banners']) && isset($data['banners'][0]['image'])): ?>
                <div style="position: relative; border-radius: 30px; overflow: hidden; height: 350px;">
                    <img src="<?php echo htmlspecialchars($data['banners'][0]['image']); ?>" style="width: 100%; height: 100%; object-fit: cover; opacity: 0.6;">
                    <div style="position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: center; padding: 50px;">
                        <h1 style="font-size: 2.5rem; font-weight: 900;"><?php echo htmlspecialchars($data['banners'][0]['title'] ?? ''); ?></h1>
                        <p style="color: var(--brand-text-secondary);"><?php echo htmlspecialchars($data['banners'][0]['subtitle'] ?? ''); ?></p>
                        <button class="btn-accent" style="width: fit-content; margin-top: 20px;">مشاهده جشنواره</button>
                    </div>
                </div>
                <?php endif; ?>
            </section>
            <section style="margin-top: 40px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2 style="font-weight: 900; margin:0;">محصولات منتخب</h2>
                    <button onclick="showView('search')" style="background: none; border: none; color: var(--brand-accent); font-weight: bold; cursor: pointer; font-size: 13px;">مشاهده همه</button>
                </div>
                <div class="product-grid" id="product-list"></div>
            </section>
        </div>

        <!-- Search View -->
        <div id="search-view" class="view-section">
            <div style="background: var(--brand-surface); padding: 30px; border-radius: 24px; border: 1px solid var(--brand-border); margin-bottom: 30px;">
                <h2 style="font-weight: 900; margin-bottom: 20px;">جستجوی هوشمند</h2>
                <div style="display: flex; gap: 10px;">
                    <input type="text" id="search-input" class="form-control" placeholder="نام محصول را وارد کنید..." style="height: 50px;" oninput="handleSearch(this.value)">
                    <button class="btn-accent" style="width: 60px; height: 50px;"><i data-lucide="search"></i></button>
                </div>
            </div>
            <div class="product-grid" id="search-results"></div>
        </div>

        <!-- Product Details View -->
        <div id="product-details-view" class="view-section">
            <div id="product-detail-container"></div>
        </div>

        <!-- Blog View -->
        <div id="blog-view" class="view-section">
            <h2 style="font-weight: 900; margin-bottom: 30px;">مجله تکنولوژی ایران استور</h2>
            <div id="blog-list" class="product-grid"></div>
        </div>

        <!-- About View -->
        <div id="about-view" class="view-section">
            <div class="admin-card text-center" style="text-align: center; padding: 60px 20px;">
                <h2 style="font-weight: 900; margin-bottom: 20px;">درباره ایران استور</h2>
                <p style="color: var(--brand-text-secondary); max-width: 600px; margin: 0 auto;">ما با بیش از ۱۰ سال سابقه در فروش قطعات دیجیتال، بهترین‌ها را برای شما فراهم کرده‌ایم.</p>
                <div style="display: flex; justify-content: center; gap: 40px; margin-top: 40px;">
                    <div><div style="font-size: 1.5rem; font-weight: 900; color: var(--brand-accent);">+۵۰۰۰</div><div style="font-size: 0.7rem; opacity: 0.6;">مشتری راضی</div></div>
                    <div><div style="font-size: 1.5rem; font-weight: 900; color: var(--brand-accent);">۲۴/۷</div><div style="font-size: 0.7rem; opacity: 0.6;">پشتیبانی آنلاین</div></div>
                </div>
            </div>
        </div>

        <!-- Admin View -->
        <div id="admin-view" class="view-section">
            <div style="display: flex; gap: 10px; margin-bottom: 30px; overflow-x: auto; padding-bottom: 10px;">
                <button onclick="setAdminTab('products')" class="btn-accent">مدیریت کالاها</button>
            </div>
            <div id="admin-products-tab" class="admin-tab">
                <div class="admin-card">
                    <h3 style="margin-top: 0;">مدیریت کالاها</h3>
                    <div id="admin-product-list" style="margin-bottom: 20px; display: flex; flex-direction: column; gap: 10px;"></div>
                    <hr style="border: 0; border-top: 1px solid var(--brand-border); margin: 20px 0;">
                    <h4 style="margin-top: 0;">افزودن محصول جدید</h4>
                    <div class="form-group"><label>نام کالا</label><input id="adm-p-title" class="form-control"></div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group"><label>قیمت (تومان)</label><input id="adm-p-price" type="number" class="form-control"></div>
                        <div class="form-group"><label>دسته</label><input id="adm-p-cat" class="form-control"></div>
                    </div>
                    <div class="form-group"><label>تصویر (URL)</label><input id="adm-p-img" class="form-control"></div>
                    <div class="form-group"><label>توضیحات</label><textarea id="adm-p-desc" class="form-control" rows="2"></textarea></div>
                    <button onclick="handleAdminAddProduct()" class="btn-accent" style="width: 100%;">ثبت کالای جدید</button>
                </div>
            </div>

            <div id="admin-banners-tab" class="admin-tab" style="display: none;">
                <div class="admin-card">
                    <h3 style="margin-top: 0;">مدیریت بنرها</h3>
                    <div id="admin-banner-list" style="margin-bottom: 20px; display: flex; flex-direction: column; gap: 10px;"></div>
                    <hr style="border: 0; border-top: 1px solid var(--brand-border); margin: 20px 0;">
                    <h4 style="margin-top: 0;">افزودن بنر جدید</h4>
                    <div class="form-group"><label>عنوان بنر</label><input id="adm-b-title" class="form-control"></div>
                    <div class="form-group"><label>زیرعنوان</label><input id="adm-b-subtitle" class="form-control"></div>
                    <div class="form-group"><label>آدرس تصویر</label><input id="adm-b-img" class="form-control"></div>
                    <button onclick="handleAdminAddBanner()" class="btn-accent" style="width: 100%;">ثبت بنر جدید</button>
                </div>
            </div>
        </div>

        <!-- Checkout View -->
        <div id="checkout-view" class="view-section">
             <div class="step-indicator">
                <div class="step-circle active" id="step-1-circle">۱</div>
                <div class="step-line"></div>
                <div class="step-circle" id="step-2-circle">۲</div>
                <div class="step-line"></div>
                <div class="step-circle" id="step-3-circle">۳</div>
            </div>
            <div id="checkout-step-1" class="checkout-step">
                <div class="admin-card"><h3 style="margin-top:0;">بررسی سفارش</h3><div id="checkout-items-list"></div></div>
                <button onclick="nextStep(2)" class="btn-accent" style="width: 100%;">مرحله بعد</button>
            </div>
            <div id="checkout-step-2" class="checkout-step" style="display: none;">
                <div class="admin-card">
                    <h3 style="margin-top:0;">اطلاعات گیرنده</h3>
                    <div class="form-group"><label>نام</label><input id="ch-name" class="form-control"></div>
                    <div class="form-group"><label>آدرس</label><textarea id="ch-address" class="form-control"></textarea></div>
                </div>
                <button onclick="nextStep(3)" class="btn-accent" style="width: 100%;">مرحله بعد</button>
            </div>
            <div id="checkout-step-3" class="checkout-step" style="display: none;">
                <div class="admin-card"><h3>انتخاب پرداخت</h3><div style="display: flex; flex-direction: column; gap: 10px;">
                    <label class="admin-card" style="margin:0;"><input type="radio" name="pay" value="card" checked> کارت به کارت</label>
                </div></div>
                <button onclick="completePurchase()" class="btn-accent" style="width: 100%;">ثبت نهایی</button>
            </div>
        </div>

        <!-- Success View -->
        <div id="success-view" class="view-section">
            <div style="text-align: center; padding: 60px;">
                <h1 style="font-weight: 900;">تبریک! خرید انجام شد</h1>
                <button onclick="showView('home')" class="btn-accent" style="margin: 0 auto;">بازگشت</button>
            </div>
        </div>

    </main>

    <!-- Cart Drawer -->
    <div class="overlay" id="overlay"></div>
    <div id="cart-drawer">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <h2 style="font-weight: 900; margin: 0;">سبد خرید</h2>
            <button id="close-cart" style="background: none; border: none; color: white; cursor: pointer; font-size: 20px;">×</button>
        </div>
        <div id="cart-items" style="display: flex; flex-direction: column; gap: 15px; overflow-y: auto; max-height: calc(100% - 150px);">
            <!-- Cart items here -->
        </div>
        <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid var(--brand-border);">
            <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                <span style="color: var(--brand-text-secondary);">جمع کل:</span>
                <span id="cart-total" style="font-weight: 900; color: var(--brand-accent);">۰ تومان</span>
            </div>
            <button class="btn-accent" style="width: 100%; padding: 15px;">تایید و پرداخت</button>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/lucide.min.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>
