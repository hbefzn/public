<?php
/**
 * Iran Store API Backend (Pure PHP)
 * Handles data.json reading and writing
 */
header('Content-Type: application/json');

$dataFile = __DIR__ . '/data.json';

// Initialize data file if not exists
if (!file_exists($dataFile) || filesize($dataFile) < 50) {
    $initialData = [
        "products" => [
            ["id" => "1", "title" => "هدفون بی‌سیم سونی WH-1000XM5", "price" => 18450000, "description" => "بهترین تجربه نویز کنسلینگ جهان با صدای فوق‌العاده شفاف و باتری ۳۰ ساعته.", "image" => "https://images.unsplash.com/photo-1618366712277-72164424748a?w=600&q=80", "category" => "صوتی", "rating" => 4.9, "reviews" => 120],
            ["id" => "2", "title" => "اپل واچ الترا ۲ - بدنه تیتانیوم", "price" => 48800000, "description" => "سخت‌ترین و توانمندترین اپل واچ تا به امروز. مناسب برای ورزش‌های حرفه‌ای.", "image" => "https://images.unsplash.com/photo-1434494878577-86c23bcb06b9?w=600&q=80", "category" => "گجت", "rating" => 4.8, "reviews" => 85],
            ["id" => "3", "title" => "لپ‌تاپ ایسوس ROG Zephyrus G14", "price" => 95000000, "description" => "قدرتمندترین لپ‌تاپ ۱۴ اینچی گیمینگ جهان مجهز به گرافیک RTX 4070.", "image" => "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=600&q=80", "category" => "لپ‌تاپ", "rating" => 4.7, "reviews" => 43],
            ["id" => "4", "title" => "گوشی سامسونگ Galaxy S24 Ultra", "price" => 72900000, "description" => "پرچمدار جدید سامسونگ با بدنه تیتانیومی و هوش مصنوعی Galaxy AI.", "image" => "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=600&q=80", "category" => "موبایل", "rating" => 4.8, "reviews" => 210]
        ],
        "banners" => [
            ["id" => "b1", "image" => "https://images.unsplash.com/photo-1593642702821-c8da6771f0c6?w=1200&q=80", "title" => "جشنواره بهاره دیجیتال ایران", "subtitle" => "تا ۵۰ درصد تخفیف بر روی تمامی گجت‌های هوشمند"],
            ["id" => "b2", "image" => "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&q=80", "title" => "دنیای گیمینگ حرفه‌ای", "subtitle" => "کامل‌ترین تجهیزات گیمینگ با ارسال رایگان"]
        ],
        "blogs" => [
            ["id" => "bl1", "title" => "راهنمای خرید گوشی در ۲۰۲۴", "excerpt" => "چگونه بهترین گوشی را بر اساس بودجه خود انتخاب کنیم؟", "image" => "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&q=80"],
            ["id" => "bl2", "title" => "هوش مصنوعی در گجت‌ها", "excerpt" => "هوش مصنوعی چگونه تجربه ما را تغییر می‌دهد؟", "image" => "https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?w=800&q=80"]
        ],
        "orders" => []
    ];
    file_put_contents($dataFile, json_encode($initialData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    echo file_get_contents($dataFile);
} elseif ($method === 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    if ($data) {
        if (file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
            echo json_encode(["success" => true]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "خطا در نوشتن فایل"]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["error" => "داده نامعتبر"]);
    }
}
?>
